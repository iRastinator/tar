<html>
<body onload="document.frm1.submit()">
   <form action="poliv/index.php" name="frm1" method="POST">

   </form>
</body>
</html>