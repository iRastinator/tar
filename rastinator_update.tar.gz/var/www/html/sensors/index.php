<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Rastinator</title>
<script type="text/javascript" src="/ajax/jquery-3.7.0.min.js"></script>
<style>
     @import "../style.css" screen; /* Стиль для вывода результата на монитор */
     @import "../style.css" print, handheld; /* Стиль для печати и смартфона */

     *{
        padding: 0%;
        margin: 0%;
      }
	
		.container {
			grid-template-columns: clamp(11rem, 5.909rem + 25.45vw, 25rem) clamp(6.25rem, 2.841rem + 17.05vw, 15.625rem) clamp(5rem, -0.455rem + 27.27vw, 20rem) auto;
			display: grid;
		}

		.item {

			padding: 0px;
			border: 0px solid black;

		}

		.item_1 {
			grid-column-start: 1;
			grid-column-end: 5;
		}

		.item_2 {
			grid-column-start: 1;
			grid-column-end: 5;
		}

		.item_4 {
			grid-row-start: 3;

			grid-column-start: 1;
			grid-column-end: 5;
		}

		.item_3 {
						
		grid-row-start: 4;
		grid-row-end: 150;	
			padding-top: 3px;
			padding-right: 1px;
		}

 		.zatichka {
		    grid-row-start: 150;
			grid-row-end: 150;
				
		}

		@media (max-width: 1000px) {
			.container {
			grid-template-columns: 1px clamp(6.25rem, 4.911rem + 14.29vw, 15.625rem) clamp(10rem, -1.136rem + 18.18vw, 12.5rem) auto;
			display: grid;
			}

			.zatichka {
		    grid-row-start: 5;
			grid-row-end: 150;
				
			}

			.item_3 {
				grid-row-start: 4;
				grid-row-end: 4;
				grid-column-start: 1;
				grid-column-end: 5;

				padding-top: 3px;
				padding-right: 1px;
			}




		  }
   
</style>      
          
</head>

<body>


<?php
//Авторизация
include('../login/in.php');    
    
function debug_to_console($data) {
    $output = $data;
    if (is_array($output))
        $output = implode(',', $output);
    echo "<script>console.log('Debug Objects: " . $output . "' );</script>";
}    
?>
    
    
    
<div class="container">
     <div class="zatichka"></div>
    
<!-- Верхнее меню -->     
<div class="item item_1">
        <ul>
          <li><svg width="clamp(6.25rem, 3.977rem + 11.36vw, 12.5rem)" height="clamp(1.4rem, 0.369rem + 2.84vw, 2.5rem)" viewBox="150 -30 180 180"> <?php include('../pic/Rastinator.svg'); ?> </svg> </li>
          <li><a href="../poliv/index.php" >Полив</a></li>   
          <li><a href="../climat/index.php" >Климат</a></li>
          <li><a class="active">Датчики</a></li>
          <li><a href="../settings/index.php">Настройки</a></li>
          <li><a href="../log_poliva/index.php">Журнал полива</a></li>
          <li><a href="../log_domoticz/index.php">Лог системы</a></li>
        </ul>  
    

    
</div>           

<!-- Информационная панель - отображение данных лога -->     
<div class="item item_2" >
                               
             <script type="text/javascript">        
                $(document).ready(function() 
                { 
                var func = function() {$("#info").load('../log/log.php');}
                setInterval(func, 2000);

                });

            </script>                                

    
            <div id="info" >
               <?php include('../log/log.php'); ?>
                
            </div> 
</div> 
    
 
<!-- Select с названиями файлов --> 
<div class="item item_3">                        
                        

    
<form id="myform" method="POST" action="index.php">
      

     
        
<?php  // Заполнение Селекта названиями

    
$var = $_POST['rast'];   
    
$path = "/home/pi/domoticz/scripts/lua/";
                                                     
$des = '';
    

//$files = scandir($path); $x = count($files); //общее коллтчество файлов в директории

$files = glob($path . "*sensors*");
$x = count($files)+1;
	
$temp_m = array(); // Массив для скриптов полива
$temp_add2 = array(); // Массив для отключенных скриптов
    
if($handle = opendir($path))
    {
         $count = 0;
        
         
    // Загрузка имен файлов в массив где ключи это  set_start_time в этом файле, далее сортирровка  по времени(set_start_time) 
  
    while($entry = readdir($handle))
         {
              
            if ( substr($entry , 0 , 19) == 'script_time_sensors' )
              { 
					/*
                $comand = "grep ^sets_start_time ".$path.$entry." | grep -Eo '[0-9]{2}:[0-9]{2}'";
                $output = shell_exec($comand);
                $output = trim($output);  	
					*/
                $temp_m[$entry] = $output; 
        
                }
        
             if ( substr($entry , 0 , 11) == 'off_sensors' )
                   {
                    $temp_add2[$entry] = "Название";
                    }
                
            
        }
    $sep1['----1'] = "----1"; 

    asort($temp_m); 
    
    if (empty($temp_add2)==false and empty($temp_m)==false)
    {$temp_m = array_merge($temp_m, $sep1 );}
    
    $temp_m = array_merge($temp_m, $temp_add2 );

    //var_dump($temp_m);

    echo'<select  class="main" size="'.$x.'" name="rast" id="select_rast" onchange="this.form.submit()";>'; 

        
    foreach ($temp_m as  $entry => $value)
     {
            if ( substr($entry , 0 , 4) == '----')
            {
             echo '<option style="color:lightgray" disabled>──────────────────────────────────────────────────────────</option>';
            }   
                

             
            if ( substr($entry , 0 , 19) == 'script_time_sensors')
            {

                
                        $count = $count + 1;

                        $name = substr($entry , 20 , -4); 
 
                

                        
                
                // Если список грузится первый раз - выбор первого элемента 
                if ($var == null and $count == 1) { 
                    echo '<option selected value='.$entry.'>'.$name.'</option>';}
                
                // Если список грузится первый раз - загрузка последующих элементов
                if ($var == null and $count !== 1) {                      
                    echo '<option value='.$entry.'>'.$name.'</option>';}
                            
                           
                // Если список грузится не первый раз - выбор загружаемого элемента
                if ($var == $entry)   
                   { 
                    echo '<option selected value='.$entry.'>'.$name.'</option>';}
                
                // Если список грузится не первый раз - загрузка последующих элементов  
                elseif ($var !== null and $var !=='') 
                 {                      
                    echo '<option value='.$entry.'>'.$name.'</option>';}

                
                
                
              }
        
         //Отключенные скрипты 
        
        
        
        if ( substr($entry , 0 , 11) == 'off_sensors')
             { 
                
                    $count = $count + 1;
                    $name = substr($entry , 12 , -4); 
                    $len = strlen(trim($name));
              


                    // Если список грузится первый раз - выбор первого элемента 
                    if ($var == null and $count == 1) 
                    { echo '<option style="color:gray" selected value='.$entry.'>'.$name.' - Отключен</option>';}

                    // Если список грузится первый раз - загрузка последующих элементов
                    if ($var == null and $count !== 1)
                    { echo '<option style="color:gray" value='.$entry.'>'.$name.' - Отключен</option>'; }

                    // Если список грузится не первый раз - выбор загружаемого элемента
                    if ($var == $entry)   
                    { echo '<option style="color:gray" selected value='.$entry.'>'.$name.' - Отключен</option>';}

                    // Если список грузится первый раз - загрузка последующих элементов  
                    elseif ($var !== null and $var !=='') 
                     { echo '<option style="color:gray" value='.$entry.'>'.$name.' - Отключен</option>';} 

           
                
              }
        

        
            
      }
        

        
        // Маркер для кнопки удалить - отключает кнопку если последний элемент
        if ($count == 1) {$des = 'disabled';} 
        
        
    }closedir($handle);

    
    
 ?>
                                                                                                     
</select>
        
</form>   
    

    
 

    
</div> 

<!-- item item_4 - Кнопки включить отключить удалить Запустить остановить -  ----------> 
<div class="item item_4">
    
    
<div class="btn-group">
    
    <form id="delform" method="POST" action="del_file.php">
        
    <button class="button" name="del" value="" type="submit" onclick="return confirm('Вы уверены, что хотите Удалить Профиль Растения? ?')" <?php echo $des; ?> >Удалить</button> 

    <button class="button" name="otkl" value="" type="submit"  >Отключить</button>  

    <button class="button" name="vkl" value="" type="submit" >Включить</button> 

    
        <?php  //Кнопки Удалить Отключить Включить

    $file = $_POST['rast'];  

    // Определяем файл для загрузки если в первый раз
    if ($file == '')
    {

        $path = "/home/pi/domoticz/scripts/lua/";
                // определение первого файла в директории                                       
                if ($file == null) // Если список грузится первый раз - определения первого файла в директории 
                {$file = array_key_first($temp_m); }

        echo '<input  name="del_file"  value='.$file.' type="hidden" >'; //type="hidden"
    }                                           
    else 
    {
        echo '<input  name="del_file"  value='.$file.' type="hidden" >';//type="hidden"

    }      


    ?>
    

    </form>

     
    
    
<form id="myform2" method="POST" action="save_file.php" >

                                                                                                    
<?php  // 

//var_dump($_POST); echo '</br>';
//exit();    
    

            $var= $_POST['rast'] ;
      
            $path = "/home/pi/domoticz/scripts/lua/";

            
    
            // Если список грузится первый раз - определения первого файла в директории
            if ($var == null)  
            {$var = array_key_first($temp_m); }
    
            $filename = $path.$var;
        
            
            
    
            $Name = '';
            $flag = 'false';
            
            //Название растения - если с OFF - имя длиннее на 4 сивола
            if (substr($var, 0,4) ==  "off_"){
                $Name =  substr($var , 12 , strlen(trim($var))-16);
                $flag = 'disabled';
                }
            else{
                $Name =  substr($var , 20 , strlen(trim($var))-24);  }
                
 
 
    
    

       echo '<input class="button" type="submit" name="new_porfile" value="Сохранить новый профиль">';   
       echo '<input class="button" type="submit" name="save_changes" value="Сохранить изменения">';

    
        echo '</div>'; 
        
        ?>
        <div class="separation_div">  </div>
</div> 

    
<!-- item item_5 - Отображение загруженных настроек в инпуты ---------->

<?php 


       //Информация - имя файла при загрузке  
       echo '<input  name="origen_file"  value='.$filename.' type="hidden" >'; //
       
                                                      
                                                      
       echo '<input name="m_label" class="input_1"  value="Контроль:" > ';                 
      
    //Название растения
       echo '
       <input class="input_2" name="Name_unit" id="Name_unit" type="text" value="'.$Name.'" title="Уникальное название!"   autocomplete="off"  onkeydown="if(event.keyCode==13){return false;}" >'
?>
        <script>
        Name_unit.addEventListener("keydown", function(){this.style.backgroundColor = "#B0F0B0";this.style.color="black";})
        
        const inputField = document.getElementById('Name_unit');
        inputField.addEventListener('input', (event) => {
        const inputValue = event.target.value;
        const allowedInput = /^[A-Za-zА-Яа-я0-9-]+$/;
        if (!allowedInput.test(inputValue)) {
        event.target.value = inputValue.replace(/[^A-Za-zА-Яа-я0-9-]/g, '');
        }
        });

        </script>
   
 <?php           
		$file = fopen($filename, 'r');
    
         $ver = '';   
       
						
		//Для нижнего - определяем какой датчик по типу
	 	$sensor_type = ''; 
		for ($i = 0; $i < 20; $i++) 
		{	
			$stroka = fgets($file);
			if (substr($stroka , 0, 14) == 'set_rate_flora')
			   { $sensor_type = 'Flora';}
			if (substr($stroka , 0, 14) == 'set_rate_mijia')
			   { $sensor_type = 'Mijia';}
		}

		rewind($file);
	
        for ($i = 0; $i < 200; $i++) 
		{
                
            $stroka = fgets($file);
            

            $ins_serv = '"';
            
            if (substr($stroka , 0, 12) == '--separation'){
                echo' <input type="hidden" name="separation'.$i.'" value="--separation'.$i.'">
                <div class="separation_div"> </div>';      
            }
            
            if (substr($stroka , 0, 7) == '--info:'){
            echo '<input name="Name_unit_info" id="Name_unit_info" class="input_3" value="'.substr($stroka , 7, strlen($stroka)).'" autocomplete="off" onkeydown="if(event.keyCode==13){return false;}">
            <script>Name_unit_info.addEventListener("input", function(){this.style.backgroundColor = "#B0F0B0";this.style.color="black";})</script>'; 
            }
            
            $pos1      = strripos($stroka, 'label<');
            $pos2      = strripos($stroka, '>label');  
                            
            if ($pos1 == TRUE) // Если первый label< существует - всегда существет у всех установок
                {            
                    
                    $Label = substr($stroka , $pos1+6 , $pos2-$pos1-6);
                    $name =  substr($stroka , 0 , strripos($stroka, ' =')) ;
                

      

				// если MAC
                     if (substr($stroka , 0, 1) == '"') 
                    {

						 	$value_mac = trim(substr($stroka , 1 , 18 ));
						    $name= $value_mac;
                    		
						    $parts = explode(',', $stroka);
						 	$id_sens = trim($parts[1]);
						 
							// удаляем все кроме числа	ID					
							preg_match('/(\d+)/', $id_sens, $matches);
							$id_sens = $matches[1];

						
						 // Определение имени датчика по id
						 $st = 'curl "http://127.0.0.1:8080/json.htm?type=command&param=devices_list" ';
    					 $sens_name = shell_exec($st); 
						 
						 $responseObject = json_decode($sens_name);

							// Заданный idx
							$givenIdx = $id_sens;
						 	
							// Поиск объекта с заданным idx
							$deviceInfo = null;
							foreach ($responseObject->result as $item) 
							{
								if ($item->idx === $givenIdx) {
									$deviceInfo = $item;
									break;
								}
							}
						 

							// Получение имени
						   
							$deviceName = $deviceInfo ? $deviceInfo->name : "Ошибка: id не найдено! ";
 							
						 if ($deviceName != null){ $deviceName = rtrim($deviceName, " \t\n\r\0\x0B" . array_pop(explode(' ', $deviceName)));}
						 
						 echo 
                       '
                      <div class="div_mac_button">  
                        <input readonly class="input_mac" type="text" id="setm_'.$i.'" name="setm_'.$i.'"  value="'.$value_mac.'"  autocomplete="off" >

						<input class="button_smal_orange" id="butt_del_mac'.$i.'" name="butt_del_mac'.$i.'" value="X" onclick="clearInput'.$i.'(event)" readonly>
					  </div>	
						<script>
						function clearInput'.$i.'(event) {
  						event.preventDefault(); // Предотвращение отправки формы
  						document.getElementById("setm_'.$i.'").value = ""; // Устанавливаем значение инпута в пустую строку
						}
						</script>
						        
								
						<input  type="hidden" id="setID_'.$i.'" name="setID_'.$i.'"  value="'.$id_sens.'"  autocomplete="off" onkeydown="if(event.keyCode==13){return false;}">
						
						
						<input  class="input_2" type="text" id="sens_name_'.$i.'" name="sens_name_'.$i.'" readonly value="'.$deviceName.' "  autocomplete="off" >
						
                        ';
                        $name = $i;
                        
                    }
                    else
					{
					  // Создание Label       readonly   
                      echo'
                      <input  type="text"  class="input_1" id="label_'.$name.'" name="label_'.$name.'" value="'.$Label.'"   autocomplete="off" onkeydown="if(event.keyCode==13){return false;}" >                       
                          ';	
						
						
					}
                

   
                // Если просто одно цифровое значение
                if (substr($stroka , 0, 4) == 'set_')
                    {
                        $pos1 = strripos($stroka, '=');
                        $pos2 = strripos($stroka, '--');
                        $str =  substr($stroka , $pos1+2 , $pos2-$pos1-3);
                        
                        $format = 'type="number"';

                
                        echo'
                        
                        <input class="input_2" 
                        id="'.$name.'_dig" name="'.$name.'" value="'.$str.'" autocomplete="off"
                         '.$format.'onkeydown="if(event.keyCode==13){return false;}"
                                                
                        > 
                        <script>'.$name.'_dig.addEventListener("input", function(){this.style.backgroundColor = "#B0F0B0";this.style.color="black";})</script>                         

                        ';
                    
                    }
                    
               // Добавление названиия 
                    $pos1  = strripos($stroka, 'info<');
                    $pos2  = strripos($stroka, '>info');
                    if ($pos1 !== FALSE) // Если info< существует
                    {
     
                          if (substr($name, 0,3) == "set" or trim(substr($stroka , 0 , 1 )) == '"' )
                           {              
                            
							//readonly
                            echo'
                            <input  class="input_3_readonly" id="info_'.$name.'" name="info_'.$name.'" type="text" value="'.substr($stroka , $pos1+5 , $pos2-$pos1-5).'" title="'.substr($stroka , $pos1+5 , $pos2-$pos1-5).'" onkeydown="if(event.keyCode==13){return false;}"  >
                         

                            ';
                           }  
                            

                        
                    }
                    
                    
                                       
                   
                    

				
				
				
				
                }
            

			
			
			if (strpos($stroka , 'Ver')) 
         {$ver = substr($stroka , strpos($stroka , 'Ver'), 20) ;}            
                
        }   
        fclose($file); 
        				

  
        
        
?>    
    


<input type="hidden" id="add_new_flora" name="add_new_flora"  value=""  autocomplete="off" onkeydown="if(event.keyCode==13){return false;}">


<div class="separation_div"></div>
 
	<input class="input_1" type="text" id="add_name" name="add_name"  autocomplete="off" placeholder="Название">
	

	<input class="button_cell" type="submit" name="new_flora" value="Добавить датчик" >

 
	<input class="button_cell" type="submit" name="start" value="Опросить датчики">


	
<input type="hidden" name="cheсk" value="check"> <!--  Проверочный инпут в конце ------>

<div class="separation_div"></div>
	

	
</form> 
	

<!-- Проверка одного датчика  -->	
<input type="text" id="input1" class="input_1" placeholder="МАС адрес датчика">
<input  type="hidden" id="input2" value="<?php echo $sensor_type; ?>">
<button class="button_cell" id="fetchData">Тест датчика</button>

<div class="input_1"></div>
<div class="separation_div"></div>
<div id="dataDisplay"></div>

<!--Теперь при нажатии на кнопку, значение из input будет передаваться в запросе, а ответ от сервера будет отображаться в элементе с id "dataDisplay". -->	
<script>
document.addEventListener('DOMContentLoaded', function() {
  document.getElementById('fetchData').addEventListener('click', function() {
    var value1 = document.getElementById('input1').value;
	var value2 = document.getElementById('input2').value;

    var formData = new FormData();
    formData.append('param1', value1);
	formData.append('param2', value2);
	  

    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
      if (xhr.readyState === XMLHttpRequest.DONE) {
        if (xhr.status === 200) {
          document.getElementById('dataDisplay').innerHTML = xhr.responseText;
        } else {
          console.error('Произошла ошибка при выполнении запроса');
        }
      }
    };
    xhr.open('POST', 'test_sensor.php', true);
    xhr.send(formData);
  });
});
</script>

<!----   Этот код ищет все input элементы, у которых id начинается с "setm_" или "add_new_flora", и устанавливает значение выбранного input в input с id "input1" при клике на них. ---->
<script>	
document.addEventListener('DOMContentLoaded', function() {
  var inputs = document.querySelectorAll('input[id^="setm_"]');
  inputs.forEach(function(input) {
    input.addEventListener('click', function() {
      var clickedInputValue = input.value;
      var match = input.id.match(/setm_(\d+)/); // Извлечь номер из id кликнутого input
      if (match) {
        var sensNameInput = document.getElementById('sens_name_' + match[1]); // Найти соответствующий инпут
        if (sensNameInput) {
          var sensNameValue = sensNameInput.value; // Получить значение найденного инпута
          var input2Value = document.getElementById('input2').value; // Получить значение из input с id='input2'
          var trimmedValue = sensNameValue.split(input2Value)[0]; // Обрезать строку до первого вхождения значения из input2
          document.getElementById('add_name').value = trimmedValue; // Установить обрезанное значение в инпут с id=add_name
        }
      }
      document.getElementById('input1').value = clickedInputValue;
      document.getElementById('add_new_flora').value = clickedInputValue;
    });
  });
});

</script>	
	
	
<!----   Этот код отслеживает ввод и вставку текста в input с id "input1" и автоматически копирует данные в input с id "add_new_flora"---->
<script>	
document.addEventListener('DOMContentLoaded', function() {
  var input1 = document.getElementById('input1');
  var addNewFlora = document.getElementById('add_new_flora');
  
  function updateAddNewFlora() {
    addNewFlora.value = input1.value;
  }
  
  input1.addEventListener('input', updateAddNewFlora);
  input1.addEventListener('paste', function(e) {
    addNewFlora.value = (e.clipboardData || window.clipboardData).getData('text');
  });
  
  input1.addEventListener('change', updateAddNewFlora);
});
</script>		
	
	
	
	
	
    
</div> 

    
 
   

<div style="color:grey;"> <?php echo $ver ?></div>  
    
 <script>
	//Этот JavaScript код будет искать все элементы input с типом "number" на странице и добавлять обработчик события прокрутки колеса мыши. Когда происходит событие прокрутки, код проверяет, является ли целевой элемент активным (то есть, имеет ли фокус), и если это так, предотвращает стандартное поведение прокрутки. Таким образом, данная функция предотвращает изменение значения поля ввода типа "number" при прокрутке колеса мыши.
    document.querySelectorAll("input[type=number]").forEach(function (element) {
        element.addEventListener("wheel", function(event) {
            if (document.activeElement === event.target) {
                event.preventDefault();
            }
        });
    });
</script>
   
</body>
</html>