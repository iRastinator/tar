<?php


//Опрос одного датчика 
$info = '';
if(isset($_POST['param1']) and isset($_POST['param2']))
{
	
// оПРОС fLORA
	 if ($_POST['param2'] == 'Flora' )
	 {
	 $cmd = '/home/pi/bin/miflora '.$_POST['param1'] ;	

		 echo shell_exec($cmd); 
		 
	 }	
	
// Опрос Mijia
if ($_POST['param2'] == 'Mijia' )	
	{
	$cmd = '/home/pi/bin/mijia '.$_POST['param1'] ;	

		 echo shell_exec($cmd);
		 	
		
	}
	
}




?>