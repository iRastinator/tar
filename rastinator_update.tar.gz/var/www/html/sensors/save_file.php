<style>
	@import "../style.css" screen; /* Стиль для вывода результата на монитор */
    @import "../style.css" print, handheld; /* Стиль для печати и смартфона */

</style>                                    

<div style="Position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);">
	<?php include('../pic/process.svg'); ?> 
</div>

<?php
                                      
//echo '</br>_POST=';
//var_dump($_POST); exit();
//echo '</br>Button=';
//var_dump(isset($_POST['run_script']));
//exit();
 //var_dump($_POST['input1']); exit();
    
//var_dump($_POST);
//var_dump($_POST['Name_unit']); exit();

// Если произошел сбой при отправкие формы  и последний проверочный input отсутствует - то выход.
if($_POST["cheсk"] != "check") { exit();}

$filename=''; // Имя файла для отправки в index.php

function utf8_urldecode($str) 
	{$str = preg_replace("/%u([0-9a-f]{3,4})/i","&#x\\1;",urldecode($str));
	 return html_entity_decode($str,ENT_COMPAT,'UTF-8');;
	}




//Опрос датчиков
if(isset($_POST['start']))
{
	// оПРОС fLORA
	 if (isset($_POST['set_rate_flora']) )
		 {
		 $mac = '';
		 
			 foreach ($_POST as $key => $value) 
			 {
				if (substr($key, 0, 5) == 'setm_') 
				{
				 
				 $id = trim( $_POST[str_replace('setm', 'setID', $key)] );	
					
					// Регулярное выражение для извлечения IP и MAC
					$pattern = '/((\d{1,3}\.){3}\d{1,3})?\/?([0-9A-Fa-f:]{17}|[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2})/';


						if (preg_match($pattern, $value, $matches)) 
						{
							$ip = isset($matches[1]) ? $matches[1] : '127.0.0.1'; // IP (или 127.0.0.1 если не найден)
							$mac = isset($matches[3]) ? $matches[3] : null; // MAC находится в третьей группе

						} 
						
					 	$stt = ' "'.$mac.'"'.' '.'"'.$id.'"'.' '.'"'. ((int)$id + 1) .'"'.' '.'"'. ((int)$id + 2) .'"'.' '.'"'. ((int)$id + 3) .'"';
					    
						if ($ip == '127.0.0.1' or $ip == '')
						{
						 $cmd = 'python3 /home/pi/domoticz/scripts/python/miflora/miflora_s.py 127.0.0.1'.$stt ;
						}
						else
						{
						 $server_ip = $_SERVER['SERVER_ADDR'];
						$cmd = "sudo -u pi ssh -o StrictHostKeyChecking=no pi@" .$ip. " 'python3 /home/pi/domoticz/scripts/python/miflora/miflora_s.py ".$server_ip. $stt. " '";
							//echo ($cmd); exit;
						}
						
				 		shell_exec($cmd.' > /dev/null 2>/dev/null &');  
				 }

				 
			  }

		 
		     //для отправки в index.php
		     $filename = str_replace('/home/pi/domoticz/scripts/lua/', '', $_POST['origen_file']);

     
		 }
	
	// Опрос Mijia
	if (isset($_POST['set_rate_mijia']) )
		 {
			$mac = '';
		 
			 foreach ($_POST as $key => $value) 
			 {
				if (substr($key, 0, 5) == 'setm_') 
				{
				 $id = trim( $_POST[str_replace('setm', 'setID', $key)] );	
					
					// Регулярное выражение для извлечения IP и MAC
					$pattern = '/((\d{1,3}\.){3}\d{1,3})?\/?([0-9A-Fa-f:]{17}|[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2})/';


						if (preg_match($pattern, $value, $matches)) 
						{
							$ip = isset($matches[1]) ? $matches[1] : '127.0.0.1'; // IP (или 127.0.0.1 если не найден)
							$mac = isset($matches[3]) ? $matches[3] : null; // MAC находится в третьей группе

						} 
						
					 	$stt = ' "'.$mac.'"'.' '.'"'.$id.'"';
					    
						if ($ip == '127.0.0.1' or $ip == '')
						{
						 $cmd = '/home/pi/domoticz/Domoticz_Python_Environment/bin/python3 /home/pi/domoticz/scripts/python/mijia/mijia_s.py 127.0.0.1'.$stt ;

						 shell_exec($cmd.' > /dev/null 2>/dev/null'); // с & - не работает в фоне
							//echo ($cmd); exit;					
						}
						else
						{
						 $server_ip = $_SERVER['SERVER_ADDR'];
						
						$cmd = "sudo -u pi ssh -o StrictHostKeyChecking=no pi@" .$ip. " 'python3 /home/pi/domoticz/scripts/python/mijia/mijia_s.py " .$server_ip . $stt. " '";
						shell_exec($cmd.' > /dev/null 2>/dev/null &');
							//echo ($cmd); exit;
						}
						
			
					   
					
		
				 }

				 
			  }
		//для отправки в index.php 
		$filename = str_replace('/home/pi/domoticz/scripts/lua/', '', $_POST['origen_file']);

		 }
	
	
		// оПРОС BLE
	 if (isset($_POST['set_rate_ble']) )
		 {
		 $mac = '';
		 
			 foreach ($_POST as $key => $value) 
			 {
				if (substr($key, 0, 5) == 'setm_') 
				{
				 
				 $id = trim( $_POST[str_replace('setm', 'setID', $key)] );	
					
					// Регулярное выражение для извлечения IP и MAC
					$pattern = '/((\d{1,3}\.){3}\d{1,3})?\/?([0-9A-Fa-f:]{17}|[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2})/';


						if (preg_match($pattern, $value, $matches)) 
						{
							$ip = isset($matches[1]) ? $matches[1] : '127.0.0.1'; // IP (или 127.0.0.1 если не найден)
							$mac = isset($matches[3]) ? $matches[3] : null; // MAC находится в третьей группе

						} 
						
					 	$stt = ' "'.$mac.'"'.' '.'"'.$id.'"'.' '.'"'. ((int)$id + 1) .'"'.' '.'"'. ((int)$id + 2) .'"'.' '.'"'. ((int)$id + 3) .'"'.' '.'"'. ((int)$id + 4) .'"'.' '.'"'. ((int)$id + 5) .'"';
					    
						if ($ip == '127.0.0.1' or $ip == '')
						{
						 $cmd = 'python3 /home/pi/domoticz/scripts/python/ble/ble-yc01_s.py 127.0.0.1'.$stt ;
		
						}
						else
						{
						 $server_ip = $_SERVER['SERVER_ADDR'];
						
						$cmd = "sudo -u pi ssh -o StrictHostKeyChecking=no pi@" .$ip. " 'python3 /home/pi/domoticz/scripts/python/ble/ble-yc01_s.py ".$server_ip. $stt. " '";
						//echo ($cmd); exit;
						}
						
				 		shell_exec($cmd.' > /dev/null 2>/dev/null &');  
				 }

				 
			  }

		 
		     //для отправки в index.php
		     $filename = str_replace('/home/pi/domoticz/scripts/lua/', '', $_POST['origen_file']);

     
		 }
	
	
}



// Если  сохранить изменения - удаляется старый файл и дальше генерится новой -----------------
// удаляем переменную для старого названия и создаем новую

if(isset($_POST['save_changes'])) 
{   
    
    $name_o = str_replace('/home/pi/domoticz/scripts/lua/script_time_sensors_', '', $_POST['origen_file']);
       
   // Если скрипт выключен    
    if (substr( $_POST['origen_file'], 0 , 41) == '/home/pi/domoticz/scripts/lua/off_sensors_') {
     $name_o = str_replace('/home/pi/domoticz/scripts/lua/off_sensors_', '', $_POST['origen_file']);   
         }
     
    $name_o = str_replace ('.lua', '' , $name_o);

    
    //Удаление файла скрипта
    $comand = ' rm '.$_POST['origen_file'];
    //echo $comand; 
    $output = shell_exec($comand);

}
    
//exit();





// Создание нового файла  ------------------------------------------------------
$query_string = "";
$key = "";
$value = "";

if (isset($_POST['save_changes']) || isset($_POST['new_porfile']) || isset($_POST['new_flora']) ) 
{  
       $set_value = array();
       $set_mac = array();
       $set_all = array();
       $sensID = array();
       $label = array();
       $info = array();
    
      
		// Имя файла на основе данных из $_POST
		$filename = $_POST['Name_unit'].".lua";

		// Проверка на существование файла и создание нового имени если файл есть
		$directory = "/home/pi/domoticz/scripts/lua/";

		// Проверяем, существует ли файл и добавляем `-N` к имени, если файл существует
		$baseName = $filename; // Сохраняем базовое имя без изменений
		$count = 1; // Инициализируем счетчик

		// Полный путь к файлу
		$filePath = $directory . 'script_time_sensors_'.$filename;

		if (isset($_POST['new_flora']) == false)
		{
			// Проверка существования файла и создание нового имени, если файл есть
			while (file_exists($filePath)) {
				// Проверяем, есть ли суффикс -N
				if (preg_match('/-(\d+)\.lua$/', $filename, $matches)) {
					// Увеличиваем значение на 1
					$count = (int)$matches[1] + 1;
					// Убираем суффикс -N для основы
					$baseName = preg_replace('/-\d+\.lua$/', '', $filename);
				} else {
					// Если нет суффикса -N, начинаем с 1
					$baseName = pathinfo($filename, PATHINFO_FILENAME); // Получаем имя файла без расширения
					$count = 1; // Устанавливаем счетчик на 1 для -1
				}

				// Устанавливаем новое имя файла
				// Обновляем файл без расширения и добавляем новое имя
				$filename = $baseName . '-' . $count . '.lua';
				$filePath = $directory . 'script_time_sensors_'. $filename; // Обновляем полный путь к файлу
			}
		}
//-------------	
    
    
    
    $fh = fopen("/home/pi/domoticz/scripts/lua/temp_script_time_sensors_".$filename, "w"); 
   
    fwrite($fh , 'commandArray = {}'."\r\n");
    fwrite($fh , '------------------------------------------------------------------------------'."\r\n");
    fwrite($fh , '------------------------------ Установки -------------------------------------'."\r\n");
    fwrite($fh , 'Name_unit = "'.trim($_POST['Name_unit']).'"'."\r\n");

   

       foreach ($_POST as $key => $value) 
       {
		 if(substr($key, 0, 4) == 'info'  ) {$info[$key] = $value;}
		 if(substr($key, 0, 6) == 'label_') {$label[$key] = $value;}  
		 if(substr($key, 0, 4) == 'set_'  ) {$set_value[$key] = $value;}
		 if(substr($key, 0, 5) == 'setm_' and $value !=='') {$set_mac[$key] = $value;}
		 if(substr($key, 0, 6) == 'setID_' ) {$sensID[$key] = $value;}
		   
		 if(substr($key, 0, 3) == 'set'  ) {$set_all[$key] = $value;}
		 if(substr($key, 0, 10)  == 'separation'  ) {$set_all[$key] = $value;}
		 if(substr($key, 0, 14)  == 'Name_unit_info'  ) {$set_all[$key] = $value;}
       }
    	//var_dump($set_mac); exit();    
		

	
	
	

	$tak = 0;
    foreach ($set_all as $key => $value) 
       {
        
        
        if (substr($key, 0, 14)  == 'Name_unit_info')
            {
            fwrite($fh , '--info:'.$_POST['Name_unit_info']."\r\n");
            }
        
        if (substr($key, 0, 10)  == 'separation') 
            {
            fwrite($fh , '--separation'."\r\n");
            }

        if (substr($key, 0, 4) == 'set_') 
            {
            fwrite($fh , $key);
            fwrite($fh , ' = ');
            fwrite($fh , trim($set_value[$key]) );    
            }
		      
		
		
		// Массив мас адресов - отдельное построение всей строки
		if (substr($key, 0, 5) == 'setm_' ) 
			{
				if ($tak == 0){ fwrite($fh , "sens = {"."\r\n"); $tak = $tak+1 ;}
				 
			}
		if (substr($key, 0, 5) == 'setm_' and $value !== '' and isset($_POST['new_porfile'])== false) 
            {
            
				
				fwrite($fh , '"');
				fwrite($fh , trim($set_mac[$key]) );
				fwrite($fh , ' , ');
				fwrite($fh , trim($sensID[str_replace('setm', 'setID', $key)]) );
				fwrite($fh , '"');
				fwrite($fh , ', ');


				fwrite($fh , ' -- label<>label ');
				fwrite($fh , 'info<');
				fwrite($fh , trim($info[str_replace('setm', 'info', $key)]) );
				fwrite($fh , '>info'."\r\n");

			}
		
		
		
		
		//удалени  датчиков в домотиксе если поле с мас - пустое и скрипт 
		if (substr($key, 0, 5) == 'setm_' and $value == '' )
		{

		$del_sens_flora = trim($sensID[str_replace('setm', 'setID', $key)] );	
		$del_sens_flora2 = (int)$del_sens_flora +1;
		$del_sens_flora3 = (int)$del_sens_flora +2;
		$del_sens_flora4 = (int)$del_sens_flora +3;
		$del_sens_flora5 = (int)$del_sens_flora +4;
		$del_sens_flora6 = (int)$del_sens_flora +5;
		
		$st = 'curl "http://127.0.0.1:8080/json.htm?idx='.$del_sens_flora.'&param=deletedevice&type=command"';
		shell_exec($st);

			//Удаляем еще 3 датчик - если скрипт - flora
			if(isset($_POST['set_rate_flora'])) 
			{
				$st = 'curl "http://127.0.0.1:8080/json.htm?idx='.$del_sens_flora2.'&param=deletedevice&type=command"';
				shell_exec($st);
				$st = 'curl "http://127.0.0.1:8080/json.htm?idx='.$del_sens_flora3.'&param=deletedevice&type=command"';
				shell_exec($st);
				$st = 'curl "http://127.0.0.1:8080/json.htm?idx='.$del_sens_flora4.'&param=deletedevice&type=command"';
				shell_exec($st);
			}
			//Удаляем еще 5 датчик - если скрипт - ble
			if(isset($_POST['set_rate_ble'])) 
			{
				$st = 'curl "http://127.0.0.1:8080/json.htm?idx='.$del_sens_flora2.'&param=deletedevice&type=command"';
				shell_exec($st);
				$st = 'curl "http://127.0.0.1:8080/json.htm?idx='.$del_sens_flora3.'&param=deletedevice&type=command"';
				shell_exec($st);
				$st = 'curl "http://127.0.0.1:8080/json.htm?idx='.$del_sens_flora4.'&param=deletedevice&type=command"';
				shell_exec($st);
				$st = 'curl "http://127.0.0.1:8080/json.htm?idx='.$del_sens_flora5.'&param=deletedevice&type=command"';
				shell_exec($st);
				$st = 'curl "http://127.0.0.1:8080/json.htm?idx='.$del_sens_flora6.'&param=deletedevice&type=command"';
				shell_exec($st);				
			}
			
			
	
			
		}

     
	
        if (substr($key, 0, 3) == 'set' and substr($key, 0, 6) !== 'setID_' and substr($key, 0, 5) !== 'setm_')
        {
            fwrite($fh , ' -- label<');
            fwrite($fh , trim($label["label_".$key]) ); 
            fwrite($fh , '>label ');
			
					
            fwrite($fh , 'info<');
            fwrite($fh , trim ($info["info_".$key]));
            fwrite($fh , '>info'."\r\n");
         }
    
			
              
      }		
	
	
	//////////////////// Изменеие имени сенсоров
		
		$count = 0;
		$name_edit_id = '';
		foreach ($set_mac as $key => $value) 
		{
		  if ($value == trim($_POST['add_new_flora'])) 
		  {
			$count++;
			$name_edit_id = trim($sensID[str_replace('setm', 'setID', $key)]) ;
		  }
			
		}

		if ($count > 0) 
		{
			$sens_type = '';

			$n_sens = '';

			$words = explode(' ', $_POST['add_name']);

			$n_sens = $name_edit_id.'_'.((int)$name_edit_id+3).' - ';
			$n_sens2 = $name_edit_id.' - ';
			if(count($words) >= 2 and strpos($_POST['add_name'] , '-')) 
			{
			$n_sens = $name_edit_id.'_'.((int)$name_edit_id+3);
				if (isset($_POST['set_rate_mijia']) )
				{
					$n_sens2 = $name_edit_id.' ';
				}
			} 

			if (isset($_POST['set_rate_flora']) )
			
				{
				$sens_type = 'Flora';

				$name_e = urlencode(trim($_POST['add_name']) .' '.$sens_type. ' ' .$n_sens.' ');

				$st = 'curl "http://127.0.0.1:8080/json.htm?type=setused&idx='.$name_edit_id.'&name='.$name_e.'Влажность'.'&used=true"';
				shell_exec($st);	

				$st = 'curl "http://127.0.0.1:8080/json.htm?type=setused&idx='.((int)$name_edit_id+1).'&name='.$name_e.'Температура'.'&used=true"';
				shell_exec($st);
				$st = 'curl "http://127.0.0.1:8080/json.htm?type=setused&idx='.((int)$name_edit_id+2).'&name='.$name_e.'Освещенность'.'&used=true"';
				shell_exec($st);	
				$st = 'curl "http://127.0.0.1:8080/json.htm?type=setused&idx='.((int)$name_edit_id+3).'&name='.$name_e.'EC'.'&used=true"';
				shell_exec($st);	
				}
			
			if (isset($_POST['set_rate_mijia']) )
				{
				$sens_type = 'Mijia';
				$name_e = urlencode(trim($_POST['add_name']) .' '.$sens_type. ' ' .$n_sens2.'Температура и Влажность');

				$st = 'curl "http://127.0.0.1:8080/json.htm?type=setused&idx='.$name_edit_id.'&name='.$name_e.'&used=true"';
				shell_exec($st);	


				}
			
			if (isset($_POST['set_rate_ble']) )
			
				{
				$sens_type = 'BLE';

				$name_e = urlencode(trim($_POST['add_name']) .' '.$sens_type. ' ' .$n_sens.' ');


				$st = 'curl "http://127.0.0.1:8080/json.htm?type=setused&idx='.((int)$name_edit_id).'&name='.$name_e.'Температура'.'&used=true"';
				shell_exec($st);
				$st = 'curl "http://127.0.0.1:8080/json.htm?type=setused&idx='.((int)$name_edit_id+1).'&name='.$name_e.'EC'.'&used=true"';
				shell_exec($st);
				$st = 'curl "http://127.0.0.1:8080/json.htm?type=setused&idx='.((int)$name_edit_id+2).'&name='.$name_e.'ph'.'&used=true"';
				shell_exec($st);
				$st = 'curl "http://127.0.0.1:8080/json.htm?type=setused&idx='.((int)$name_edit_id+3).'&name='.$name_e.'ORP'.'&used=true"';
				shell_exec($st);
				$st = 'curl "http://127.0.0.1:8080/json.htm?type=setused&idx='.((int)$name_edit_id+4).'&name='.$name_e.'Free Chlorine'.'&used=true"';
				shell_exec($st);
				$st = 'curl "http://127.0.0.1:8080/json.htm?type=setused&idx='.((int)$name_edit_id+5).'&name='.$name_e.'TDS'.'&used=true"';
				shell_exec($st);				
				
				
				}
			//echo $set_mac;
			//echo $st; 
			//exit();
		} 


	///////////////////////////
	
		//если нет ни одного адреса
			if (count($set_mac) == 0 and $tak == 0)
				{ fwrite($fh , "sens = {"."\r\n");}

			//Добавление нового датчика
			if(   trim($_POST['add_new_flora']) !== '' and isset($_POST['new_flora']) and $count == 0) 
				{
				
					include 'add_new_flora.php';



					if (isset($_POST['set_rate_flora']) )
					{
						$id_new_flora_info = 'Влажность id:'.$id_new_flora.' Температура id:'.((int)$id_new_flora+1).' Освещенность id:'.((int)$id_new_flora+2).' EC id:'.((int)$id_new_flora+3);
					}

				
					if (isset($_POST['set_rate_mijia']) )
					{
						$id_new_flora_info = 'Температура и Влажность id:'.$id_new_flora;
					}
				
				
					if (isset($_POST['set_rate_ble']) )
					{
						$id_new_flora_info = 'Температура id:'.$id_new_flora.' EC id:'.((int)$id_new_flora+1).' pH id:'.((int)$id_new_flora+2).' ORP id:'.((int)$id_new_flora+3).' Free Chlorine id:'.((int)$id_new_flora+4).' TDS id:'.((int)$id_new_flora+5);
					}


					fwrite($fh , '"'.$_POST['add_new_flora'].' , '.$id_new_flora.'",  -- label<>label info<'.$id_new_flora_info.'>info');

				
				
					fwrite($fh , "\r\n");	
				}
		
			fwrite($fh , "}"."\r\n");
	
	
	
	
	
    //Присоединение програмной части
            //
            if (isset($_POST['set_rate_flora']) )
            {$file2 = file_get_contents( "script_part_flora" ); }
            // 
            if (isset($_POST['set_rate_mijia']) )
            {$file2 = file_get_contents( "script_part_mijia" ); }
			
			if (isset($_POST['set_rate_ble']) )
            {$file2 = file_get_contents( "script_part_ble" ); }   
            
            
            fwrite($fh , $file2);

    fclose($fh); 

    //Копирование финального файла
    $path1 = "/home/pi/domoticz/scripts/lua/temp_script_time_sensors_".$filename;
    $path2 = '/home/pi/domoticz/scripts/lua/script_time_sensors_'.$filename;
    
    
    
    $name_o = str_replace('/home/pi/domoticz/scripts/lua/', '', $_POST['origen_file']); 
    if (substr($name_o,0,4) =='off_')
        {
         $path2 = '/home/pi/domoticz/scripts/lua/off_sensors_'.$filename;
         $filename = 'off_sensors_'.$filename;
        } 
    else {$filename = 'script_time_sensors_'.$filename;}
    
    
    $comand = ' mv '. $path1. ' '. $path2;
    $output = shell_exec($comand);
//echo $comand ; exit;
 


}
else { $query_string = $_SERVER['QUERY_STRING'];}




 


 

// Эта форма отправляется автоматом после загрузки страницы
echo 
     '
<html>
<body onload="document.frm1.submit()">
   <form action="index.php" name="frm1" method="POST">
      <input type="hidden" name="rast" value="'.$filename.'" />

   </form>
</body>
</html>
' 




?>