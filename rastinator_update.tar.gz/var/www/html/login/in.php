

<?php //Аторизация 

$login = $_POST["username"];
$password = $_POST["password"];

//Если есть сооке
$token_from_file='';
if (isset($_COOKIE['Rast7'])) 
{
	$comand = "more /var/www/html/login/token";
    $token_from_file = shell_exec($comand);
    
    //echo strpos($output, $_COOKIE['Rast7']);
    if (strpos($token_from_file, $_COOKIE['Rast7']) ) 
      {
        //echo strpos($token_from_file, $_COOKIE['Rast7']);
        
            //echo $_COOKIE['Rast7'];
        // загрузка страницы

      } 
    
}


// Доделать - не принимать просроченные cooke из файла на сервере?



// URL для запроса авторизации
$url = "curl -k 'https://".$login.':'.$password."@localhost/json.htm?type=command&param=getversion'";
$output_s = shell_exec($url); 



//Аторизация у domoticz если Да
if (strpos($output_s, "SystemName") !== false)
{

    if($_POST["remember_me"]=='1' || $_POST["remember_me"]=='on')
                    {
        
                    $token = random_bytes(15);
                    $token = bin2hex($token);
                    $hour = time() + 3600 * 24 * 30;
                    
                    //Запись куки в браузер
                    setcookie('Rast7', $token, $hour);
					setcookie('Rast7', $token, $hour , "/poliv/");
                    setcookie('Rast7', $token, $hour , "/climat/");
                    setcookie('Rast7', $token, $hour , "/settings/");
                    setcookie('Rast7', $token, $hour , "/sensors/");
                    setcookie('Rast7', $token, $hour , "/settings/");
                    setcookie('Rast7', $token, $hour , "/log_poliva/");
                    setcookie('Rast7', $token, $hour , "/log_domoticz/");
                    setcookie('Rast7', $token, $hour , "/log/");
        
                    
                    //$comand = "echo '".$token."' >> /var/www/html/token";
                    $comand = "echo '".$token."[".$hour."'] >> /var/www/html/login/token";
                    $output = shell_exec($comand);

            
                    }
            else
            {       // Если пользователь не сохраняется устанвливается время доступа 10 мин
                    $token = random_bytes(15);
                    $token = bin2hex($token);
                    $hour = time() + 600 ;
                    
                    //Запись куки в браузер
                    setcookie('Rast7', $token, $hour);
					setcookie('Rast7', $token, $hour , "/poliv/");
                    setcookie('Rast7', $token, $hour , "/climat/");
                    setcookie('Rast7', $token, $hour , "/settings/");
                    setcookie('Rast7', $token, $hour , "/sensors/");
                    setcookie('Rast7', $token, $hour , "/settings/");
                    setcookie('Rast7', $token, $hour , "/log_poliva/");
                    setcookie('Rast7', $token, $hour , "/log_domoticz/");
                    setcookie('Rast7', $token, $hour , "/log/");
                
                    $comand = "echo '".$token."[".$hour."'] >> /var/www/html/login/token";
                    $output = shell_exec($comand);
                
            }
                      
            // загрузка страницы
        
    
}
else
{
    //echo "False";
}


// Если сооке нет или порольи логин не подошел 
if (strpos($output_s, "SystemName") == false and strpos($token_from_file, $_COOKIE['Rast7']) == false ){
    


echo'
<style>
body {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: #545454;
  font-family: Arial, sans-serif;
}

form {
  width: 250px;
  background-color: #fff;
  padding: 20px;
  border-radius: 5px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

p {
  margin-bottom: 15px;
}

label {
  display: block;
  font-family: Arial;
  color: green;
  color: #666;
  font-size: 14px;
}

input[type="text"],
input[type="password"] {
  width: 95%;
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 5px;
}

input[type="checkbox"] {
  margin-right: 5px;
}

input[type="submit"] {
  background-color: #4CAF50;
  color: white;
  padding: 10px 15px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

input[type="submit"]:hover {
  background-color: #45a049;
}

h1{
    -webkit-text-size-adjust: 100%;
    --fa-style-family-classic: "Font Awesome 6 Free";
    --fa-font-solid: normal 900 1em/1 "Font Awesome 6 Free";
    box-sizing: border-box;
    padding: 0em;
    clear: both;
    padding-bottom: 5px;
    opacity: .7;
    text-transform: uppercase;
    text-align: center;
    color: #666;
    margin: 0 0 30px 0;
    letter-spacing: 4px;
    font: normal 26px/1 Verdana, Helvetica;
    position: relative;
    }
.clearfix::after {
  content: "";
  clear: both;
  display: table;
}

.clearfix {
  margin-bottom: 10px;
}
</style>



<form class="autification" method="POST">
<h1>RASTINATOR</h1>
    <p class="clearfix">
        <input type="text" autocapitalize="none" autocorrect="off" name="username" id="username" placeholder="Имя"  autofocus="" ng-required="">
    </p>
    <p class="clearfix">
        <input type="password" name="password" id="password" placeholder="Пароль">
    </p>
    
    <br>

    <input type="checkbox" name="remember_me" id="remember_me" style="float: left;">
    <label for="remember_me" style="word-wrap: break-word; line-height: 16px; float: left;">Запомнить меня</label>

    <br> <br>
    
    <p class="clearfix">
        <input type="submit" name="submit" value="Войти">
    </p>      
</form>


'; exit();
            }




?>