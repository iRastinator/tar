<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8" />
	<title>Rastinator</title>
	<script type="text/javascript" src="/ajax/jquery-3.7.0.min.js"></script>
	<style>
		@import "../style.css";

		* {
			padding: 0%;
			margin: 0%;
		}


		body {
			background-color: gainsboro;
		}

	</style>

</head>

<body>


	<?php
//Авторизация
include('../login/in.php');    
    
function debug_to_console($data) {
    $output = $data;
    if (is_array($output))
        $output = implode(',', $output);
    echo "<script>console.log('Debug Objects: " . $output . "' );</script>";
}    
?>



	<div class="container">

		<!-- Верхнее меню -->
		<div class="item item_1">
			<ul>
				<li><svg width="clamp(6.25rem, 3.977rem + 11.36vw, 12.5rem)" height="clamp(1.4rem, 0.369rem + 2.84vw, 2.5rem)" viewBox="150 -30 180 180"> <?php include('../pic/Rastinator.svg'); ?> </svg> </li>
				<li><a href="../poliv/index.php">Полив</a></li>
				<li><a href="../climat/index.php">Климат</a></li>
				<li><a href="../sensors/index.php">Датчики</a></li>
				<li><a href="../settings/index.php">Настройки</a></li>
				<li><a class="active" href="../log_poliva/index.php">Журнал полива</a></li>
				<li><a href="../log_domoticz/index.php">Лог системы</a></li>

			</ul>



		</div>

		<!-- Информационная панель - отображение данных лога -->
		<div class="item item_2">

			<script type="text/javascript">
				$(document).ready(function() {
					var func = function() {
						$("#info").load('../log/log.php');
					}
					setInterval(func, 2000);

				});

			</script>


			<div id="info">
				<?php include('../log/log.php'); ?>

			</div>
		</div>






		<div class="log_poliva">


			<?php
$file_path = "/var/www/html/log/log_watering";

if (file_exists($file_path)) {
  $file_contents = file_get_contents($file_path);
  $lines = array_reverse(explode("\n", $file_contents));

  // Параметры пагинации
  if ($_GET['count_srt'] == ''){$items_per_page = 20;}
    else
    {$items_per_page = $_GET['count_srt']; } // Количество строк на одной странице
    
  $total_items = count($lines); // Общее количество строк
  $total_pages = ceil($total_items / $items_per_page); // Общее количество страниц

  // Определение текущей страницы
  $current_page = isset($_GET['page']) ? $_GET['page'] : 1;
  if ($current_page < 1) $current_page = 1;
  elseif ($current_page > $total_pages) $current_page = $total_pages;
  
  // Вычисление индексов начала и конца строк для текущей страницы
  $start_index = ($current_page - 1) * $items_per_page;
  $end_index = min($start_index + $items_per_page, $total_items);
 
	//Очистка лога
  if (isset($_POST['clear_log']))
	 {
		$command = 'echo -n > /var/www/html/log/log_watering';
		shell_exec($command);
	  	$lines = '';
	 }  

  echo '<div class="btn-group" align-items: center;">
		<form  method="POST" action="index.php" >
		<button class="button" name="clear_log" id="clear_log" type="submit" onclick="return confirm(\'Вы уверены, что хотите очистить Журнал?\')"  >Очистить журнал</button>
	</form>';
                // Вывод пагинации
              if ($current_page > 1) {
                echo "<a class=\"btn_pag\"  href=\"?page=1&count_srt=".$items_per_page."   \">Первая</a> ";
                echo "<a class=\"btn_pag\" href=\"?page=" . ($current_page - 1) . "&count_srt=".$items_per_page."\">Предыдущая</a> ";
              }
              echo "<span class=\"btn_pag\"> Страница $current_page из $total_pages</span>";
              if ($current_page < $total_pages) {
                echo "<a class=\"btn_pag\" href=\"?page=" . ($current_page + 1) . "&count_srt=".$items_per_page."\">Следующая</a> ";
                echo "<a class=\"btn_pag\" href=\"?page=$total_pages&count_srt=$items_per_page\">Последняя</a> ";
              }
             
            } else {
              echo "Файл не существует.";
            }
    echo '
    <form  method="GET" action="index.php" >  
    <input class="input_s" value="'.$items_per_page.'" type="text" name="count_srt" />  
    <input class="btn_pag" value="Записей на страницу:" type="submit" name="sb_btn" /> 
    </form>';
  
	echo '</div>';
    		

    
   echo "<table>";


  // Вывод строк для текущей страницы
   
  if ($start_index == 0){$end_index = $end_index+1;}

  for ($i = $start_index; $i < $end_index; $i++) {
    $line = $lines[$i];
    $data = explode(" ", $line);

    $time = $data[0];
    
    if ($tmp == $time) {$time = ''; }
    if ($time != '') {$tmp = $time; }
    
    
    // Получение данных из строки после времени
    $data_text = implode(" ", array_slice($data, 1)); // объединяем элементы массива, начиная со второго
    
     if ($data_text != '')
     {
    echo '<tr>';

    echo "<td>" . $time . "</td>";
	if (strpos($data_text, "Система перезагружена!") !== false or strpos($data_text, "Критическое количество ошибок!") !== false) {
    	echo "<td><span class=\"red\">" . $data_text . "</span></td>";
	}
	else {
    	echo "<td>" . $data_text . "</td>";
	}
    echo "</tr>";
     }
                      
  }

  echo "</table>";

    

?>




		</div>

</body>



</html>
