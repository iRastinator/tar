<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8" />
	<title>Rastinator</title>
	<script type="text/javascript" src="/ajax/jquery-3.7.0.min.js"></script>
	<style>
		@import "../style.css"screen;
		/* Стиль для вывода результата на монитор */


		* {
			padding: 0%;
			margin: 0%;
		}

		.container {
			grid-template-columns: clamp(11rem, 5.909rem + 25.45vw, 25rem) clamp(6.25rem, 2.841rem + 17.05vw, 15.625rem) clamp(2.5rem, -1.136rem + 18.18vw, 12.5rem) auto;
			display: grid;
		}

		.item {

			padding: 0px;
			border: 0px solid black;

		}

		.item_1 {
			grid-column-start: 1;
			grid-column-end: 5;
		}

		.item_2 {
			grid-column-start: 1;
			grid-column-end: 5;
		}

		.item_4 {
			grid-row-start: 3;

			grid-column-start: 1;
			grid-column-end: 5;
		}

		.item_3 {

			grid-row-start: 4;
			grid-row-end: 150;
			padding-top: 3px;
			padding-right: 1px;
		}

		.zatichka {
			grid-row-start: 150;
			grid-row-end: 150;

		}

		@media (max-width: 1000px) {
			.container {
				grid-template-columns: 1px clamp(6.25rem, 2.841rem + 17.05vw, 15.625rem) clamp(2.5rem, -1.136rem + 18.18vw, 12.5rem) auto;
				display: grid;
			}

			.zatichka {
				grid-row-start: 5;
				grid-row-end: 150;

			}

			.item_3 {
				grid-row-start: 4;
				grid-row-end: 4;
				grid-column-start: 1;
				grid-column-end: 5;

				padding-top: 3px;
				padding-right: 1px;
			}




		}

	</style>

</head>

<body>



	<?php
//Авторизация
include('../login/in.php');    
    
function debug_to_console($data) {
    $output = $data;
    if (is_array($output))
        $output = implode(',', $output);
    echo "<script>console.log('Debug Objects: " . $output . "' );</script>";
}    
?>



	<div class="container">
		<div class="zatichka"></div>

		<!-- Верхнее меню -->
		<div class="item item_1">
			<ul>
				<li><svg width="clamp(6.25rem, 3.977rem + 11.36vw, 12.5rem)" height="clamp(1.4rem, 0.369rem + 2.84vw, 2.5rem)" viewBox="150 -30 180 180"> <?php include('../pic/Rastinator.svg'); ?> </svg> </li>
				<li><a class="active">Полив</a></li>
				<li><a href="../climat/index.php">Климат</a></li>
				<li><a href="../sensors/index.php">Датчики</a></li>
				<li><a href="../settings/index.php">Настройки</a></li>
				<li><a href="../log_poliva/index.php">Журнал полива</a></li>
				<li><a href="../log_domoticz/index.php">Журнал системы</a></li>
			</ul>



		</div>

		<!-- Информационная панель - отображение данных лога -->
		<div class="item item_2">

			<script type="text/javascript">
				$(document).ready(function() {
					var func = function() {
						$("#info").load('../log/log.php');
					}
					setInterval(func, 2000);

				});

			</script>


			<div id="info">
				<?php include('../log/log.php'); ?>

			</div>
		</div>


		<!-- Select с названиями файлов -->
		<div class="item item_3">



			<form id="myform" method="POST" action="index.php">




				<?php  // Заполнение Селекта названиями


    $var = $_POST['rast'];   

    $path = "/home/pi/domoticz/scripts/lua/";

    $des = '';

    $files = glob($path . "*plant*");
	$x = count($files)+2;

    $temp_m = array(); // Массив для скриптов полива
    $temp_add = array(); // Массив для сервисных скриптов   
    $temp_add2 = array(); // Массив для отключенных скриптов

    if($handle = opendir($path))
        {
             $count = 0;

             function to_min($seconds) {
             $t = round($seconds);
             //return sprintf('%02d:%02d:%02d', ($t/3600),($t/60%60), $t%60);
             return sprintf('%02d:%02d', ($t/60), $t%60);
             }


        // Загрузка имен файлов в массив где ключи это  set_Shift_time_watering в этом файле, далее сортирровка по Сдвигу по времени(et_Shift_time_watering) 

        while($entry = readdir($handle))
             {

                if ( substr($entry , 0 , 17) == 'script_time_plant' )
                  {
                    //grep ^set_Shift_time_watering script_time_plant_.lua | grep -o '[0-9]*'
                    $comand = "grep ^set_Shift_time_watering ".$path.$entry." | grep -o '[0-9]*'";
                    $output = shell_exec($comand);
                    $output = trim($output);  

                   //grep -Po '^sets_Canal_out\s+=\s+"\K[^"]+' script_time_plant_.lua
                    $comand = " grep -Po '^sets_Canal_out\s+=\s+".'"'.'\K[^"]+'."'".'   '.$path.$entry;
                    $output2 = shell_exec($comand);
                    $output2 = trim($output2);
                    // Если сервисный режим    
                    if ($output2 !=='') 
                          {$temp_add[$entry] = $output;}
                     else { $temp_m[$entry] = $output; }   


                    }

                    if ( substr($entry , 0 , 9) == 'off_plant' )
                       {
                        $temp_add2[$entry] = $output;
                        }


            }
        $sep1['----1'] = "----1"; 
        $sep2['----2'] = "----2"; 
        asort($temp_m); 
        asort($temp_add);

        if (empty($temp_add)==false and empty($temp_m)==false ){$temp_m = array_merge($temp_m, $sep1 );}
        $temp_m = array_merge($temp_m, $temp_add );
        if (empty($temp_add2)==false and empty($temp_m)==false){$temp_m = array_merge($temp_m, $sep2 );}
        $temp_m = array_merge($temp_m, $temp_add2 );

        //var_dump($temp_m);

    echo'<select  class="main" size="'.$x.'" name="rast" id="select_rast" onchange="this.form.submit()";>'; 


        foreach ($temp_m as  $entry => $value)
         {
                if ( substr($entry , 0 , 4) == '----')
                {
                 echo '<option style="color:lightgray" disabled>──────────────────────────────────────────────────────────</option>';
                }   



                if ( substr($entry , 0 , 17) == 'script_time_plant')
                {


                    $count = $count + 1;
                     //echo "<a href=action.php?var=$entry >$entry</a><br>";
                    $name = substr($entry , 18 , -4); 

                          //grep -Po '^sets_Canal\s+=\s+"\K[^"]+' script_time_plant_.lua
                            $comand = " grep -Po '^sets_Canal\s+=\s+".'"'.'\K[^"]+'."'".'   '.$path.$entry;
                            $output = shell_exec($comand);
                            $output = trim($output);
                            // 
                            //$output = str_repeat('&nbsp;', 24- iconv_strlen($name)).$output;

                        //grep ^set_Shift_time_watering script_time_plant_.lua | grep -o '[0-9]*'
                            $comand = "grep ^set_Shift_time_watering ".$path.$entry." | grep -o '[0-9]*'";
                            $output2 = shell_exec($comand);
                            $output2 = trim($output2);

                        //grep ^set_Time_fertilize script_time_plant_.lua | grep -o '[0-9]*'
                            $comand = "grep ^set_Time_fertilize ".$path.$entry." | grep -o '[0-9]*'";
                            $output3 = shell_exec($comand);
                            $output3 = trim($output3);

                        //grep ^set_Time_clear_water script_time_plant_.lua | grep -o '[0-9]*'
                            $comand = "grep ^set_Time_clear_water ".$path.$entry." | grep -o '[0-9]*'";
                            $output4 = shell_exec($comand);
                            $output4 = trim($output4);

                        //grep ^set_set_Quota script_time_plant_.lua | grep -o '[0-9]*'
                            $comand = "grep ^set_Quota ".$path.$entry." | grep -o '[0-9]*'";
                            $output5 = shell_exec($comand);
                            $output5 = trim($output5);


                          //Время полного полива
                        $output4= $output2*60 + ($output3+$output4)*$output5;
                        // Длина времени 
                        $len_str = iconv_strlen(to_min($output2*60).'-'.to_min($output4));

                        // Tc
                        $output = str_repeat('&nbsp;', 35 - ($len_str + iconv_strlen($name))).$output;

                        //grep -Po '^sets_Canal_out\s+=\s+"\K[^"]+' script_time_plant_.lua
                            $comand = " grep -Po '^sets_Canal_out\s+=\s+".'"'.'\K[^"]+'."'".'   '.$path.$entry;
                            $output6 = shell_exec($comand);
                            $output6 = trim($output6);
                    // Если включен сервисный режим
                            if ($output6 !=='') 
                            {
                                //grep ^set_Time_drain script_time_plant_.lua | grep -o '[0-9]*'
                                $comand = "grep ^set_Time_drain ".$path.$entry." | grep -o '[0-9]*'";
                                $output4 = shell_exec($comand);
                                $output4 = trim($output4);
                                $output4 = $output4 + $output2*60;

                                $output = str_repeat('&nbsp;', 30 - ($len_str + iconv_strlen($name))).'Слив:'.$output6;

                            }


                    // Если список грузится первый раз - выбор первого элемента 
                    if ($var == null and $count == 1) { 
                        echo '<option selected value='.$entry.'>'.to_min($output2*60).'-'.to_min($output4).'&nbsp;'.$name.$output.'</option>';}

                    // Если список грузится первый раз - загрузка последующих элементов
                    if ($var == null and $count !== 1) {                      
                        echo '<option  value='.$entry.'>'.to_min($output2*60).'-'.to_min($output4).'&nbsp;'.$name.$output.'</option>';}


                    // Если список грузится не первый раз - выбор загружаемого элемента
                    if ($var == $entry)   
                       { 
                        echo '<option selected value='.$entry.'>'.to_min($output2*60).'-'.to_min($output4).'&nbsp;'.$name.$output.'</option>';}

                    // Если список грузится не первый раз - загрузка последующих элементов  
                    elseif ($var !== null and $var !=='') 
                     {                      
                        echo '<option  value='.$entry.'>'.to_min($output2*60).'-'.to_min($output4).'&nbsp;'.$name.$output.'</option>';}




                  }

             //Отключенные скрипты 
            if ( substr($entry , 0 , 9) == 'off_plant')
                 {

                        $count = $count + 1;
                        $name = substr($entry , 10 , -4); 
                        $len = strlen(trim($name));

                        // Если список грузится первый раз - выбор первого элемента 
                        if ($var == null and $count == 1) 
                        { echo '<option style="color:gray" selected value='.$entry.'>'.$name.' - Отключен</option>';}

                        // Если список грузится первый раз - загрузка последующих элементов
                        if ($var == null and $count !== 1)
                        { echo '<option style="color:gray" value='.$entry.'>'.$name.' - Отключен</option>'; }

                        // Если список грузится не первый раз - выбор загружаемого элемента
                        if ($var == $entry)   
                        { echo '<option style="color:gray" selected value='.$entry.'>'.$name.' - Отключен</option>';}

                        // Если список грузится первый раз - загрузка последующих элементов  
                        elseif ($var !== null and $var !=='') 
                         { echo '<option style="color:gray" value='.$entry.'>'.$name.' - Отключен</option>';} 



                  }




          }



            // Маркер для кнопки удалить - отключает кнопку если последний элемент
            if ($count == 1) {$des = 'disabled';} 


        }closedir($handle);



     ?>

				</select>
				<script>
					var select = document.getElementById("select_rast");

					// Выделение опций селекта по совподающим каналам    
					var optionGroups = {};

					for (var i = 0; i < select.options.length; i++) {
						var option = select.options[i];
						var regex = /ch(\d-\d)/;
						var substring = option.textContent.match(regex);

						if (substring) {
							var key = substring[1];

							if (key in optionGroups) {
								optionGroups[key].push(option);
							} else {
								optionGroups[key] = [option];
							}
						}
					}

					for (var key in optionGroups) {
						var options = optionGroups[key];

						if (options.length > 1) {
							options.forEach(function(option) {
								option.classList.add("red");
							});
						}
					}



					// Выделение опций селекта по совподающему времени
					var options = select.options;

					for (var i = 0; i < options.length - 1; i++) {
						var currentOption = options[i];
						var nextOption = options[i + 1];

						var currentText = currentOption.textContent;
						var nextText = nextOption.textContent;

						var currentNumbersMatch = currentText.match(/\d+:\d+-\d+:\d+/);
						var nextNumbersMatch = nextText.match(/\d+:\d+-\d+:\d+/);

						if (currentNumbersMatch && nextNumbersMatch) {
							var currentNumbers = currentNumbersMatch[0].split("-");
							var nextNumbers = nextNumbersMatch[0].split("-");

							var currentNumberA = parseInt(currentNumbers[0].replace(":", ""));
							var currentNumberC = parseInt(currentNumbers[1].replace(":", ""));
							var nextNumberA = parseInt(nextNumbers[0].replace(":", ""));
							var nextNumberB = parseInt(nextNumbers[1].replace(":", ""));

							if (currentNumberC > nextNumberA || (currentNumberC === nextNumberA && currentNumberD >= nextNumberB)) {
								currentOption.classList.add("red");
								nextOption.classList.add("red");
							}
						}
					}

				</script>
			</form>




		</div>

		<!-- item item_4 - Кнопки включить отключить удалить Запустить остановить -  ---------->
		<div class="item item_4">


			<div class="btn-group">
				<form id="delform" method="POST" action="del_file.php">

					<button class="button" name="del" value="" type="submit" onclick="return confirm('Вы уверены, что хотите Удалить Профиль Растения? ?')" <?php echo $des; ?>>Удалить</button>

					<button class="button" name="otkl" value="" type="submit">Отключить</button>

					<button class="button" name="vkl" value="" type="submit">Включить</button>


					<?php  //Кнопки Удалить Отключить Включить

        $file = $_POST['rast'];  

        // Определяем файл для загрузки если в первый раз
        if ($file == '')
        {

            $path = "/home/pi/domoticz/scripts/lua/";
                    // определение первого файла в директории                                       
                    if ($file == null) // Если список грузится первый раз - определения первого файла в директории 
                    {$file = array_key_first($temp_m); }

            echo '<input  name="del_file"  value='.$file.' type="hidden" >'; //type="hidden"
        }                                           
        else 
        {
            echo '<input  name="del_file"  value='.$file.' type="hidden" >';//type="hidden"

        }      

        ?>

				</form>






				<form id="myform2" method="POST" action="save_file.php">


					<?php  // 

        //var_dump($_POST); echo '</br>';
        //exit();    

        $var = $_POST['rast'];
        $set = $_POST['set'];

        $path = "/home/pi/domoticz/scripts/lua/";

        // Если список грузится первый раз - определения первого файла в директории                                            
        if ($var == null) 
        {$var = array_key_first($temp_m); }


        if ($set !== null) { $var = $set; } 

        $filename = $path.''.$var;
        $Name = '';
        $flag = 'false';

        //Название растения - если с OFF - имя длиннее на 4 сивола
        if (substr($var, 0,4) ==  "off_"){
            $Name =  substr($var , 10 , strlen(trim($var))-14);
            $flag = 'disabled';
            }
        else{
            $Name =  substr($var , 18 , strlen(trim($var))-22);  }



    
       echo '<input class="button" type="submit" name="run_script" value="Запустить полив" '.$flag.'>';
       echo '<input class="button" type="submit" name="stop_script" value="Остановить полив" '.$flag.'>';
       echo '<input class="button" type="submit" name="new_porfile" value="Сохранить новый профиль">';   
       echo '<input class="button" type="submit" name="save_changes" value="Сохранить изменения">';

    
        echo '</div>'; 
        
        ?>
					<div class="separation_div"> </div>


			</div>


			<!-- Отображение загруженных настроек в инпуты ---------->

			<!-- Кнопки выбора режимов ---------->
			<input class="input_1" value="Режим рабрты">

			<div class="div_mode">
				<input class="button_cell" name="schedule_watering" value="Полив по расписанию">
				<input class="button_cell" name="sensor_watering" value="Полив по датчику">
				<input class="button_cell" name="service_drain" value="Режим слива">
			</div>

			<script>
				// Режим по расписанию
				document.querySelector('.button_cell[name="schedule_watering"]').addEventListener('click', function() {
					if (confirm('Переключение на режим "Полив по расписанию". Настройка "Полив по расписанию" будет изменена! Проверте установки после переключения на новый режим!')) {
						document.querySelector('[name="setm_Hour_watering"]').value = "12";
						document.querySelector('[name="setm_Sens_id"]').value = "";
						document.querySelector('[name="sets_Canal_out"]').value = "";
						document.querySelector('[name="save_changes"]').click();
					}
				});

				document.querySelector('.button_cell[name="sensor_watering"]').addEventListener('click', function() {
					if (confirm('Переключение на режим "Полив по датчику влажности". Настройка "Датчики влажности ID" будет изменена! Проверте установки после переключения на новый режим!')) {
						document.querySelector('[name="sets_Canal_out"]').value = "";
						document.querySelector('[name="setm_Hour_watering"]').value = "";
						document.querySelector('[name="save_changes"]').click();
					 }
				});

				document.querySelector('.button_cell[name="service_drain"]').addEventListener('click', function() {
					if (confirm('Переключение на "Режим cлива"! Настройка "Канал слива" будет изменена! Проверте установки после переключения на новый режим!')) {
						document.querySelector('[name="sets_Canal_out"]').value = "ch";
						document.querySelector('[name="save_changes"]').click();
					}
				});

				
				
				//При загрузке страницы убираем инпуты для других режим
				document.addEventListener('DOMContentLoaded', function() {
				  var setm_Sens_id = document.querySelector('[name="setm_Sens_id"]').value;
				  var sets_Canal_out = document.querySelector('[name="sets_Canal_out"]').value;
				  var setm_Hour_watering = document.querySelector('[name="setm_Hour_watering"]').value;
					
					// Режим по датчикам влажности
					if (setm_Hour_watering === "" && sets_Canal_out === ''){
						document.querySelector('[name="setm_Sens_id"]').style.backgroundColor = '#DAD5C0';
						document.querySelector('[name="sensor_watering"]').style.backgroundColor = 'salmon';
						document.querySelector('[name="sensor_watering"]').disabled = true;
						
						document.querySelector('[name="label_setm_Hour_watering"]').style.display = 'none';
						document.querySelector('[name="setm_Hour_watering"]').style.display = 'none';
						document.querySelector('[name="info_setm_Hour_watering"]').style.display = 'none';

							//Канал слива
						document.querySelector('[name="label_sets_Canal_out"]').style.display = 'none';
						document.querySelector('[name="sets_Canal_out"]').style.display = 'none';
						document.querySelector('[name="info_sets_Canal_out"]').style.display = 'none';
							//Время слива
						document.querySelector('[name="label_set_Time_drain"]').style.display = 'none';
						document.querySelector('[name="set_Time_drain"]').style.display = 'none';
						document.querySelector('[name="info_set_Time_drain"]').style.display = 'none';
							//ID Датчики слива
						document.querySelector('[name="label_setm_Sens_out_id"]').style.display = 'none';
						document.querySelector('[name="setm_Sens_out_id"]').style.display = 'none';
						document.querySelector('[name="info_setm_Sens_out_id"]').style.display = 'none';  
			

						
						}
					
				   // Режим по расписанию
					if (setm_Hour_watering !== "" && sets_Canal_out === '') { 
						document.querySelector('[name="schedule_watering"]').style.backgroundColor = 'salmon';
						document.querySelector('[name="schedule_watering"]').disabled = true;
						document.querySelector('[name="setm_Hour_watering"]').style.backgroundColor = '#DAD5C0';	

						// Датчики влажности ID  
						document.querySelector('[name="label_setm_Sens_id"]').style.display = 'none';
						document.querySelector('[name="setm_Sens_id"]').style.display = 'none';
						document.querySelector('[name="info_setm_Sens_id"]').style.display = 'none';
						  //Уровень влажности полива
						document.querySelector('[name="label_set_Water_level"]').style.display = 'none';
						document.querySelector('[name="set_Water_level"]').style.display = 'none';
						document.querySelector('[name="info_set_Water_level"]').style.display = 'none'; 
						 //Период полива по датчикам 				  
						document.querySelector('[name="label_set_Period"]').style.display = 'none';
						document.querySelector('[name="set_Period"]').style.display = 'none';
						document.querySelector('[name="info_set_Period"]').style.display = 'none';


						//Канал слива
						document.querySelector('[name="label_sets_Canal_out"]').style.display = 'none';
						document.querySelector('[name="sets_Canal_out"]').style.display = 'none';
						document.querySelector('[name="info_sets_Canal_out"]').style.display = 'none';
							//Время слива
						document.querySelector('[name="label_set_Time_drain"]').style.display = 'none';
						document.querySelector('[name="set_Time_drain"]').style.display = 'none';
						document.querySelector('[name="info_set_Time_drain"]').style.display = 'none';
							//ID Датчики слива
						document.querySelector('[name="label_setm_Sens_out_id"]').style.display = 'none';
						document.querySelector('[name="setm_Sens_out_id"]').style.display = 'none';
						document.querySelector('[name="info_setm_Sens_out_id"]').style.display = 'none';  
				
					  
				    }
					
				// Если режим слива	
				if (sets_Canal_out !== ""){
					document.querySelector('[name="sets_Canal_out"]').style.backgroundColor = '#DAD5C0';
					document.querySelector('[name="service_drain"]').style.backgroundColor = 'salmon';
					document.querySelector('[name="service_drain"]').disabled = true;
					document.querySelector('[name="setm_Sens_drainage_id"]').value = "";
				}	
					
					
				});

			</script>

			<div class="separation_div"> </div>
			<?php 


       //Информация - имя файла при загрузке  
       echo '<input  name="origen_file"  value='.$filename.' type="hidden" >'; // 
                                                      
                                                      
       echo '<input  class="input_1"  value="Растение или зона полива"> ';                 
      
    //Название растения
       echo '
       <input class="input_2"  name="Name_unit" id="Name_unit" type="text" value="'.$Name.'" title="Уникальное название!"   autocomplete="off"  onkeydown="if(event.keyCode==13){return false;}" >'
?>
			<script>
				Name_unit.addEventListener("keydown", function() {
					this.style.backgroundColor = "#B0F0B0";
					this.style.color = "black";
				})

				const inputField = document.getElementById('Name_unit');
				inputField.addEventListener('input', (event) => {
					const inputValue = event.target.value;
					const allowedInput = /^[A-Za-zА-Яа-я0-9-]+$/;
					if (!allowedInput.test(inputValue)) {
						event.target.value = inputValue.replace(/[^A-Za-zА-Яа-я0-9-]/g, '');
					}
				});

			</script>

			<?php           
            
        $file = fopen($filename, 'r');
    
    
    
        // Если сервисный режим и sets_Canal_out ="чемуто"
            $serv_mode = '';
            $contents = file_get_contents($filename); // Укажите здесь имя своего файла
            preg_match('/sets_Canal_out\s*=\s"([^"]*)"/', $contents, $matches);

            if (isset($matches[1]) && $matches[1] != '') {
                // Ваши действия здесь. Этот блок кода выполнится, если кавычки содержат ненулевое значение
                $serv_mode = 'type="hidden" ';
				$serv_mode2 = 'style="display: none;" ';
				
                
            } else {
                // Блок кода, который выполнится, если кавычки пусты
                $serv_mode = 'type="text"'; 
            }
    

    
        $ver = '';
        for ($i = 0; $i < 200; $i++) {
                
            $stroka = fgets($file);
            
            //Остовляем строки для сервесного режима

            $values = array('set_Shift_time_watering', 'sets_Canal_out' , 'set_Time_drain', 'setm_Sens_out_id', 'set_time_alarm', 'set_Shift_time_restart', 'sets_email');
            $ins_serv = $serv_mode;
            if ($serv_mode == 'type="hidden" ')
            {
                foreach ($values as $value) {

                    if (strpos($stroka, $value) !== false) {
                        $ins_serv = 'type="text"';
                    } 
                }
            }


            
            if (substr($stroka , 0, 12) == '--separation' ) //and $ins_serv == 'type="text"'
            {
                echo' <input type="hidden" name="separation'.$i.'" value="--separation'.$i.'">
                <div '.$serv_mode2.' class="separation_div"> </div>';      
            }
            
            if (substr($stroka , 0, 7) == '--info:')
            {
            echo '<input name="Name_unit_info" id="Name_unit_info" class="input_3" value="'.substr($stroka , 7, strlen($stroka)).'" autocomplete="off" onkeydown="if(event.keyCode==13){return false;}">
            <script>Name_unit_info.addEventListener("input", function(){this.style.backgroundColor = "#B0F0B0";this.style.color="black";})</script>'; 
            }
            
            $pos1      = strripos($stroka, 'label<');
            $pos2      = strripos($stroka, '>label');  
                            
            if ($pos1 == TRUE) // Если первый label< существует - всегда существет у всех установок
                {            
                    
                    $Label = substr($stroka , $pos1+6 , $pos2-$pos1-6);
                    $name =  substr($stroka , 0 , strripos($stroka, ' =')) ;
                
            // Создание Label       
                    echo'
                    <input   class="input_1" '.$ins_serv.' id="label_'.$Label.'" name="label_'.$name.'" value="'.$Label.'"   autocomplete="off" onkeydown="if(event.keyCode==13){return false;}" >                       
                        ';
                
                    
                
             // Позиция если значения в кавычках
                     if (substr($stroka , 0, 5) == 'sets_') 
                    {
                        $pos1 = strripos($stroka, '= "')+ 2 ;
                        $pos2 = strripos($stroka, '"')+ 5;
                     echo 
                       '
                      
                        <input  class="input_2" '.$ins_serv.' type="text" id="'.$name.'" name="'.$name.'"  value="'.trim(substr($stroka , $pos1+1 , $pos2-$pos1-1) ).'"  autocomplete="off" onkeydown="if(event.keyCode==13){return false;}">
                        <script>'.$name.'.addEventListener("keydown", function(){this.style.backgroundColor = "#B0F0B0";this.style.color="black";})
                                
                        </script> 
                        
                        ';
  
                        
                    }
                    
                
              // Если  массив данных
                     if (substr($stroka , 0, 5) == 'setm_')
                    {   
                    $pos1      = strripos($stroka, '{'); 
                    $pos2      = strripos($stroka, '}');
                        echo 
                       '
                             
                        <input  class="input_2" '.$ins_serv.' type="text" id="'.$name.'" name="'.$name.'"  value="'.trim(substr($stroka , $pos1+1 , $pos2-$pos1-1) ).'"  autocomplete="off" onkeydown="if(event.keyCode==13){return false;}" >
                        <script>'.$name.'.addEventListener("keydown", function(){this.style.backgroundColor = "#B0F0B0";this.style.color="black";})
                                
                        </script> 
                        
                        ';
                        
                        $script = "<script>";
                        $script .= "document.getElementById('$name').addEventListener('input', function() {";
                        $script .= "this.value = this.value.replace(/[^0-9.,\\s]+/g, '');";
                        $script .= "});";
                        $script .= "</script>";
                        // Выводим скрипт на страницу
                        echo $script;    
                    }
   
				
				
                // Если просто одно цифровое значение
                if (substr($stroka , 0, 4) == 'set_')
                    {
                        $pos1 = strripos($stroka, '=');
                        $pos2 = strripos($stroka, '--');
                        $str =  substr($stroka , $pos1+2 , $pos2-$pos1-3);
                        
                        $format = '';
                        if ($name == "set_dilution_ppm") {$format = 'step="0.1"';}
                        if ($name == "set_Day_option") {$format = 'step="1" min="0" max="1"';}    
                        
						$ins_serv2 = $ins_serv;
					    if ($ins_serv == 'type="text"'){$ins_serv2 = 'type="number"';} // Принудительно вкл.type="number"
					    
					
                        echo'
                        
                        <input class="input_2" id="'.$name.'_dig" name="'.$name.'" value="'.$str.'" autocomplete="off"
                        '.$ins_serv2.'   '.$format.'onkeydown="if(event.keyCode==13){return false;}"
                                                
                        > 
                        <script>'.$name.'_dig.addEventListener("input", function(){this.style.backgroundColor = "#B0F0B0";this.style.color="black";})</script>                         

                        ';
                        
                    }
				
                    
               // Добавление названиия 
                    $pos1  = strripos($stroka, 'info<');
                    $pos2  = strripos($stroka, '>info');
									
                    if ($pos1 !== FALSE) // Если info< существует
                    {
                        
                     
                        if (substr($name, 0,9) == "setm_Pump" )
                        {              
                        echo'
                        
                        <input  class="input_3" '.$ins_serv.'  id="'.$name.'_info" name="info_'.$name.'" id="'.$name.'_info" type="text" value="'.substr($stroka , $pos1+5 , $pos2-$pos1-5).'"  autocomplete="off" onkeydown="if(event.keyCode==13){return false;}" >
                        <script>'.$name.'_info.addEventListener("keydown", function(){this.style.backgroundColor = "#B0F0B0";this.style.color="black";})</script>                          

                        ';
                        }
                        else
                        {
                            if (substr($name, 0,3) == "set" )
                           {              
                            //readonly
                            echo'
                        
                            <input  class="input_3_readonly" id="'.$name.'_info" name="info_'.$name.'" '.$ins_serv.' type="text" value="'.substr($stroka , $pos1+5 , $pos2-$pos1-5).'" title="'.substr($stroka , $pos1+5 , $pos2-$pos1-5).'" onkeydown="if(event.keyCode==13){return false;}"  >
                         

                            ';
                           }  
                            
                
                        }
             
                        
                    }
         
                     if($ins_serv == 'type="text"')
					 {
					//echo '<br>';	 
					 }                  
                     
                    
                }
            

			
			
         if (strpos($stroka , 'Ver')) 
         {$ver = substr($stroka , strpos($stroka , 'Ver'), 20) ;}            
                
        }   
        fclose($file); 
        
         


        
        
?>





			<input type="hidden" name="cheсk" value="check"> <!--  Проверочный инпут в конце ------>

			</form>

			<div class="separation_div"> </div>

			<div style="color:grey;"> <?php echo $ver ?></div>






</body>

</html>
