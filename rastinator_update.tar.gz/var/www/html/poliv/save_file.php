            

<style>
	@import "../style.css" screen; /* Стиль для вывода результата на монитор */
    @import "../style.css" print, handheld; /* Стиль для печати и смартфона */

</style>                                    

<div style="Position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);">
	<?php include('../pic/process.svg'); ?> 
</div>

<?php
                                      
//echo '</br>_POST=';
//var_dump($_POST);
//echo '</br>Button=';
//var_dump(isset($_POST['run_script']));
//exit();
    //var_dump($_POST['Name_unit_info']); exit();
    
//var_dump($_POST);
//var_dump($_POST['Name_unit']); exit();

// Если произошел сбой при отправкие формы  и последний проверочный input отсутствует - то выход.
if($_POST["cheсk"] != "check") { exit();}

$filename=''; // Имя файла для отправки в index.php

function utf8_urldecode($str) 
    {$str = preg_replace("/%u([0-9a-f]{3,4})/i","&#x\\1;",urldecode($str));
     return html_entity_decode($str,null,'UTF-8');;
    }


// Если  кнопка запуск полива --------------------------------------------------------------------------------
if(isset($_POST['run_script'])) 
{ 
    $path = '/home/pi/domoticz/scripts/lua/';
    $filename = $path."script_time_plant_".$_POST[Name_unit].".lua"; 
    //echo 'Запуск: '.$filename ; echo '<br>';
   
    //Переименоваие  в device_режим 
    $comand = ' mv '.$filename.' '.$path."script_device_plant_".$_POST[Name_unit].".lua";
    //echo $comand ;
    $output = shell_exec($comand);    
    //sexit();
    
    //определение id кнопки Выборочный полив   
    $decod = json_encode(array(utf8_urldecode("Выборочный полив"))); 
    $add = str_replace ( "\\", "\\\\\\", $decod);
    $simb   = array("[", "]");
    $repl = str_replace ( $simb, "", $add);  
    $comand = 'curl "127.0.0.1:8080/json.htm?type=command&param=getlightswitches" | grep -C 3 '.$repl. ' | grep "idx"  '. "| awk '{print $3 }' " . '| sed '.'s/\"//g';
    $output = shell_exec($comand);
    $id  = trim($output);

    // Нажать кнопку - выборочный полив    
    $cmd = "curl '127.0.0.1:8080/json.htm?type=command&param=switchlight&idx=".$id."&switchcmd=On'";
    // echo $cmd ;
    $output = shell_exec($cmd);

    //Переименоваие файла обратно в time_режим
    $comand = ' mv '.$path."script_device_plant_".$_POST[Name_unit].".lua".' '.$filename;
    //echo $comand ;
    $output = shell_exec($comand);      

    $filename = "script_time_plant_".$_POST[Name_unit].".lua"; // Имя файла для отправки в index.php
    //exit();
}




//Остановить полив -----------------------------------------------------------------------------
if(isset($_POST['stop_script'])) 
{ 
    /*определение id кнопки Статус полива   
    $decod = json_encode(array(utf8_urldecode("Статус полива"))); 
    $add = str_replace ( "\\", "\\\\\\", $decod);
    $simb   = array("[", "]");
    $repl = str_replace ( $simb, "", $add);  
    $comand = 'curl "127.0.0.1:8080/json.htm?type=command&param=getlightswitches" | grep -C 3 '.$repl. ' | grep "idx"  '. "| awk '{print $3 }' " . '| sed '.'s/\"//g';
    $output = shell_exec($comand);
    $id  = trim($output);

    //выключаем Статус полива     
    $cmd = "curl '127.0.0.1:8080/json.htm?type=command&param=switchlight&idx=".$id."&switchcmd=Off'";
    $output = shell_exec($cmd);   
    //sleep(5);
    //Вкючаем Статус полива   
    $cmd = "curl '127.0.0.1:8080/json.htm?type=command&param=switchlight&idx=".$id."&switchcmd=On'";
    $output = shell_exec('sleep 3; '.$cmd); 
*/
	$comand = 'curl "127.0.0.1:8080/json.htm?type=command&param=updateuservariable&vname=Stop_flag&vtype=2&vvalue=-1"';
	$output = shell_exec($comand); 
	
    $filename = "script_time_plant_".$_POST[Name_unit].".lua";
}





// Если  сохранить изменения - удаляется старый файл и дальше генерится новой -----------------
// удаляем переменную для старого названия и создаем новую

if(isset($_POST['save_changes'])) 
{   
    
    $name_o = str_replace('/home/pi/domoticz/scripts/lua/script_time_plant_', '', $_POST['origen_file']);
       
   // Если скрипт выключен    
    if (substr( $_POST['origen_file'], 0 , 40) == '/home/pi/domoticz/scripts/lua/off_plant_') {
     $name_o = str_replace('/home/pi/domoticz/scripts/lua/off_plant_', '', $_POST['origen_file']);   
         }
     
    $name_o = str_replace ('.lua', '' , $name_o);

    
    //Удаление файла скрипта
    $comand = ' rm '.$_POST['origen_file'];
    //echo $comand; exit();
    $output = shell_exec($comand);


    // Если имя поменялось у профиля - поменять имя переменной пользователя    
    if ($name_o != $_POST[Name_unit]) 
    {

    //Удаление переменной пользователя Domoticz - начало
    $decod = json_encode(array(utf8_urldecode($name_o))); 
    $add = str_replace ( "\\", "\\\\\\", $decod);
    $simb   = array("[", "]");
    $repl = str_replace ( $simb, "", $add);

    //определение id переменной
    $comand = 'curl "127.0.0.1:8080/json.htm?type=command&param=getuservariables" | grep -C 3 '.$repl. ' | grep "idx"  '. "| awk '{print $3 }' " . '| sed '.'s/\"//g';
    $output = shell_exec($comand);
    $output = trim($output);

    // удаление переменной по id
    $comand = 'curl "127.0.0.1:8080/json.htm?type=command&param=deleteuservariable&idx='.$output.'"';
    //echo $comand;
    $output = shell_exec($comand);
    //echo $output;
    //Удаление переменной пользователя Domoticz - конец    

    //Создание новой переменной 
    $cmdd = "curl '127.0.0.1:8080/json.htm?type=command&param=adduservariable&vname=".$_POST[Name_unit]."&vtype=0&vvalue=1'";
    $output = shell_exec($cmdd);     
    //echo $output;   
 
}


    
    

}
    






// Создание нового файла профиля растения ------------------------------------------------------
$query_string = "";
$key = "";
$value = "";
if (isset($_POST['save_changes']) || isset($_POST['new_porfile'])) 
{  
       $set_value = array();
       $set_value_m = array();
       $set_value_s = array();
       $set_all = array();
       //$tmp = array();
       $label = array();
       $info = array();
    
        
    $filename = "script_time_plant_".$_POST[Name_unit].".lua";
    
    $name_o = str_replace('/home/pi/domoticz/scripts/lua/', '', $_POST['origen_file']); 
    

    
    if (substr($name_o,0,4) =='off_'){
        $filename = "off_plant_".$_POST[Name_unit].".lua";
    } 
    $fh = fopen("/home/pi/domoticz/scripts/lua/temp_".$filename, "w"); 
   
    fwrite($fh , 'commandArray = {}'."\r\n");
    fwrite($fh , '------------------------------------------------------------------------------'."\r\n");
    fwrite($fh , '------------------------------ Установки -------------------------------------'."\r\n");
    fwrite($fh , 'Name_unit = "'.$_POST[Name_unit].'"'."\r\n");

    //var_dump($_POST); exit();

       foreach ($_POST as $key => $value) 
       {

       // $set_value[] = "$key=$value";


         if(substr($key, 0, 4) == 'info'  ) {array_push($info[$key] = $value);}
         if(substr($key, 0, 6) == 'label_') {array_push($label[$key] = $value);}  
         if(substr($key, 0, 4) == 'set_'  ) {array_push($set_value[$key] = $value);}
         if(substr($key, 0, 5) == 'setm_' ) {array_push($set_value_m[$key] = $value);}
         if(substr($key, 0, 5) == 'sets_' ) {array_push($set_value_s[$key] = $value);}
           
         if(substr($key, 0, 3) == 'set'  ) {array_push($set_all[$key] = $value);}
         if(substr($key, 0, 10)  == 'separation'  ) {array_push($set_all[$key] = $value);}
         if(substr($key, 0, 14)  == 'Name_unit_info'  ) {array_push($set_all[$key] = $value);}
       }
       
    foreach ($set_all as $key => $value) 
       {
        
        
        if (substr($key, 0, 14)  == 'Name_unit_info')
            {
            fwrite($fh , '--info:'.$_POST['Name_unit_info']."\r\n");
            }
        
        if (substr($key, 0, 10)  == 'separation') 
            {
            fwrite($fh , '--separation'."\r\n");
            }
            
        if (substr($key, 0, 5) == 'setm_') 
            {
            fwrite($fh , $key);
            fwrite($fh , ' = {');
            fwrite($fh , trim($set_value_m[$key]));
            fwrite($fh , '}');    
        
            }
        if (substr($key, 0, 5) == 'sets_') 
            {
            fwrite($fh ,  $key);
            fwrite($fh , ' = "');
            fwrite($fh , trim($set_value_s[$key]));
            fwrite($fh , '"');    
        
            }
        if (substr($key, 0, 4) == 'set_') 
            {
            fwrite($fh , $key);
            fwrite($fh , ' = ');
            fwrite($fh , trim($set_value[$key]) );    
            }
        
        if (substr($key, 0, 3) == 'set')
        {
			//if (isset($_POST['set_rate_flora'])
			 //  {$key = 'id:'.$key.' id:'.(int)$key+1;}
				
            fwrite($fh , ' -- label<');
            fwrite($fh , trim($label["label_".$key]) ); 
            fwrite($fh , '>label ');

            fwrite($fh , 'info<');
            fwrite($fh , trim ($info["info_".$key]));
            fwrite($fh , '>info'."\r\n");
         }
    
              
      }
  
    

    //Присоединение програмной части
            $file2 = file_get_contents( "script_part_ras" );
            fwrite($fh , $file2);

    fclose($filename); 

    //Копирование финального файла
    $path1 = "/home/pi/domoticz/scripts/lua/temp_".$filename;
    $path2 = '/home/pi/domoticz/scripts/lua/'.$filename;
    $comand = ' mv '. $path1. ' '. $path2;
    $output = shell_exec($comand);
    //echo $comand;
    
    //Создание новой переменной пользователя
    $cmdd = "curl '127.0.0.1:8080/json.htm?type=command&param=adduservariable&vname=".$_POST[Name_unit]."&vtype=0&vvalue=1'";
    $output = shell_exec($cmdd);     
    //echo $output;       


}
else { $query_string = $_SERVER['QUERY_STRING'];}




 


 

// Эта форма отправляется автоматом после загрузки страницы
echo 
     '
<html>
<body onload="document.frm1.submit()">
   <form action="index.php" name="frm1" method="POST">
      <input type="hidden" name="rast" value='.$filename.' />
   </form>
</body>
</html>
' 




?>


