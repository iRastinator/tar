<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Rastinator</title>
<script type="text/javascript" src="/ajax/jquery-3.7.0.min.js"></script>
<style>
     @import "../style.css" screen; /* Стиль для вывода результата на монитор */
     @import "../style.css" print, handheld; /* Стиль для печати и смартфона */

     *{
        padding: 0%;
        margin: 0%;
      }
		.container {
			grid-template-columns: 400px 250px 200px auto;
			display: grid;
		}

		.item {

			padding: 0px;
			border: 0px solid black;

		}

		.item_1 {
			grid-column-start: 1;
			grid-column-end: 5;
		}

		.item_2 {
			grid-column-start: 1;
			grid-column-end: 5;
		}

		.item_4 {
			grid-row-start: 3;

			grid-column-start: 1;
			grid-column-end: 5;
		}

		.item_3 {
						
		grid-row-start: 4;
		grid-row-end: 150;	
			padding-top: 3px;
			padding-right: 1px;
		}

    
</style>      
          
</head>

<body>


<?php
//Авторизация
include('../login/in.php');    
    
function debug_to_console($data) {
    $output = $data;
    if (is_array($output))
        $output = implode(',', $output);
    echo "<script>console.log('Debug Objects: " . $output . "' );</script>";
}    
?>
    
    
    
<div class="container">
     
    
<!-- Верхнее меню -->     
<div class="item item_1">
        <ul>
          <li><p class="logo" >Rastinator</p></li>
          <li><a href="../poliv/index.php" >Полив</a></li>   
          <li><a class="active" >Климат</a></li>
          <li><a href="../sensors/index.php">Датчики</a></li>
          <li><a href="../settings/index.php">Настройки</a></li>
          <li><a href="../log_poliva/index.php">Журнал полива</a></li>
          <li><a href="../log_domoticz/index.php">Журнал системы</a></li>
          <!--  <li style="float:right"><a href="">Ver.13.08.2023</a></li>  -->
        </ul>  
    

    
</div>           

<!-- Информационная панель - отображение данных лога -->     
<div class="item item_2" >
                               
             <script type="text/javascript">        
                $(document).ready(function() 
                { 
                var func = function() {$("#info").load('../log/log.php');}
                setInterval(func, 2000);

                });

            </script>                                

    
            <div id="info" >
               <?php include('../log/log.php'); ?>
                
            </div> 
</div> 
    
 
<!-- Select с названиями файлов --> 
<div class="item item_3">                        
                        

    
<form id="myform" method="POST" action="index.php">
      

     
        
<?php  // Заполнение Селекта названиями

    
$var = $_POST['rast'];   
    
$path = "/home/pi/domoticz/scripts/lua/";
                                                     
$des = '';
    

$files = scandir($path); $x = count($files); //общее коллтчество файлов в директории

$temp_m = array(); // Массив для скриптов полива
$temp_add2 = array(); // Массив для отключенных скриптов
    
if($handle = opendir($path))
    {
         $count = 0;
        
         
    // Загрузка имен файлов в массив где ключи это  set_start_time в этом файле, далее сортирровка  по времени(set_start_time) 
  
    while($entry = readdir($handle))
         {
              
            if ( substr($entry , 0 , 18) == 'script_time_climat' )
              {

                $comand = "grep ^sets_start_time ".$path.$entry." | grep -Eo '[0-9]{2}:[0-9]{2}'";
                $output = shell_exec($comand);
                $output = trim($output);  

                $temp_m[$entry] = $output; 
        
                }
        
             if ( substr($entry , 0 , 10) == 'off_climat' )
                   {
                    $temp_add2[$entry] = "Название";
                    }
                
            
        }
    $sep1['----1'] = "----1"; 

    asort($temp_m); 
    
    if (empty($temp_add2)==false and empty($temp_m)==false)
    {$temp_m = array_merge($temp_m, $sep1 );}
    
    $temp_m = array_merge($temp_m, $temp_add2 );

    //var_dump($temp_m);

    echo'<select  class="main" size="'.$x.'" name="rast" id="select_rast" onchange="this.form.submit()";>'; 

        
    foreach ($temp_m as  $entry => $value)
     {
            if ( substr($entry , 0 , 4) == '----')
            {
             echo '<option style="color:lightgray" disabled>──────────────────────────────────────────────────────────</option>';
            }   
                

             
            if ( substr($entry , 0 , 18) == 'script_time_climat')
            {

                
                        $count = $count + 1;

                        $name = substr($entry , 19 , -4); 
 
                
                        $comand = " grep -Po '^sets_Canal_cooler\s+=\s+".'"'.'\K[^"]+'."'".'   '.$path.$entry;
                        $output = shell_exec($comand);
                        $output = trim($output); 
                      
                        
                        //Канал управления CO2
                        $comand = " grep -Po '^sets_Canal_Co2\s+=\s+".'"'.'\K[^"]+'."'".'   '.$path.$entry;
                        $out = shell_exec($comand);
                        $out = trim($out);  
                        if ($out != null) {$output = $out;}
                
                           
                        $comand = " grep -Po '^sets_Canal_hoter\s+=\s+".'"'.'\K[^"]+'."'".'   '.$path.$entry;
                        $output1 = shell_exec($comand);
                        $output1 = trim($output1);
                       
                          
                        $comand = "grep ^sets_start_time ".$path.$entry." | grep -Eo '[0-9]{2}:[0-9]{2}'";
                        $output2 = shell_exec($comand);
                        $output2 = trim($output2);
                        

             
                        $comand = "grep ^sets_stop_time ".$path.$entry." | grep -Eo '[0-9]{2}:[0-9]{2}'";
                        $output3 = shell_exec($comand);
                        $output3 = trim($output3);
                   
                    // Длина времени 
                    $len_str = iconv_strlen($output2.'-'.$output3);
                    
                    // Каналы
                    $output = str_repeat('&nbsp;', 29 - ($len_str + iconv_strlen($name))).$output.' '.$output1;
                


                        
                
                // Если список грузится первый раз - выбор первого элемента 
                if ($var == null and $count == 1) { 
                    echo '<option selected value='.$entry.'>'.$output2.'-'.$output3.'&nbsp;'.$name.$output.'</option>';}
                
                // Если список грузится первый раз - загрузка последующих элементов
                if ($var == null and $count !== 1) {                      
                    echo '<option value='.$entry.'>'.$output2.'-'.$output3.'&nbsp;'.$name.$output.'</option>';}
                            
                           
                // Если список грузится не первый раз - выбор загружаемого элемента
                if ($var == $entry)   
                   { 
                    echo '<option selected value='.$entry.'>'.$output2.'-'.$output3.'&nbsp;'.$name.$output.'</option>';}
                
                // Если список грузится не первый раз - загрузка последующих элементов  
                elseif ($var !== null and $var !=='') 
                 {                      
                    echo '<option value='.$entry.'>'.$output2.'-'.$output3.'&nbsp;'.$name.$output.'</option>';}

                
                
                
              }
        
         //Отключенные скрипты 
        
        
        
        if ( substr($entry , 0 , 10) == 'off_climat')
             { 
                
                    $count = $count + 1;
                    $name = substr($entry , 11 , -4); 
                    $len = strlen(trim($name));
              


                    // Если список грузится первый раз - выбор первого элемента 
                    if ($var == null and $count == 1) 
                    { echo '<option style="color:gray" selected value='.$entry.'>'.$name.' - Отключен</option>';}

                    // Если список грузится первый раз - загрузка последующих элементов
                    if ($var == null and $count !== 1)
                    { echo '<option style="color:gray" value='.$entry.'>'.$name.' - Отключен</option>'; }

                    // Если список грузится не первый раз - выбор загружаемого элемента
                    if ($var == $entry)   
                    { echo '<option style="color:gray" selected value='.$entry.'>'.$name.' - Отключен</option>';}

                    // Если список грузится первый раз - загрузка последующих элементов  
                    elseif ($var !== null and $var !=='') 
                     { echo '<option style="color:gray" value='.$entry.'>'.$name.' - Отключен</option>';} 

           
                
              }
        

        
            
      }
        

        
        // Маркер для кнопки удалить - отключает кнопку если последний элемент
        if ($count == 1) {$des = 'disabled';} 
        
        
    }closedir($handle);

    
    
 ?>
                                                                                                     
</select>
        <script>
            
        var select = document.getElementById("select_rast");
        
        // Выделение опций селекта по совподающим каналам    
        var optionGroups = {};

        for (var i = 0; i < select.options.length; i++) {
            var option = select.options[i];
            var regex = /ch(\d-\d)/;
            var substring = option.textContent.match(regex);

            if (substring) {
                var key = substring[1];

                if (key in optionGroups) {
                    optionGroups[key].push(option);
                } else {
                    optionGroups[key] = [option];
                }
            }
        }

        for (var key in optionGroups) {
            var options = optionGroups[key];

            if (options.length > 1) {
                options.forEach(function(option) {
                    option.classList.add("red");
                });
            }
        }
            
       
            

            
    </script>
</form>   
    

    
   

    
</div> 

<!-- item item_4 - Кнопки включить отключить удалить Запустить остановить -  ----------> 
<div class="item item_4">
    
    
<div class="btn-group">
    
    <form id="delform" method="POST" action="del_file.php">
        
    <button class="button" name="del" value="" type="submit" onclick="return confirm('Вы уверены, что хотите Удалить Профиль Растения? ?')" <?php echo $des; ?> >Удалить</button> 

    <button class="button" name="otkl" value="" type="submit"  >Отключить</button>  

    <button class="button" name="vkl" value="" type="submit" >Включить</button> 

    
        <?php  //Кнопки Удалить Отключить Включить

    $file = $_POST['rast'];  

    // Определяем файл для загрузки если в первый раз
    if ($file == '')
    {

        $path = "/home/pi/domoticz/scripts/lua/";
                // определение первого файла в директории                                       
                if ($file == null) // Если список грузится первый раз - определения первого файла в директории 
                {$file = array_key_first($temp_m); }

        echo '<input  name="del_file"  value='.$file.' type="hidden" >'; //type="hidden"
    }                                           
    else 
    {
        echo '<input  name="del_file"  value='.$file.' type="hidden" >';//type="hidden"

    }      


    ?>
    

    </form>

     
    
    
<form id="myform2" method="POST" action="save_file.php" >

                                                                                                    
<?php  // 

//var_dump($_POST); echo '</br>';
//exit();    
    

            $var= $_POST['rast'] ;
      
            $path = "/home/pi/domoticz/scripts/lua/";

            
    
            // Если список грузится первый раз - определения первого файла в директории
            if ($var == null)  
            {$var = array_key_first($temp_m); }
    
            $filename = $path.$var;
        
            
            
    
            $Name = '';
            $flag = 'false';
            
            //Название растения - если с OFF - имя длиннее на 4 сивола
            if (substr($var, 0,4) ==  "off_"){
                $Name =  substr($var , 11 , strlen(trim($var))-15);
                $flag = 'disabled';
                }
            else{
                $Name =  substr($var , 19 , strlen(trim($var))-23);  }
                
 
 
    
    

       echo '<input class="button" type="submit" name="new_porfile" value="Сохранить новый профиль">';   
       echo '<input class="button" type="submit" name="save_changes" value="Сохранить изменения">';

    
        echo '</div>'; 
        
        ?>
        
        <div class="separation_div">  </div>
        
</div> 

    
<!-- item item_5 - Отображение загруженных настроек в инпуты ---------->

<?php 


       //Информация - имя файла при загрузке  
       echo '<input  name="origen_file"  value='.$filename.' type="hidden" >'; //
       
                                                      
                                                      
       echo '<input  class="input_1" value="Контроль:"> ';                 
      
    //Название растения
       echo '
       <input class="input_2" name="Name_unit" id="Name_unit" type="text" value="'.$Name.'" title="Уникальное название!"   autocomplete="off"  onkeydown="if(event.keyCode==13){return false;}" >'
?>
        <script>
        Name_unit.addEventListener("keydown", function(){this.style.backgroundColor = "#B0F0B0";this.style.color="black";})
        
        const inputField = document.getElementById('Name_unit');
        inputField.addEventListener('input', (event) => {
        const inputValue = event.target.value;
        const allowedInput = /^[A-Za-zА-Яа-я0-9-]+$/;
        if (!allowedInput.test(inputValue)) {
        event.target.value = inputValue.replace(/[^A-Za-zА-Яа-я0-9-]/g, '');
        }
        });

        </script>
   
 <?php           
            
        $file = fopen($filename, 'r');
    
    
    

    
        $ver = '';
        for ($i = 0; $i < 200; $i++) {
                
            $stroka = fgets($file);
            

            $ins_serv = '"';
            
            if (substr($stroka , 0, 12) == '--separation'){
                echo' <input type="hidden" name="separation'.$i.'" value="--separation'.$i.'">
                <div class="separation_div"> </div>';      
            }
            
            if (substr($stroka , 0, 7) == '--info:'){
            echo '<input name="Name_unit_info" id="Name_unit_info" class="input_3" value="'.substr($stroka , 7, strlen($stroka)).'" autocomplete="off" onkeydown="if(event.keyCode==13){return false;}">
            <script>Name_unit_info.addEventListener("input", function(){this.style.backgroundColor = "#B0F0B0";this.style.color="black";})</script>'; 
            }
            
            $pos1      = strripos($stroka, 'label<');
            $pos2      = strripos($stroka, '>label');  
                            
            if ($pos1 == TRUE) // Если первый label< существует - всегда существет у всех установок
                {            
                    
                    $Label = substr($stroka , $pos1+6 , $pos2-$pos1-6);
                    $name =  substr($stroka , 0 , strripos($stroka, ' =')) ;
                
            // Создание Label       readonly   
                    echo'
                    <input  type="text"  class="input_1"  
 id="label_'.$Label.'" name="label_'.$name.'" value="'.$Label.'"   autocomplete="off" onkeydown="if(event.keyCode==13){return false;}" >                       
                        ';
                

                    $name =  substr($stroka , 0 , strripos($stroka, ' =')) ; 
                    
                
             // Позиция если значения в кавычках
                     if (substr($stroka , 0, 5) == 'sets_') 
                    {
                        $pos1 = strripos($stroka, '= "')+ 2 ;
                        $pos2 = strripos($stroka, '"')+ 2;
                    
                    $format = 'type="text"';
                         
                    if ($name == "sets_start_time" or $name == "sets_stop_time") 
                       {$format = 'type="time" format="HH:mm"';}
                    
                    if ($name == "sets_Canal_cooler" or $name == "sets_Canal_hoter")
                       {
                            $format = $format.' oninput="formatInput_'.$name.'()"';
                           echo '                        
                           <script>
                           //Формат ввода по шаблону --
                            function formatInput_'.$name.'() {
                            const inputField = document.getElementById("'.$name.'");
                            const inputValue = inputField.value.replaceAll(/[^1-7]/g, "");

                            const formattedValue = `ch${inputValue.substr(0, 1)}-${inputValue.substr(1, 1)}`;

                            inputField.value = formattedValue;
                            }
                             </script>
                            ';
                       
                        }
                    
                    echo 
                       '
                      
                        <input  class="input_2" '.$format.' id="'.$name.'" name="'.$name.'"  value="'.trim(substr($stroka , $pos1+1 , $pos2-$pos1-1) ).'  autocomplete="off" onkeydown="if(event.keyCode==13){return false;}">
                       
                        <script>
                        '.$name.'.addEventListener("keydown", function(){this.style.backgroundColor = "#B0F0B0";this.style.color="black";})
                                                
                        </script>
                        ';
                         
                         
                       

  
                        
                    }
                    
                
              // Если  массив данных
                     if (substr($stroka , 0, 5) == 'setm_')
                    {   
                    $pos1      = strripos($stroka, '{'); 
                    $pos2      = strripos($stroka, '}');
                        echo 
                       '
                             
                        <input  class="input_2" type="text" id="'.$name.'" name="'.$name.'"  value="'.trim(substr($stroka , $pos1+1 , $pos2-$pos1-1) ).'"  autocomplete="off" onkeydown="if(event.keyCode==13){return false;}" >
                        <script>'.$name.'.addEventListener("keydown", function(){this.style.backgroundColor = "#B0F0B0";this.style.color="black";})
                                
                        </script> 
                        
                        ';
                        
                        $script = "<script>";
                        $script .= "document.getElementById('$name').addEventListener('input', function() {";
                        $script .= "this.value = this.value.replace(/[^0-9.,\\s]+/g, '');";
                        $script .= "});";
                        $script .= "</script>";
                        // Выводим скрипт на страницу
                        echo $script;    
                    }
   
                // Если просто одно цифровое значение
                if (substr($stroka , 0, 4) == 'set_')
                    {
                        $pos1 = strripos($stroka, '=');
                        $pos2 = strripos($stroka, '--');
                        $str =  substr($stroka , $pos1+2 , $pos2-$pos1-3);
                        
                        $format = 'type="number"';

                
                        echo'
                        
                        <input class="input_2" 
                        id="'.$name.'_dig" name="'.$name.'" value="'.$str.'" autocomplete="off"
                         '.$format.'onkeydown="if(event.keyCode==13){return false;}"
                                                
                        > 
                        <script>'.$name.'_dig.addEventListener("input", function(){this.style.backgroundColor = "#B0F0B0";this.style.color="black";})</script>                         

                        ';
                    
                    }
                    
               // Добавление названиия 
                    $pos1  = strripos($stroka, 'info<');
                    $pos2  = strripos($stroka, '>info');
                    if ($pos1 !== FALSE) // Если info< существует
                    {
     
                            if (substr($name, 0,3) == "set" )
                           {              
                            //readonly
                            echo'
                            <input  class="input_3_readonly" id="'.$name.'_info" name="info_'.$name.'" type="text" value="'.substr($stroka , $pos1+5 , $pos2-$pos1-5).'" title="'.substr($stroka , $pos1+5 , $pos2-$pos1-5).'" onkeydown="if(event.keyCode==13){return false;}"  >
                         

                            ';
                           }  
                            

                        
                    }
                    
                    
                                       
                 
                    
                }
            
         if (strpos($stroka , 'Ver')) 
         {$ver = substr($stroka , strpos($stroka , 'Ver'), 20) ;}            
                
        }   
        fclose($file); 
        
         


        
        
?>    
    
    

    
    


    
<input type="hidden" name="cheсk" value="check"> <!--  Проверочный инпут в конце ------>

</form>    
    
</div>    

<div style="color: snow;"> <?php echo $ver ?></div>    


    
    
</body>
</html>