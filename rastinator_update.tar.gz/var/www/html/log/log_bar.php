

<?php 


	

	// Выбираем значение Stop_flag
	$curlCommand = 'curl "127.0.0.1:8080/json.htm?type=command&param=getuservariables" | jq \'.result[] | select(.Name=="Stop_flag") | .Value\' | tr -d \'"\' ';
	

    //echo shell_exec($curlCommand);
	$cmd = "sudo service domoticz status";
	$output = shell_exec($cmd);

	if (strpos($output, 'active (running)') !== false) 
	{
	  $value = shell_exec($curlCommand);
	  
	}

	else {$value = -1; }


	$status = trim($value) ;



	if ($status == '') {$status = '-1';}

	if($_GET['status'] == 'Off')
	{
	$comand = 'curl "127.0.0.1:8080/json.htm?type=command&param=updateuservariable&vname=Stop_flag&vtype=2&vvalue=-1"';
    $output = shell_exec($comand);
	}
	if($_GET['status'] == 'On')
	{
	$comand = 'curl "127.0.0.1:8080/json.htm?type=command&param=updateuservariable&vname=Stop_flag&vtype=2&vvalue=0"';
    $output = shell_exec($comand);
	}
    

?> 
    
  
    
<!----- индикатор и Часы -------->

<div id="div_serverMeter" >
    
<!----- кнопка Статус полива -------->

<a id="irrigationStatus" class="<?php 
    if($status !== '-1') { 
        echo 'stat_active'; 
    } else { 
        echo 'stat_not_active'; 
    } 
?>" href="#">
    Статус полива <?php if($status == '-1') { echo 'Off'; } else { echo 'On'; } ?>
</a>

	<script>
		document.getElementById('irrigationStatus').addEventListener('click', function(event) {
			event.preventDefault(); // Предотвратить переход по ссылке

			// Определяем новое состояние
			const newStatus = '<?php echo ($status == '-1') ? 'On' : 'Off'; ?>';

			// Отправляем AJAX-запрос
			const xhr = new XMLHttpRequest();
			xhr.open('GET', 'index.php?status=' + newStatus, true); // Запрос к index.php с новым статусом
			xhr.onload = function() {
				if (xhr.status === 200) {
					// Здесь можно обновить элемент или выполнить действия в зависимости от ответа сервера
					const response = JSON.parse(xhr.responseText);
					alert('Статус обновлен: ' + response.newStatus);

					// Изменяем текст и класс ссылки в зависимости от нового статуса
					document.getElementById('irrigationStatus').className = response.className;
					document.getElementById('irrigationStatus').innerText = 'Статус полива ' + (response.newStatus == 'On' ? 'Off' : 'On');
				} else {
					alert('Произошла ошибка: ' + xhr.status); // Обработка ошибки
				}
			};
			xhr.send();
		});
	</script>
<!----- кнопка Статус полива конец -------->

    

<body onload="updateMeter()"> <!-- Вызываем функцию при загрузке страницы -->
	
<?php
    // PHP-код для получения значения текущей секунды на сервере
    date_default_timezone_set('Europe/Moscow');
	$currentTime = date('s');
    $currentTime2 = date('H:i:s'); 
?>
    
    <meter id="serverMeter" value="<?php echo $currentTime; ?>" min="0" max="59"></meter> 
    <script>
	// Функция для обновления значения индикатора
    function updateMeter() {
      var meter = document.getElementById("serverMeter");
      var currentTime = new Date().getSeconds(); // Получаем текущую секунду на сервере
      meter.value = currentTime;
    }
    </script>
    
<?php 
		echo '<span class="clock">'.$currentTime2.'</span>'; 
?>
        
	
</div>
        
