<meta name = "viewport" content = "width=device-width, initial-scale=1">

<?php 


	

	// Выбираем значение Stop_flag
	$curlCommand = 'curl "127.0.0.1:8080/json.htm?type=command&param=getuservariables" | jq \'.result[] | select(.Name=="Stop_flag") | .Value\' | tr -d \'"\' ';
	
    //echo shell_exec($curlCommand);
	$cmd = "sudo service domoticz status &";
	$output = shell_exec($cmd);
	if (strpos($output, 'active (running)') !== false) 
	{
	  $value = shell_exec($curlCommand);
	}

	else {$value = -1;}


	$status = trim($value) ;

	//echo $status;
	if ($status == '') {$status = '-1';}

	if($_GET['status'] == 'Off')
	{
	$comand = 'curl "127.0.0.1:8080/json.htm?type=command&param=updateuservariable&vname=Stop_flag&vtype=2&vvalue=-1"';
    $output = shell_exec($comand);
	}
	if($_GET['status'] == 'On')
	{
	$comand = 'curl "127.0.0.1:8080/json.htm?type=command&param=updateuservariable&vname=Stop_flag&vtype=2&vvalue=0"';
    $output = shell_exec($comand);
	}
    

?> 
    
  
    
<!----- индикатор и Часы -------->

<div id="div_serverMeter" >
    
    <!----- кнопка Статус полива -------->
	<a  class="<?php 
			   if($status !== '-1') {echo 'stat_active';} 
			   else {echo 'stat_not_active';} 
			   ?>" href="index.php?status=<?php if($status == '-1') {echo 'On';} else {echo 'Off';} ?>" >Статус полива <?php if($status == '-1') {echo 'Off';}else{echo 'On';} ?> </a>

    <script>
    // Функция для обновления значения индикатора
    function updateMeter() {
      var meter = document.getElementById("serverMeter");
      var currentTime = new Date().getSeconds(); // Получаем текущую секунду на сервере
      meter.value = currentTime;
    }
    </script>

    <body onload="updateMeter()"> <!-- Вызываем функцию при загрузке страницы -->
    <?php
    // PHP-код для получения значения текущей секунды на сервере
    $currentTime = date('s');
    $currentTime2 = date('H:i:s'); 
    ?>
    
    <meter id="serverMeter" value="<?php echo $currentTime; ?>" min="0" max="59"></meter> 
    
    <?php 
		echo '<span class="clock">'.$currentTime2.'</span>'; 
		?>
        

</div>
        
