<meta name = "viewport" content = "width=device-width, initial-scale=1">

<?php 


	

	// Выбираем значение Stop_flag
	$curlCommand = 'curl "127.0.0.1:8080/json.htm?type=command&param=getuservariables" | jq \'.result[] | select(.Name=="Stop_flag") | .Value\' | tr -d \'"\' ';
	
    //echo shell_exec($curlCommand);
	$cmd = "sudo service domoticz status &";
	$output = shell_exec($cmd);
	if (strpos($output, 'active (running)') !== false) 
	{
	  $value = shell_exec($curlCommand);
	}

	else {$value = -1;}

	//echo $value;
// Выполнение команды и сохранение вывода в массив
//$value = array();
//exec($comand, $value, $return_var);

// Печать вывода
//echo "Output: " . implode("\n", $output) . "\n";

// Печать статуса выполнения команды
//echo "Return var: " . $return_var . "\n";
	//echo $comand;
	

	$status = trim($value) ;

	//echo $status;
	if ($status == '') {$status = '-1';}

	if($_GET['status'] == 'Off')
	{
	$comand = 'curl "127.0.0.1:8080/json.htm?type=command&param=updateuservariable&vname=Stop_flag&vtype=2&vvalue=-1"';
    $output = shell_exec($comand);
	}
	if($_GET['status'] == 'On')
	{
	$comand = 'curl "127.0.0.1:8080/json.htm?type=command&param=updateuservariable&vname=Stop_flag&vtype=2&vvalue=0"';
    $output = shell_exec($comand);
	}
    

    ?> 
    
  
    
<!----- индикатор и Часы -------->
<div id="div_serverMeter" >
    
    <!----- кнопка Статус полива -------->
	<a  class="<?php 
			   if($status !== '-1') {echo 'stat_active';} 
			   else {echo 'stat_not_active';} 
			   ?>" href="index.php?status=<?php if($status == '-1') {echo 'On';} else {echo 'Off';} ?>" >Статус полива <?php if($status == '-1') {echo 'Off';}else{echo 'On';} ?> </a>

    <script>
    // Функция для обновления значения индикатора
    function updateMeter() {
      var meter = document.getElementById("serverMeter");
      var currentTime = new Date().getSeconds(); // Получаем текущую секунду на сервере
      meter.value = currentTime;
    }
    </script>

    <body onload="updateMeter()"> <!-- Вызываем функцию при загрузке страницы -->
    <?php
    // PHP-код для получения значения текущей секунды на сервере
    $currentTime = date('s');
    $currentTime2 = date('H:i:s'); 
    ?>
    
    <meter id="serverMeter" value="<?php echo $currentTime; ?>" min="0" max="59"></meter> 
    
    <?php 
		echo '<span class="clock">'.$currentTime2.'</span>'; 
		?>
        

</div>
        
 
 

    
<?php
// Создаем массив с именами файлов скриптов климата для фильтрации лога по ним

$files = array();
$files_climat = array();        
$path = "/home/pi/domoticz/scripts/lua";
                                                                                                
    if($handle = opendir($path)) {
         $count = 0;
         while($entry = readdir($handle)){
            if ( substr($entry , 0 , 17) == 'script_time_plant' || substr($entry , 0 , 18) == 'script_time_climat'){
                
                $count = $count + 1;
                 //echo "<a href=action.php?var=$entry >$entry</a><br>";
                 $len = strlen(trim($name));
                 $files[] = substr($entry , 18 , $len-4);
            }
             
             if ( substr($entry , 0 , 18) == 'script_time_climat'){
                
                 $count = $count + 1;
                 $len = strlen(trim($name));
                 //$files[] = substr($entry , 19 , $len-4);
                 $files_climat[] = substr($entry , 19 , $len-4);
            } 

         }
      
        closedir($handle);
    }
     
    
    
    
// Создаем массив с названиями и с информацией из файла лога, затем сливаем в один - в релультате дублируемые записи уходят и затнем сравниваем с именами файлов из массива $files    

$comand = 'tail -n50 /tmp/domoticz.txt | cat -E &';// -E добовляет $ в конец строки
//разбиваем одну большую строку на массив строк
$arr = array();
$cmd = "sudo service domoticz status &";
$output = shell_exec($cmd);
	
if (strpos($output, 'active (running)') !== false) 
{
exec($comand, $arr, $return_var);
}


//print_r ($stroki);
//$arr = explode( '$' , $stroki); //Разбивка по строкам

$count = count($arr);
$narr1 = array();
$narr2 = array();
$warn = array();
$narr_climat1 = array();
$narr_climat2 = array();
$currentTime = date('i'); 
    	
for ($i = 0; $i < $count; $i++) 
{
    if (trim($arr[$i]) != '')
    {
		$str = trim($arr[$i]); 
		$str = substr($str, 0, -1); // Удаляем последний сивол $
		$time_file = substr($str , 14 , 2);								
        if ( $time_file == $currentTime ) //or (int)$time_file == (int)$currentTime-1 ) // берем строки на текущую минуту и на предыдущую
		{
             $str_all = substr($str , 11 , 5).substr($str , 37 , strlen($str));     //  
             $st =   trim(substr($str , 37 , strpos($str, "->")-37));
			 

            if (array_key_exists ($st, array_flip($files))) {   
             $narr1[]= $st;
             $narr2[]= $str_all;  
			
            }
             if (array_key_exists ($st, array_flip($files_climat))) {   
             $narr_climat1[]= $st;
             $narr_climat2[]= $str_all; 
		
            }
			
			
			$str = trim($arr[$i]);
			$str = substr($str, 0, -1); // Удаляем последний сивол $
			
		     if ( (strpos($str, "!!!") or strpos($str, "Error") ) and  strpos($str, "has been running for more than 10 seconds") == false and $time_file == $currentTime) 
			{ 		
			$str_all = substr($str , 11 , 5).substr($str , 37 , strlen($str));
			$st =   trim(substr($str , 37 , strpos($str, "->")-37));
			 $warn1[]= $st;
             $warn2[]= $str_all; 
			}
			
        }
		

    }
}




//$c1 = array_combine($narr1, $narr2);
//$c2= array_combine($narr_climat1, $narr_climat2);
//$c3= array_combine($warn1 , $warn2);

$c1 = $narr2;
$c2=  $narr_climat2;
$c3=  $warn2;


//var_dump($narr1) ;      
//echo '<br> <br>';

$tmpp = array();         
foreach (array_unique($c1) as $row) {
echo'<div class="div_item_log">';

	if (strpos($row, "НАЧАЛСЯ ПОЛИВ") || strpos($row, "Происходит полив!") || strpos($row, "ЗАКОНЧИЛСЯ ПОЛИВ") || strpos($row, "ПРОИСХОДИТ СЛИВ") || strpos($row, "ЗАКОНЧИЛСЯ СЛИВ") )
     {
      echo '<div class="marking">'.$row.'</div> </div>';  continue;   
     }
    
     if (strpos($row, "!!!"))
     {
      echo '<div class="marking_alarm">'.$row.'</div> </div>';  continue;   
     }
     
    echo '<div>'.$row.'</div> </div>';

}   
     
        
        
echo '<div class="info_sep"></div>';       
        
        

foreach (array_unique($c2) as $row) 
 {
echo '<div class="info_climat">';
    
	if (strpos($row, "!!!"))
     {
      echo '<div class="marking_alarm">'.$row.'</div>';    
     }

     else{
          echo $row;
         }
echo "</div>";  
 }       
       
        
        
$c3 = array_diff($c3, $c1, $c2); // удаляются повторяющиеся строки
	
foreach (array_unique($c3) as $row) {
     

      echo '<div class="marking_alarm">'.$row.'</div>';   

}   	
	
	
?>

    
    
    
    
    
    