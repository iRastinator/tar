commandArray = {}
------------------------------------------------------------------------------
------------------------------ Установки -------------------------------------
Name_unit = "Огурец"
setm_Pump_1 = {1.17} -- label<Дозировочный насос - 1>label info< Нитрат кальция [ Ca(NO3)2 ] N-7.45% CaO-13.5%>info
setm_Pump_2 = {0.34} -- label<Дозировочный насос - 2>label info< Нитрат калия [ KNO3 ] N-2.31%  K2O-7.82%>info
setm_Pump_3 = {1.13} -- label<Дозировочный насос - 3>label info< Cульфат магния  [ MgSO4 ] Mg-4.83%  S-3.84%>info
setm_Pump_4 = {1.15} -- label<Дозировочный насос - 4>label info< Монофосфат калия [ KH2PO4 ] P2O5-10%  K2O-6.6%>info
setm_Pump_5 = {1.00} -- label<Дозировочный насос - 5>label info< Аквамикс Fe-0.0384% Mn-0.0257% Zn-0.0053% Cu-0.0053% Ca-0.0257% В-0.0052% Мо-0.0013%>info
setm_Pump_6 = {0.00} -- label<Дозировочный насос - 6>label info< >info
setm_Pump_7 = {0.00} -- label<Дозировочный насос - 7>label info< >info
setm_Concentration = {9.00} -- label<Концентрация удобрений >label info< Концентрация удобрений>info
set_Day_option = 0 -- label<Опция День>label info<  '1' -  растягивает рецепт удобрения на день; 0 - рецепт удобрений меняется каждый полив на следующий>info
set_Time_fertilize = 200 -- label<Время в сек. от начала полива в течении которого вносятся удобрения>label info< >info
set_Time_clear_water = 30 -- label<Время полива>label info< >info
set_Quota = 1 -- label<Квота>label info< 000>info
set_Water_level = 17 -- label<Уровень влажности>label info< Порог данных датчика влажности для срабатывания полива>info
set_Periodl = 1 -- label<Периуд повтора попытки полива>label info< в часах от начала суток - один для всех растений  минимальный - 1 час>info
set_Shift_time_watering = 5 -- label<Сдвиг по времени>label info< в минутах - опеределяет начало полива>info
setm_Hour_watering = {10, 19} -- label<Часы полива в сутках>label info< - используется только для режима - без датчика влажности!>info
setm_Sens_id = {11} -- label<Датчики влажности>label info< Если датчиков несколько - для полива будет выбираться датчик с наименьшей влажностью если датчик не указан полив будет согласно установкам set_Periodl, set_Shift_time_watering и setm_Hour_watering без учета датчика влажности>info
sets_Canal = "ch1-6" -- label<Канал управления>label info< подключенный к клапану растения>info
sets_Canal_out = "" -- label<Сервисный режим работы скрипта>label info< -канал управления слива>info
set_Time_drain = 300 -- label<Сервисный режим работы скрипта>label info< время слива в секундах>info
setm_Sens_alarm_id = {} -- label<ID Датчики перелива>label info< Если влажность > 5 - полив не происходит и высылается сообщение. {} - не используется. В сервисном режиме ...>info
set_Temp_set = 20 -- label<Начальная температура коректировки>label info< Значение температуры от которой происходит корректеровка влажности полива >info
set_Temp_corection = 1 -- label<Температурный Коэфицент>label info< корректирующий заданную влажность в зависимости от температуры среды (при изменении температуры на 1 градус заданная влажность для полива меняется на set_Temp_corection)>info
set_Temp_stop_watering = 17 -- label<Температура прекращения полива>label info< >info
set_start_time_watering = 0 -- label<Час начала полива включительно>label info< (от 0 до 23)>info
set_stop_time_watering = 23 -- label<Час конца полива включительно>label info< (от 0 до 23)>info
set_Alarm_level_low = 8 -- label<Нижний уровень влажности>label info< при котором будет выслано сообщение с предупреждением>info
set_Alarm_level_high = 95 -- label<Верхний уровень влажности>label info< при котором будет выслано сообщение с предупреждением>info
set_time_alarm = 70 -- label<Время обновления дачиков влажности>label info< в минутах после которого данные дачика не используется и высылается сообщение с предупреждением>info
set_Shift_time_restart = 57 -- label<Сдвиг перезапуска>label info< Сдвиг по времени в минутах для перезапуска системы в случае превышения set_time_alarm у датчиков>info
set_division = 10 -- label<Делитель>label info< на сколько раз делиться ml удобрений при впрыске. - ТАКОЙ ЖЕ КАК ПРИ КАЛИБРОВКИ ДОЗИРОВОЧНЫХ НАСОСОВ!>info
sets_m_valve = "ch3-3" -- label<Канал главного клапана>label info< Канал подкюченный к главному клапану или насосу (одинаковый для всех)>info
sets_email = "rastinator.sad@gmail.com" -- label<Адрес электронной почты>label info< 000>info
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>x<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<--
-->>>>>>>>>>>>>>>>>>>>>>>>>>>> Программная часть <<<<<<<<<<<<<<<<<<<<<<<<<<<<<--
------------------------------ Ver. 11.06.23 (1)-----------------------------------
 

-- Отключение скрипта
if (otherdevices['Статус полива'] == 'Off') 
    then
    print (Name_unit .. '-> ПОЛИВ ВЫКЛЮЧЕН !!! ...........')
    return 
    end


m = os.date('%M')
sec = os.date('%S')
hr = os.date('%H')
day = os.date('%d')
vr = hr .. ':' .. m ..':' .. sec

set_time_alarm = set_time_alarm*60
hr_offset = math.floor(set_Shift_time_watering/60) 

local function timedifference (s)
   year = string.sub(s, 1, 4)
   month = string.sub(s, 6, 7)
   day = string.sub(s, 9, 10)
   hour = string.sub(s, 12, 13)
   minutes = string.sub(s, 15, 16)
   seconds = string.sub(s, 18, 19)
   t1 = os.time()
   t2 = os.time{year=year, month=month, day=day, hour=hour, min=minutes, sec=seconds}
   difference = os.difftime (t1, t2)
   return difference
end

local function updatenum(dev, value1)
    local cmd = string.format("%d|0|%d", otherdevices_idx[dev], value1)
    table.insert (commandArray, { ['UpdateDevice'] = cmd } )
end

local function updatestr(dev, value1)
    local cmd = string.format("%d|0|%s", otherdevices_idx[dev], value1)
    table.insert (commandArray, { ['UpdateDevice'] = cmd } )
end

---- Функция получение имени по id
function getdevname4idx(deviceIDX)
	for i, v in pairs(otherdevices_idx) do
		if v == deviceIDX then
			return i
		end
	end
	return 0
end

-- Если Stop_flag не создан
if (uservariables['Stop_flag'] == nil ) then
    print ( Name_unit .. " -- Stop_flag не создан!")
    return commandArray
end 

--  Если запущен этот скрипт - инфо и прерывание
if ( uservariables['Stop_flag'] == Name_unit ) then
    print ( Name_unit .. "------------------ Происходит полив!") 
    return commandArray
end



--- Создание переменной для удобрений если ранее не создовалась
if ( uservariables[Name_unit] == nil ) then 
    print ( Name_unit .. " -> Создание переменной для удобрений ...") 
    st = 'curl "127.0.0.1:8080/json.htm?type=command&param=adduservariable&vname=' .. Name_unit .. '&vtype=0&vvalue=' .. 1 .. '"'
    os.execute (st)
    return commandArray
end



if ( uservariables[Name_unit] ~= nil ) then 
    
-- Добавление еденицы к счетчику удобрений при включенной опции: set_Day_option = 1 в конце каждого дня.
    if (set_Day_option == 1 and tonumber(m) == 59 and tonumber(hr) == 23 ) then 
       local temp = tonumber( uservariables[Name_unit] ) + 1
       commandArray[ 'Variable:' .. Name_unit ] = tostring (temp)
       print ("Добавление еденицы к счетчику удобрений ... ")
    end 

-- Сброс переменной до "1" если она превышает матрицу удобрений
    local temp = tonumber( uservariables[Name_unit] )
    local i = 1 ; h = 0
    for s in string.gmatch(uservariables['pumps_calibraton'], "[^,]+")  do
        local tp = "setm_Pump_" .. tostring(i)
        if (temp  <= #_G[tp] ) then h = 1 end
        i = i + 1
    end
    if (h == 0) then 
        commandArray[ 'Variable:' .. Name_unit ] = tostring(1) 
        print ("Сброс до еденицы счетчика удобрений ... ")
        return commandArray
    end


end    

---- Увеличение квотой времени полива и концентрации удобрений
set_Time_fertilize = set_Time_fertilize * set_Quota
set_Time_clear_water = set_Time_clear_water * set_Quota

setm_Concentration_Q = setm_Concentration[ uservariables[ Name_unit ]] * set_Quota -- Добавка квоты для увеличения концентрации
-- Если коэфициент разбавления не указан - равен нулю - нет впрыска удобрений
if (setm_Concentration_Q == nil) then setm_Concentration_Q = 0 end

--print ("setm_Concentration_Q:" .. setm_Concentration_Q)



----- Проверка датчиков влажности по времени последнего обновления данных, определение наименьшего значения из группы


n = 0
w = 101
s_temp = 0
for p=1, #setm_Sens_id do
    tm_sensor = timedifference(otherdevices_lastupdate[ getdevname4idx(Sens_id[p]) ] )   
    if (tm_sensor < time_alarm) then
       if (tonumber (otherdevices[ getdevname4idx(Sens_id[p]) ]) > 0 and tonumber (otherdevices[ getdevname4idx(Sens_id[p]) ]) < w ) 
       then w = tonumber (otherdevices[ getdevname4idx(Sens_id[p]) ]) ; s_temp = p
       end
       n = n + 1
    else 
       local str = 'sudo echo "' .. vr ..' -> время опроса датчика-> ' .. getdevname4idx(Sens_id[p]) ..  ': превысило ' .. math.floor(tm_sensor/60) ..' мин. !!! "' ..'| mail -s "' .. vr .." " ..Name_unit .. '-> время опроса датчика-> ' .. getdevname4idx(Sens_id[p]) ..  ' превысило ' .. math.floor(tm_sensor/60) ..' мин. !!! " ' .. email
       if (sets_email ~= "" and tonumber(m) == set_Shift_time_watering - hr_offset*60 ) 
          then 
          os.execute (str)
          print (str) 
        end    
    print (Name_unit .. '-> время опроса датчика-> ' .. getdevname4idx(Sens_id[p]) ..  ': превысило ' .. math.floor(tm_sensor/60) ..' мин. !!!')    
    end
    
end 

if ( #setm_Sens_id > 1 ) then
if (n == 0 or w == 101 )
then 
    print (Name_unit .. "-> все датчики не обновляются !!!")
    local str = 'sudo echo "' .. vr ..' ' ..Name_unit .. '-> все датчики не обновляются !!!" | mail -s "' .. vr ..' ' ..Name_unit .. '-> все датчики не обновляются !!! " ' .. email
    if (sets_email ~= "" and tonumber(m) == set_Shift_time_watering - hr_offset*60) then os.execute (str) print (str) end    
    return commandArray
end
end

-- перезагрузка системы при привышении времени обновления датчиков больше time_alarm
if (#setm_Sens_id > 0 and s_temp == 0 and tonumber(m) == set_Shift_time_restart - hr_offset*60) 
then 
    local str = 'sudo echo "' .. vr ..' ' ..Name_unit .. '-> Перезагрузка !!!" | mail -s "' .. vr ..' ' ..Name_unit .. '-> все датчики не обновляются !!! " ' .. email
    if (sets_email ~= "" ) then os.execute (str) end 
    os.execute ("sudo reboot")  
end

local Temperature = set_Temp_set
if (s_temp ~= 0) then  Temperature = tonumber (otherdevices[ getdevname4idx(Sens_id[s_temp] +1) ]) end

Water_sensor = w
set_Water_level = set_Water_level  + ( tonumber(Temperature)  - set_Temp_set ) * set_Temp_corection 

st = 'с учетом текущей температуры '
if (set_Temp_corection == 0 or set_Temp_corection < 0 ) then st = ' Температура: ' end 

if (n == 1 ) then print (Name_unit .." -> Влажность:  " .. Water_sensor .. " % ... (Требуемая влажность " .. set_Water_level .." % " .. st .. Temperature .. " °C)") end
if (n > 1 ) then print (Name_unit .." -> Наименьшая в группе влажность:  " .. Water_sensor .. " % ... (Требуемая влажность " .. set_Water_level .." % " .. st .. Temperature .. " °C)") end
--if (#setm_Sens_id == 0 ) then print (Name_unit .." -> Включен режим полива без дачика влажности") end

-----------------------------------------------------------------------------
-- Если температура ниже set_Temp_stop_watering
if (set_Temp_stop_watering >= Temperature) 
    then
        print (Name_unit .. '-> Полив остановлен - понижение температуры ниже заданного значения!')
        return commandArray
    end
 
       
-----------------------------------------------------------------------------
----- Проверка датчиков перелива по времени последнего обновления данных, определение наибольшего значения из группы

n = 0
w = -1
s_temp = 0
for p=1, #setm_Sens_alarm_id do
    tm_sensor = timedifference(otherdevices_lastupdate[ getdevname4idx(setm_Sens_alarm_id[p]) ] )   
    if (tm_sensor < time_alarm) then
       if (tonumber (otherdevices[ getdevname4idx(setm_Sens_alarm_id[p]) ]) > w ) 
       then w = tonumber (otherdevices[ getdevname4idx(setm_Sens_alarm_id[p]) ]) ; s_temp = p
       end
       n = n + 1
    else 
       local str = 'sudo echo "' .. vr ..' -> время опроса датчика перелива-> ' .. getdevname4idx(setm_Sens_alarm_id[p]) ..  ': превысило ' .. math.floor(tm_sensor/60) ..' мин. !!! "' ..'| mail -s "' .. vr .." " ..Name_unit .. '-> время опроса датчика перелива-> ' .. getdevname4idx(setm_Sens_alarm_id[p]) ..  ' превысило ' .. math.floor(tm_sensor/60) ..' мин. !!! " ' .. email
       if (sets_email ~= "" and tonumber(m) == set_Shift_time_watering - hr_offset*60 ) 
          then 
          os.execute (str)
          print (str) 
        end    
    print (Name_unit .. '-> время опроса датчика перелива-> ' .. getdevname4idx(setm_Sens_alarm_id[p]) ..  ': превысило ' .. math.floor(tm_sensor/60) ..' мин. !!!')    
    end
    
end 

if ( #setm_Sens_alarm_id > 1 ) then
if (n == 0 or w == -1 )
    then 
    print (Name_unit .. "-> все датчики перелива не обновляются !!!")
    local str = 'sudo echo "' .. vr ..' ' ..Name_unit .. '-> все датчики перелива не обновляются !!!" | mail -s "' .. vr ..' ' ..Name_unit .. '-> все датчики перелива не обновляются !!! " ' .. email
    if (sets_email ~= "" and tonumber(m) == set_Shift_time_watering - hr_offset*60) then os.execute (str) print (str) end    
    return commandArray
end
end

Water_overflow = w
Water_overflow_id = s_temp


-- перезагрузка системы при привышении времени обновления датчиков больше time_alarm
if (#setm_Sens_alarm_id > 0 and s_temp == 0 and tonumber(m) == set_Shift_time_restart - hr_offset*60) 
then 
    local str = 'sudo echo "' .. vr ..' ' ..Name_unit .. '-> Перезагрузка !!!" | mail -s "' .. vr ..' ' ..Name_unit .. '-> все датчики перелива не обновляются !!! " ' .. email
    if (sets_email ~= "" ) then os.execute (str) end 
    --print (str)
    os.execute ("sudo reboot")  
end
-----------------------------------------------------------------------------



 

-- слив бачка в севисном режиме на следуший час в момент попытки полива
if (tonumber(m) == set_Shift_time_watering - hr_offset*60 ) 
then
    
    -- Датчик Пеерелива как датчик солености в сервисном бачке
    if (#setm_Sens_alarm_id ~= NULL and sets_Canal_out ~= "" and Water_overflow > 5 ) then
       
        -- Открыть сливной клапан
        local str = "bash /home/pi/bin/" .. sets_Canal_out .. " 1"
        os.execute (str)
        print (Name_unit .. " ->  НАЧАЛСЯ СЛИВ ... >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        str = "sleep " .. set_Time_drain
        os.execute (str)
        local str = "bash /home/pi/bin/" .. sets_Canal_out .. " 0"
        os.execute (str)
        print (Name_unit .. " ->  ЗАКОНЧИЛСЯ СЛИВ ... >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")    
        return commandArray
        
    end  


end



------ Определение времени полива --------------------------------------------------------

addday = 1 

if (set_Periodl >= 24 ) -- определение сколько дней между поливами и какой час полива = set_Periodl
    then
    addday = math.floor(set_Periodl/24)
    set_Periodl = set_Periodl - 24*addday
    addday = addday + 1
    end
-- определение минуты полива
chas_poliva = math.floor(set_Periodl + set_Shift_time_watering/60)
min_poliva = math.floor(  ((set_Periodl*60 + set_Shift_time_watering) - chas_poliva * 60)   )


Tiger_Start = 0
if (#setm_Sens_id == 0 ) -- Если включен режим без датчика
    then

    local text = ""

    for i = #setm_Hour_watering , 1 , -1  do 
    text =  tostring (setm_Hour_watering[i]) .. ", " .. text
        if (#setm_Hour_watering ~= nil) then
          if (day % addday == 0 and  tonumber(hr) == tonumber(setm_Hour_watering[i] + hr_offset) and tonumber(m) == min_poliva)
          then 
          Tiger_Start = 1
          
          end
        end
    end
    
    print (Name_unit .." -> Включен режим полива без дачика влажности -> Полив каждый " .. addday .. " днень" 
           .. " Часы полива: " .. text .. " + Сдвиг " .. math.floor(set_Shift_time_watering/60) .. ":" .. min_poliva .. ")")

else -- Если включен режим с датчиком влажности
    if (day % addday == 0 and  (hr - hr_offset) % set_Periodl == 0 and tonumber(m) == set_Shift_time_watering - hr_offset*60 and tonumber(hr) >= set_start_time_watering and tonumber(hr) <= set_stop_time_watering ) 
        then
        Tiger_Start = 1
        end

end

-- Запуск полива по кнопке при переключении Triger=Device
if (devicechanged ~= nil) 
then
    if (devicechanged['Выборочный полив'] == 'On') 
    then Tiger_Start = 1 end 
end



-- Запуск процедуры полива
if (Tiger_Start == 1)
then

   
    
    -- Сработал один из датчиков перелива
    if (#setm_Sens_alarm_id ~= NULL) then
        if (Water_overflow > 5  ) then
        -- Перелив- отправить сообщение    
            local str = 'sudo echo ' .. '"' .. vr .. ' ' .. getdevname4idx(setm_Sens_alarm_id[s_temp]) .. Water_overflow ..'"%' .. ' | mail -s ' .. '"' .. 'Сработал датчик Перелива ' .. Name_unit .. ' !!! ' .. '"'.. ' ' .. email
            if (sets_email ~= "") then os.execute (str) end
            print("! ! ! ========== Прелеив в " .. Name_unit .. "-> " .. getdevname4idx(setm_Sens_alarm_id[s_temp]) ..": ".. Water_overflow .. "%")
            return commandArray
        end
       
    end 



    if (#setm_Sens_id == 0 or Water_sensor < set_Water_level  and Water_sensor > 0 ) -- Полив если мало влаги и датчик не сухой либо включен режим без дачика влажности
    then   
       
        -- Флаг полива включЁн - для предотвращения запуска другого скрипта
        if ( uservariables['Stop_flag'] ==  '0' ) then
            st = 'curl "127.0.0.1:8080/json.htm?type=command&param=updateuservariable&vname=Stop_flag&vtype=2&vvalue=' .. Name_unit .. '"'
            os.execute (st)
        end
       
        --  Если запущен скрит во время работы другог 
        if ( uservariables['Stop_flag'] ~= Name_unit and uservariables['Stop_flag'] ~= '0' ) then
            st = Name_unit .. '-> Полив невозможен!!! Происходит полив другого растения - ' .. uservariables['Stop_flag'] .. '!!! - Ошибка в планировании полива !!!'
            print (st)
            updatestr (	'Журнал событий' , st)
            
            --local str = 'sudo echo "' .. vr ..' ' .. st ..'" | mail -s "' .. vr ..' ' .. st .. '" ' .. email
            local str = 'sudo echo "' .. vr ..' ' .. st .. '" | mail -s "' .. vr ..' ' .. Name_unit .. '- Полив невозможен!!!' .. '" ' .. email

            if (sets_email ~= "" ) then os.execute (str) end 
            
            return commandArray
        end
        
        

       
       
        -- Открыть поливочный клапан
        local str = "bash /home/pi/bin/" .. sets_Canal .. " 1"
        os.execute (str)
        print (Name_unit .. " - НАЧАЛСЯ ПОЛИВ ... >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
     
        -- Открыть главный клапан
        local str = "bash /home/pi/bin/" .. sets_m_valve .. " 1"
        os.execute (str)
   
        
        -- Впрыск удобрений --
        
        local flag = "" -- flag - переменная сод. пропись используемых удобрений
        
        -- Если концентрация = 0 то вместо впрыска задержка = set_Time_fertilize 
        if ( setm_Concentration_Q == 0 ) 
        then 
        local str = 'sleep ' .. tonumber(set_Time_fertilize)
        os.execute (str)
        end
        
        -- Начало впрыска
        if ( set_Time_fertilize > 0 and setm_Concentration_Q > 0 ) 
        then
            print (' >>>> Началась дозация удобрений для ' .. Name_unit .. " ...")
            
            --- Замена отсутсвующих значений удобрений нулями и 
            --- создание flag - переменная сод. пропись используемых удобрений
            flag = "с удобрениями {"
            local i = 1
            for s in string.gmatch(uservariables['pumps_calibraton'], "[^,]+")  do
            local tp = "setm_Pump_" .. tostring(i)
            if (_G[tp][ uservariables[ Name_unit ]] == nil ) then _G[tp][ uservariables[ Name_unit ]] = 0 
            else
                if (_G[tp][ uservariables[ Name_unit ]] ~= 0 ) then
                flag = flag .. '  #' .. i .. ":(" .. _G[tp][ uservariables[ Name_unit ]] .. ")" 
                end
            end
            i = i + 1
            end
            flag = flag .. "  } разбавление: " .. setm_Concentration[ uservariables[ Name_unit ]] 

            -----
            
            -- Получение поправок насосов из переменной пользователя
            setm_Pump_v = {}
            local i = 1
            for s in string.gmatch(uservariables['pumps_calibraton'], "[^,]+")  do
            setm_Pump_v [i] = tonumber (s)
            i = i + 1
            end
            ----------------
            
            -- Поиск наибольшего колличества удобрения в текущем рецепте
            local i = 1
            local max = 0
            for s in string.gmatch(uservariables['pumps_calibraton'], "[^,]+")  do
            local tp = "setm_Pump_" .. tostring(i)
            sh =  _G[tp][ uservariables[ Name_unit ]]
            if (sh > max) then max = sh end
            i = i + 1
            end
        
            
            ------------ Цыкл впрыска удобрений    commandArray[ 'Variable:' .. Name_unit ] 
            
                        
            local store_pumps  = {0,0,0,0,0,0,0,0,0,0,0,0}  -- счетчик удобрений, сколько было впрыснуто
       
            for p=0, max*set_division*setm_Concentration_Q do 
                
                -- Экстренное отключение полива
                    -- Определяем Stop_flag и заканчиваем скрипт если =-1
                    local url = 'curl "127.0.0.1:8080/json.htm?type=command&param=getuservariables" | grep -C 3 "Stop_flag" | grep "Value"  ' .. " | egrep -o '([-]*[0-9]+)' " 
                    local file = assert(io.popen(url, 'r'))
                    local out = file:read('*all')
                    file:close()
                    -- Отключение скрипта если Stop_flag=-1
                    if (tonumber(out) == -1) 
                    then
                       print (Name_unit .. " --- >>> Полив прерван !!! <<< ---")
                        -- Закрыть главный клапан
                       local str = "bash /home/pi/bin/" .. sets_m_valve .. " 0"
                       os.execute (str)
                        -- Закрыть поливочный клапан     
                       local str = "bash /home/pi/bin/" .. sets_Canal .. " 0"
                       os.execute (str)
                       return commandArray
                    end
                ------------
                
                local delay = 0 -- общее время впрыска в одном цикле
                local i = 1
                for s in string.gmatch(uservariables['pumps_calibraton'], "[^,]+")  do
                    
                    local tp = "setm_Pump_" .. tostring(i) 
                    if ( _G[tp][ uservariables[ Name_unit ]] > 0 and _G[tp][ uservariables[ Name_unit ]] ~= NULL ) 
                    then
                        if ( tonumber(store_pumps[i]) < tonumber (_G[tp][ uservariables[ Name_unit ] ])*setm_Concentration_Q ) 
                        then 
                            local st = "bash /home/pi/bin/pump" .. i .. " 1 ; sleep ".. setm_Pump_v[i]/set_division .. "; bash /home/pi/bin/pump" .. i .. " 0 " 
                                
                                delay = delay + setm_Pump_v[i]/set_division -- общее время потраченное на впрыск в одном цикле
                                local step = max/tonumber (_G[tp][ uservariables[ Name_unit ] ])
                                if ( p/(step*set_division) >= store_pumps[i] ) 
                                then    
                                os.execute (st)
                                store_pumps[i] = store_pumps[i] + 1/set_division
                                end
                        
                        end
 
                    end     
                    
                    i = i + 1
            
                end

            st = "sleep " .. tostring (  set_Time_fertilize/(max*set_division*setm_Concentration_Q) - delay  )     
            os.execute (st)
            
            end
            ------------ Конец впрыска удобрений
            
            local i = 1
            for s in string.gmatch(uservariables['pumps_calibraton'], "[^,]+")  do
            print ("Произведен впрыск удобрений -> насос-".. i .. ": ".. store_pumps[i] .. " ml")
            i = i + 1
            end
        
        else
            set_Time_fertilize = 0
        end
        

    
     -- Ждать время полива чистой водой
    local str = 'sleep ' .. tonumber(set_Time_clear_water)
    os.execute (str)
  
     -- Закрыть главный клапан
    local str = "bash /home/pi/bin/" .. sets_m_valve .. " 0"
    os.execute (str)

     -- Закрыть поливочный клапан     
    local str = "bash /home/pi/bin/" .. sets_Canal .. " 0"
    os.execute (str)
    print (Name_unit .. " - ЗАКОНЧИЛСЯ ПОЛИВ ... >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
    
    -- Флаг полива вЫключЁн
        temp = '0'
        st = 'curl "127.0.0.1:8080/json.htm?type=command&param=updateuservariable&vname=Stop_flag&vtype=2&vvalue=' .. temp .. '"'
        os.execute (st)

     -- Счетчик удобрений - добовляет еденицу к переменной Domoticz после полива с удобрениями
     -- Если привышение матрицы удобрений - сброс на 1
    if (set_Day_option == 0 and set_Time_fertilize > 0) then 
        local temp = tonumber( uservariables[Name_unit] ) + 1
        local i = 1
        local h = 0
        for s in string.gmatch(uservariables['pumps_calibraton'], "[^,]+")  do
        local tp = "setm_Pump_" .. tostring(i)
        if (temp  <= #_G[tp] ) then h = 1 end
        i = i + 1
        end
        if (h == 0) then commandArray[ 'Variable:' .. Name_unit ] = tostring(1)
        else commandArray[ 'Variable:' .. Name_unit ] = tostring (temp)
        end
    end
    
    -- Отослать сообщение о поливе
    --if (#setm_Sens_id == 0) then 
    local str = 'sudo echo ' .. '"'  .. Name_unit .. '- сработал полив ' .. flag   .. '" | mail -s "' .. hr .. ":" .. m .. " " .. Name_unit .. '-> Влажность: '.. Water_sensor .. '% (' .. Temperature ..'°C) - сработал полив" ' .. email
    if (sets_email ~= "") then os.execute (str) end
    print ('sets_email оповещение:  ' .. str )
     
    -- Передать в Info время полива 
    local st = ""
    if ( #setm_Sens_id ~=0 ) then st = hr..":"..m.." "..Name_unit.." ( ".. Water_sensor .."% ) полив " .. flag 
        else
        st = hr..":"..m.." "..Name_unit.." Полив без датчика влажности! " .. flag
        end
    
    updatestr (	'Журнал событий' , st)
     
    end
--------------------------    
 
    -- Если влажность > установленного
    if (Water_sensor > set_Alarm_level_high and Water_sensor ~= 101)  
    then 
        local str = 'sudo echo ' .. '"' .. vr .. ' Влажность: '..Water_sensor ..'"%' .. ' | mail -s ' .. '"' .. Name_unit .. ' Повышенная влажность !!!' .. '"'.. ' ' .. email
        if (sets_email ~= "") then os.execute (str) end
        print ('sets_email оповещение:  ' .. str)
    end    
    
    -- Если влажность < устаовленного
    if (Water_sensor < set_Alarm_level_low )  
    then 
        local str = 'sudo echo ' .. '"' .. vr .. ' Влажность: '..Water_sensor ..'"%' .. ' | mail -s ' .. '"' .. Name_unit .. ' Пониженная влажность !!!' .. '"'.. ' ' .. email
        if (sets_email ~= "") then os.execute (str) end
        print ('sets_email оповещение:  ' .. str)
    end  



end

return commandArray


-- Конец програмной части
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------

