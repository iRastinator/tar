commandArray = {}
------------------------------------------------------------------------------
------------------------------ Установки -------------------------------------
Name_unit = "Котроль-CO2-2"
--info:Дополнительная информация RASTINATOR
--separation
set_Low_Co = 21 -- label<Температура включения вентеляции>label info<>info
--separation
sets_start_time = "22:00" -- label<Час начала работы>label info<>info
sets_stop_time = "15:00" -- label<Час конца конца работы>label info<>info
--separation
sets_Canal_Co2 = "ch1-1" -- label<Канал управления устройством - Вентеляция>label info<>info
--separation
set_Alarm_level_low = 10 -- label<Нижний уровень температуры при котором будет выслано сообщение с предупреждением>label info<>info
set_Alarm_level_high = 29 -- label<Верхний уровень температуры при котором будет выслано сообщение с предупреждением>label info<>info
set_time_alarm = 15 -- label<Время обновления дачика температуры в минутах после которого дачик не используется и высылается сообщение>label info<>info
set_Shift_time_restart = 5 -- label<В>label info<>info
--separation
sets_emaill = "rastinator.sad@gmail.com" -- label<Адрес электронной почты, для отсылки сообщений, если пустые кавычки>label info<>info
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>x<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<--
-->>>>>>>>>>>>>>>>>>>>>>>>>>>> Программная часть <<<<<<<<<<<<<<<<<<<<<<<<<<<<<--
------------------------------ Ver. 20.10.21 -----------------------------------
local function updatenum(dev, value1)
    local cmd = string.format("%d|0|%d", otherdevices_idx[dev], value1)
    table.insert (commandArray, { ['UpdateDevice'] = cmd } )
end

local file = assert(io.popen('sudo python -m mh_z19', 'r'))
local output = file:read('*all')
file:close()
--print(output)

local co2 = output:match("[:]+%s+(%d+)")
--print (co2)

if (tonumber(co2) == nil) 
then
print (Name_unit .. ' -> Нет данных !!!')
else
updatenum("CO2", co2)
print (Name_unit .. ' -> ' .. tostring(co2) .." ppm")
end


return commandArray
