commandArray = {}
------------------------------------------------------------------------------
------------------------------ Установки -------------------------------------
Name_unit = "Датчики-Flora2"
--info:поясняющая информация ...
--separation
set_time_shift_flora = 33 -- label<Сдвиг опроса по времени>label info<время в минутах>info
set_rate_flora = 1 -- label<Опросить датчики каждый>label info<в часах>info
sens = {
"C4:7C:8D:65:60:0F , 15",  -- label<>label info<Sensor id 15>info
}

-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>x<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<--
-->>>>>>>>>>>>>>>>>>>>>>>>>>>> Программная часть <<<<<<<<<<<<<<<<<<<<<<<<<<<<<--
------------------------------ Ver. 27.05.23 -----------------------------------
print ("flora")
--Функция получение имени по id
function getdevname4idx(deviceIDX)
	for i, v in pairs(otherdevices_idx) do
		if v == deviceIDX then
			return i
		end
	end
	return 0
end
---------------------------------

function trim(s)
  return (string.gsub(s, "^%s*(.-)%s*$", "%1"))
end 


-- Действия при старте процесса Domoticz
-- опрос датчиков при старте
Start = 0
cmd = 'pidof domoticz'  -- получить id процесса domoticz
file = assert(io.popen(cmd, 'r'))
output = file:read('*all')
file:close()

cmd = 'ps -p ' .. tonumber(output) .. ' -o etime=' -- время с последней загрузки процесса domoticz
file = assert(io.popen(cmd, 'r'))
output = file:read('*all')
file:close()
print(output)
output = trim (output)
if (string.len(trim(output)) == 5 and string.sub(output,1,2) == '00')
then
Start = 1
end



m = os.date('%M')
hr = os.date('%H')
if ( hr % set_rate_flora == 0 and tonumber(m) == set_time_shift_flora or Start == 1) then
    for p=1, #sens do
    
        zap= string.find(sens[p],",")
        mac = string.sub(sens[p], 0, string.find(sens[p],",")-1)
        mac = mac:gsub("%s+", "")
        id = string.sub(sens[p], string.find(sens[p],",")+1,100)
        id = id:gsub("%s+", "")
        stt = '"'.. mac..'"'..' '..'"'..id..'"'..' '..'"'..tonumber(id)+1 ..'"'..' '..'"'..tonumber(id)+2 ..'"'..' '..'"'..tonumber(id)+3 ..'"'..' '..'"'..tonumber(id)+4 ..'"'

        local str = 'python3 /home/pi/domoticz/scripts/python/miflora/miflora_s.py "127.0.0.1:8080" ' .. stt .."&"
        os.execute (str)
        print (" ... Опрос датчика влажности :" .. getdevname4idx(tonumber(id)) )
        os.execute ("sleep 1")
    end 
end




 return commandArray
