commandArray = {}
------------------------------------------------------------------------------
------------------------------ Установки -------------------------------------
Name_unit = "Температура-new"
--info:Дополнительная информация RASTINATOR
--separation
set_Value_Cooler = 23 -- label<Температура включения вентиляции>label info<>info
set_Value_Hoter = 20 -- label<Температура включения нагревателя>label info<>info
--separation
sets_start_time = "00:00" -- label<Час начала работы>label info<>info
sets_stop_time = "00:00" -- label<Час конца конца работы>label info<>info
--separation
sets_Canal_cooler = "ch3-5" -- label<Канал управления устройством - Вентиляция>label info<>info
sets_Canal_hoter = "ch3-7" -- label<Канал управления устройством - Нагреватель>label info<>info
--separation
set_Sens_ID = 15 -- label<ID Датчика температуры>label info<>info
--separation
set_Alarm_level_low = 10 -- label<Нижний уровень температуры при котором будет выслано сообщение с предупреждением>label info<>info
set_Alarm_level_high = 29 -- label<Верхний уровень температуры при котором будет выслано сообщение с предупреждением>label info<>info
set_time_alarm = 60 -- label<Время обновления дачика температуры в минутах после которого датчик не используется и высылается сообщение>label info<>info
set_Shift_time_restart = 115 -- label<В>label info<>info
--separation
sets_emaill = "rastinator.sad@gmail.com" -- label<Адрес электронной почты, для отсылки сообщений, если пустые кавычки>label info<>info
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>x<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<--
-->>>>>>>>>>>>>>>>>>>>>>>>>>>> Программная часть <<<<<<<<<<<<<<<<<<<<<<<<<<<<<--
------------------------------ Ver. 01.11.2023 -----------------------------------

set_time_alarm = set_time_alarm*60
hr_offset = math.floor(set_Shift_time_restart/60) 

m = os.date('%M')
sec = os.date('%S')
hr = os.date('%H')
day = os.date('%d')
vr = hr .. ':' .. m ..':' .. sec
time_now = tonumber(hr) + tonumber(m)/60

sets_start_time_orig = sets_start_time
sets_stop_time_orig  = sets_stop_time

hours, minutes = string.match(sets_start_time, "(%d+):(%d+)")
sets_start_time = tonumber(hours) + tonumber(minutes)/60

hours, minutes = string.match(sets_stop_time, "(%d+):(%d+)")
sets_stop_time = tonumber(hours) + tonumber(minutes)/60

--print(sets_start_time..'  '..sets_stop_time .. ' -- '.. time_now) 



-- Запуск скрипта по расписанию
-- Если время старта больше времени завершения - переход через 00:00
if ( sets_start_time > sets_stop_time ) then
    if(  sets_start_time >= time_now and time_now > sets_stop_time  ) -- время когда запуска не будет
        then
            print (Name_unit .. " -> ---=== Скрипт не запущен 2")
            return commandArray
        end
end
-- Если время старта меньше времени завершения - промежуток в одних сутках
if ( sets_start_time < sets_stop_time ) 
then
    if (  time_now >= sets_start_time and time_now < sets_stop_time ) 
    then
    else 
        print (Name_unit .. " -> ---=== Скрипт не запущен ") 
        return commandArray
    end
end    
--Если время начала и время конца одинаковое
--if ( sets_start_time == sets_start_time ) then return commandArray end

local function timedifference (s)
   year = string.sub(s, 1, 4)
   month = string.sub(s, 6, 7)
   day = string.sub(s, 9, 10)
   hour = string.sub(s, 12, 13)
   minutes = string.sub(s, 15, 16)
   seconds = string.sub(s, 18, 19)
   t1 = os.time()
   t2 = os.time{year=year, month=month, day=day, hour=hour, min=minutes, sec=seconds}
   difference = os.difftime (t1, t2)
   return difference
end


local function updatestr(dev, value1)
    local cmd = string.format("%d|0|%s", otherdevices_idx[dev], value1)
    table.insert (commandArray, { ['UpdateDevice'] = cmd } )
end

---- Функция получение имени по id
function getdevname4idx(deviceIDX)
	for i, v in pairs(otherdevices_idx) do
		if v == deviceIDX then
			return i
		end
	end
	return 0
end


tm_sensor = timedifference(otherdevices_lastupdate[ getdevname4idx(set_Sens_ID) ])

local Value = tonumber ((otherdevices[ getdevname4idx(set_Sens_ID) ]):match("%d+"))

-- Если время обновления датчика > set_time_alarm

-- перезагрузка системы при привышении времени обновления датчиков больше set_time_alarm
if (tm_sensor > set_time_alarm and tonumber(m) == set_Shift_time_restart - hr_offset*60) 
 then 
    local str = 'sudo echo "' .. vr ..' ' ..Name_unit .. '-> Перезагрузка !!!" | mail -s "' .. vr ..' ' ..Name_unit .. '->' .. getdevname4idx(set_Sens_ID) .. '-> датчик не обновляется !!! " ' .. sets_emaill
    if (sets_emaill ~= "" ) then os.execute (str) end 
    os.execute ("sudo reboot")  
 
end


if (tm_sensor > set_time_alarm)      
 then
    local str = "bash /home/pi/bin/" .. sets_Canal_cooler .. " 0"
    os.execute (str)
    print (Name_unit .. '-> время опроса датчика-> ' .. getdevname4idx(set_Sens_ID) ..  ': превысило ' .. math.floor(tm_sensor/60) ..' мин. !!!')    
    
    if (sets_emaill ~= "" and tonumber(m) == 5 ) 
    then 
        local str = 'sudo echo "' .. vr .." " ..Name_unit .. '-> время опроса датчика-> ' .. getdevname4idx(set_Sens_ID) ..  ': превысило ' .. math.floor(tm_sensor/60) ..' мин. !!! "' ..'| mail -s "' .. vr .." " ..Name_unit .. '-> время опроса датчика-> ' .. getdevname4idx(set_Sens_ID) ..  ' превысило ' .. math.floor(tm_sensor/60) ..' мин. !!! " ' .. sets_emaill
        os.execute (str)
        

    end   
            -- Выключить реле     
        local str = "bash /home/pi/bin/" .. sets_Canal_cooler .. " 0"
        os.execute (str)
        
        local str = "bash /home/pi/bin/" .. sets_Canal_hoter .. " 0"
        os.execute (str)
        
        local st = Name_unit.." (".. Value .."°) Вентеляция закрыта + Подогрев отключен - Температурный датчик не обновляется! "
        print ("========= " .. st)
    return
    
end 


-----------------------------------------------------------------------------    



--local Value = tonumber ((otherdevices[ getdevname4idx(set_Sens_ID) ]):match("%p+%d+"))
--print ("Строка:  " .. Value) 
local info = Name_unit.." -> (".. Value .."°)"
-----------------------------------------------------------------------------
   
   if (Value >= set_Value_Cooler ) -- 
    then   
     -- Включить реле     
        local str = "bash /home/pi/bin/" .. sets_Canal_cooler .. " 1"
        os.execute (str)
        info = info .. " Вентеляция ВКлючена"

    else
    -- Выключить реле     
        local str = "bash /home/pi/bin/" .. sets_Canal_cooler .. " 0"
        os.execute (str)
        info = info .. " Вентеляция ОТКлючена"
       
    end
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
   
   if (Value >= set_Value_Hoter ) -- 
    then   
     -- Выключить реле     
        local str = "bash /home/pi/bin/" .. sets_Canal_hoter .. " 0"
        os.execute (str)
        info = info .. " + Подогрев ОТКлючен"

    else
    -- Включить реле    
        local str = "bash /home/pi/bin/" .. sets_Canal_hoter .. " 1"
        os.execute (str)
        -- Передать в Info  
        info = info .. " + Подогрев ВКлючен"

    end
-----------------------------------------------------------------------------

print ( info .. " (Начало в " .. sets_start_time_orig .. " завершение в " .. sets_stop_time_orig .. ")")

-----------------------------------------------------------------------------
    -- Если Значение > установленного
    if (Value >= set_Alarm_level_high and tonumber(m) == 5 )  
    then 
        local str = 'sudo echo ' .. '"' .. vr .. ' Значение: '..Value ..'"°' .. ' | mail -s ' .. '"' .. Name_unit .. ' Повышенное Значение !!!' .. '"'.. ' ' .. sets_emaill
        if (sets_emaill ~= "") then os.execute (str) end
        print ('sets_emaill оповещение:  ' .. str)
    end    
    
    -- Если Значение < устаовленного
    if (Value <= set_Alarm_level_low and tonumber(m) == 5 )  
    then 
        local str = 'sudo echo ' .. '"' .. vr .. ' Значение: '..Value ..'"°' .. ' | mail -s ' .. '"' .. Name_unit .. ' Пониженное Значение !!!' .. '"'.. ' ' .. sets_emaill
        if (sets_emaill ~= "") then os.execute (str) end
        print ('sets_emaill оповещение:  ' .. str)
    end  





return commandArray


