commandArray = {}
print('<br>…………………………………………………………………………………………………………………')
return commandArray

