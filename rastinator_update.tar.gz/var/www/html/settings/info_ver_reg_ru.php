<?php

//var_dump ($_GET); exit;
// Получаем значение переменной version из параметров запроса (например, из URL)
$version = $_GET['version'] ; // Устанавливаем по умолчанию 'stable'
$history_link = '';
// Определяем URL для получения информации о версии на основе параметра
if ($version === 'test') {
    $url = 'https://rastinator.ru/wp-content/uploads/ras_info/version_info_beta'; // Если beta
} else {
    $url = 'https://rastinator.ru/wp-content/uploads/ras_info//version_info'; // Если stable
	$history_link = '<a class="button_text" href="https://rastinator.ru/wp-content/uploads/ras_info//history">История изменений</a>';
}

// Получаем данные о версии
$file_contents = file_get_contents($url);

// Выводим информацию о доступной версии
echo 'Rastinator - ' . $file_contents.'  '.$history_link ;
?>
<br>