<?php

$file =  "../backup/rastinator_to_github.tar.gz";

$comand = 'tar --exclude=/var/www/html/backup --exclude=/var/www/html/log/log_watering --exclude=/var/www/html/token -zcvf '.$file.' /var/www/html/*';
shell_exec($comand);  


require '../vendor/autoload.php'; // Подключение Guzzle HTTP

use GuzzleHttp\Client;

// Имя пользователя и название репозитория
$username = 'iRastinator';
$repository = 'tar';

// Токен доступа GitHub
$token = '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';


// Путь к файлу, который нужно загрузить
$file = '../version_info';
$file = '../backup/rastinator_to_github.tar.gz';
// Содержимое файла (добавлена проверка на успешное чтение содержимого файла)
$content = file_get_contents($file);
if ($content === false) {
    die('Ошибка при чтении файла');
}

// Имя файла
$filename = 'version_info';
$filename = 'rastinator_update.tar.gz';
// Инициализация Guzzle HTTP клиента
$client = new Client([
    'base_uri' => 'https://api.github.com',
    'headers' => [
        'Authorization' => 'token ' . $token,
        'Accept' => 'application/vnd.github.v3+json',
    ],
]);



// Получение текущего содержимого файла с сервера GitHub
$currentFile = $client->request('GET', 'repos/'.$username.'/'.$repository.'/contents/'.$filename);
$currentFileData = json_decode($currentFile->getBody(), true);
$sha = $currentFileData['sha']; // Получение SHA хеша существующего файла

// Обновление файла на сервере GitHub
$response = $client->request('PUT', 'repos/'.$username.'/'.$repository.'/contents/'.$filename, [
    'json' => [
        'message' => 'Update file via API',
        'content' => base64_encode($content),
        'sha' => $sha  // Указание SHA хеша существующего файла для обновления
    ],
]);

// Получение ответа
$body = $response->getBody();
$content = $body->getContents();


///---


// Путь к файлу, который нужно загрузить
$file = '../version_info';
//$file = '../backup/rastinator_to_github.tar.gz';
// Содержимое файла (добавлена проверка на успешное чтение содержимого файла)
$content = file_get_contents($file);
if ($content === false) {
    die('Ошибка при чтении файла');
}

// Имя файла
$filename = 'version_info';
//$filename = 'rastinator_update.tar.gz';
// Инициализация Guzzle HTTP клиента
$client = new Client([
    'base_uri' => 'https://api.github.com',
    'headers' => [
        'Authorization' => 'token ' . $token,
        'Accept' => 'application/vnd.github.v3+json',
    ],
]);



// Получение текущего содержимого файла с сервера GitHub
$currentFile = $client->request('GET', 'repos/'.$username.'/'.$repository.'/contents/'.$filename);
$currentFileData = json_decode($currentFile->getBody(), true);
$sha = $currentFileData['sha']; // Получение SHA хеша существующего файла

// Обновление файла на сервере GitHub
$response = $client->request('PUT', 'repos/'.$username.'/'.$repository.'/contents/'.$filename, [
    'json' => [
        'message' => 'Update file via API',
        'content' => base64_encode($content),
        'sha' => $sha  // Указание SHA хеша существующего файла для обновления
    ],
]);

// Получение ответа
$body = $response->getBody();
$content = $body->getContents();

header("Location: index.php"); // Замените /index.php на путь к нужной странице
exit; // Убедитесь, что после отправки заголовка следует выход из скрипта




?>