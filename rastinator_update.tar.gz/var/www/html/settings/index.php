<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Rastinator</title>
<script type="text/javascript" src="/ajax/jquery-3.7.0.min.js"></script>
<style>
         @import "../style.css" screen; /* Стиль для вывода результата на монитор */
         @import "../style.css" print, handheld; /* Стиль для печати и смартфона */
    
                    *{
    padding: 0%;
    margin: 0%;
            }
            .container{
            grid-template-columns: auto;
            display: grid;
            
    
          }
          
          .item {
              
              padding: 0px;
              border: 0px solid black;
                        
            }


    
</style>      
          
</head>

<body>


<?php
	
//var_dump($_POST);	//exit();
//Авторизация
include('../login/in.php');    
    
function debug_to_console($data) {
    $output = $data;
    if (is_array($output))
        $output = implode(',', $output);
    echo "<script>console.log('Debug Objects: " . $output . "' );</script>";
}    
?>
    
   
    
<div class="container">

<!-- Верхнее меню -->     
<div class="item item_1">
        <ul>
          <li><svg width="150" height="40" viewBox="150 -30 180 180"> <?php include('../pic/Rastinator.svg'); ?> </svg> </li>
          <li><a href="../poliv/index.php" >Полив</a></li>    
          <li><a href="../climat/index.php">Климат</a></li>
          <li><a href="../sensors/index.php">Датчики</a></li>
          <li><a class="active" >Настройки</a></li>
          <li><a href="../log_poliva/index.php">Журнал полива</a></li>
          <li><a href="../log_domoticz/index.php">Журнал системы</a></li>

        </ul>  
    

    
</div>              

<!-- Информационная панель - отображение данных лога -->     
<div class="item item_2" >
                               
             <script type="text/javascript">        
                $(document).ready(function() 
                { 
                var func = function() {$("#info").load('../log/log.php');}
                setInterval(func, 2000);

                });

            </script>                                

    
            <div id="info" >
               <?php include('../log/log.php'); ?>
                
            </div> 
</div>  
    
    
<!-- item item_4 - Кнопки  -  ----------> 
<div class="item item_3">
    
                                                  


<div class="btn-group">

<a class="btn_pag"  href="off_reboot.php?reboot_domoticz" >Перезагрузка процессов</a> 
	
<a class="btn_pag"  href="off_reboot.php?reboot" onclick="return confirm('Вы действительно хотите  перезагрузить систему?')">Перезагрузка системы</a> 
<a class="btn_pag"  href="off_reboot.php?shutdown" onclick="return confirm('Вы действительно хотите завершить работу системы?')">Выключение системы</a> 

   

</div> 
    
 

</div> 

    
    
<!--   -->
<div class="item item_4">

   <div class="settings_palel">
	   <form action="back_up.php" method="post" name="save_sett">
			<p class="settins_label">Сохранение настроек </p>
			<br>
			<input class="button_text" type="submit" value="Сохранить настройки" name="download_set">
		    <input type="checkbox" id="only_system" name="only_system">
			<label for="only_system">Сохранить только систему Rastinator без установок и данных</label>
			</form>

	</div>
	
	<div class="settings_palel">
        <p class="settins_label">Восстановление настроек </p>
        <form action="upload.php" method="post" enctype="multipart/form-data">

  		
			<div class="file-upload">
  			<input type="file" name="fileToUpload" id="fileToUpload">
  			<label for="fileToUpload">Выберите файл</label>
  			<span id="filename"></span>
			</div>

			<script>
			document.getElementById('fileToUpload').addEventListener('change', function() {
			document.getElementById('filename').textContent = this.files[0].name;
			});
			</script>	
			
		
			  <input class="button_text" type="submit" onclick="return confirm('Вы уверены, что хотите Восстановить настройки?')" value="Восстановить настройки" name="download_set">
			  <br> 
			  
			  <input type="checkbox" id="without_bd" name="without_bd">
			  <label for="without_bd">Не восстанавливать базу данных</label>
			  <br>
			  <input type="checkbox" id="without_old_scrips" name="without_old_scrips">
			  <label for="without_bd">Удалять текущие профили</label>

			
        </form>
    </div>
	
	<div class="settings_palel">
		<p class="settins_label">Обновление</p>
		<div class="text_1">Установлена версия Rastinator: <?php $file_contents = file_get_contents('../version_info'); echo $file_contents;?></div>
				<br>
		<button class="button_text" id="getDataButton">Проверить обновление</button>
		
			<script>
				$(document).ready(function(){
					$("#getDataButton").click(function(){
						$.ajax({
							url: "info_ver.php",
							type: "GET",
							success: function(response){
								$("#version").html(response);
							}
						});
					});
				});
			</script>

		 <a class="button_text" href="update.php" onclick="return confirm('Вы уверены, что хотите Обновить систему?')" >Обновить</a>	
		<div id="version"></div>
	</div>
	
	
    <?php
		
	$AuthUser = shell_exec('sudo /home/pi/bin/email_read_user');
	$AuthPass = shell_exec('sudo /home/pi/bin/email_read_pass');
	$test_email = shell_exec('  tail -n 1 /home/pi/bin/restart_info | awk \'{print $NF}\'  ');

	?>

    <div class="settings_palel">
		 <p class="settins_label">Настройка почтового сервера для отправки сообщений</p>
	
        <form method="post" action="email_set.php" >
			<div>	
			    <label for="AuthUser">e-mail Яндекс</label>
				<input type="text" class="input_2" id="AuthUser" name="AuthUser" value="<?php echo $AuthUser ?>" placeholder="e-mail Яндекс">
				<div>
				<label for="AuthPass">Пароль для e-mail Яндекс </label>
                <input type="password" class="input_2" id="AuthPass" name="AuthPass" value="<?php echo $AuthPass ?>" placeholder="пароль">
				</div>	

			</div>

			<div>
				<label for="test_email">e-mail для системных сообщений</label>
                <input type="text" class="input_2" id="test_email" name="test_email" value="<?php echo $test_email ?>" placeholder="Тестовый e-mail">
               
			</div>
			<div> 
			 <input class="button_text" type="submit" value="Применить" >
			 <label class="info_show" > 
				<?php
		   
					if(isset($_POST["sent"])) {echo "Выслано тестовое письмо на e-mail для системных сообщений!";}
				?>
			  </label>
			</div>
				
        </form>
        
    </div>    
     
	
	<div class="settings_palel">
        <p class="settins_label">Калибровка дозировочных насосов</p>
        <br>
        <a class="button_text" href="calibration.php">Начать</a>
        
	</div>
	
	<div class="settings_palel">
        <p class="settins_label">Управление каналами</p>
        <br>
        <a class="button_text" href="test_channels.php">Начать</a>
        
	</div>

</div>


<script>
  document.addEventListener('keydown', function(event) {
  if (event.ctrlKey && event.key === '/') {
    window.location.href = '../github/index.php';  // Перенаправление на указанную страницу
  }
});
</script>     
    
  </body>
</html>
