<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8" />
	<title>Rastinator</title>

	<style>
		@import "../style.css"screen;
		/* Стиль для вывода результата на монитор */
		@import "../style.css"print, handheld;
		/* Стиль для печати и смартфона */

		body {
			height: 100%;
			margin: 0;
			display: flex;
			align-items: center;
			justify-content: center;
		}

		.settings_palel {
			text-align: center;
			width: 40%;
			position: absolute;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -50%);
		}

		#indicator {
			height: 20px;
			background-color: green;
			animation: progress-bar 60s linear forwards;
		}

		/* Анимация индикатора */
		@keyframes progress-bar {
			0% {
				width: 0%;
			}

			100% {
				width: 100%;
			}
		}

	</style>

</head>

<body>



	<?php

if(isset($_GET['reboot'])) 
{   // Загрузка index.php после завершения индикатора
    echo '
    <script>
     setTimeout(function() {
     window.location.href = "../index.php";
     }, 60000);
    </script>
<div class="settings_palel">	
<p class="settins_label">Перезагрузка</p>
<br>
<div id="container">	

    	<div id="indicator"></div>

</div>
</div>
</body>
</html>
  ';
  
  
	

    shell_exec('curl "http://127.0.0.1:8080/json.htm?type=command&param=system_reboot" > /dev/null 2>&1 &'); 
	
    shell_exec('sudo reboot > /dev/null 2>&1 &'); 
	exit();  
}

	
        





if(isset($_GET['shutdown'])) 
{
  

	echo'
	<div class="settings_palel">	
	<p class="settins_label">Выключение</p>
	<br>
    <div id="container">
	<div id="indicator" style="animation: progress-bar 20s linear forwards;"></div>
    </div>

    <script>
  window.addEventListener(\'DOMContentLoaded\', (event) => {
    setTimeout(function() {
      document.getElementById(\'message\').textContent = \'Можно отключать питание\';
    }, 20000);
  });
</script>

  <h2 id="message"></h2>
  </div>
</body>
</html>
    '; 
	shell_exec('curl "http://127.0.0.1:8080/json.htm?type=command&param=system_shutdown" > /dev/null 2>&1 &'); 
	
	shell_exec('sudo shutdown -h now > /dev/null 2>&1 &'); 
	exit();
}




if(isset($_GET['reboot_domoticz'])) 
	{
	shell_exec('/home/pi/bin/restart_domoticz > /dev/null 2>&1 &');
	
	// Эта форма отправляется автоматом после загрузки страницы
	echo 
		 '
	<html>
	<body onload="document.frm1.submit()">
	   <form action="index.php" name="frm1" method="POST">

	   </form>
	</body>
	</html>
	' ; exit();


	}



?>
