<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8" />
	<title>Rastinator</title>

	<style>
		@import "../style.css"screen;
		/* Стиль для вывода результата на монитор */
		@import "../style.css"print, handheld;
		/* Стиль для печати и смартфона */

		body {
			height: 100%;
			margin: 0;
			display: flex;
			align-items: center;
			justify-content: center;
		
		}

		.settings_palel {
			text-align: center;
			width: 40%;
			position: absolute;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -50%);
		}

		#indicator {
			height: 20px;
			background-color: #575757;
			animation: progress-bar 70s linear forwards;
		}

		/* Анимация индикатора */
		@keyframes progress-bar {
			0% {
				width: 0%;
			}

			100% {
				width: 100%;
			}
		}

	</style>

</head>

<body>
	<div class="background-svg"></div>


<?php
	


if(isset($_GET['reboot'])) 
{   // Загрузка index.php после завершения индикатора
    echo '
    <script>
     setTimeout(function() {
     window.location.href = "../index.php";
     }, 60000);
    </script>
	
<div class="settings_palel" style="opacity: 0.8;">	
<div class="settins_label">Перезагрузка</div>

<div id="container">	
    	<div id="indicator"></div>

</div>
</div>
</body>
</html>
  ';
  
  
		// Начначаем переменной stop_flag = "Switch_off" - выключение всех выключателей
		// Получаем сырой JSON
		$json = shell_exec("curl -s 'http://127.0.0.1:8080/json.htm?type=command&param=getuservariables'");

		// Экстрактим ID для Stop_flag (используем комбинацию grep и awk)
		$command = <<<CMD
		echo '$json' | grep -A4 -B1 '"Name" : "Stop_flag"' | awk -F'"' '/idx/ {print \$4}'
		CMD;

		$variable_id = trim(shell_exec($command));

		if (is_numeric($variable_id)) {
			// Обновляем переменную
			$update_cmd = sprintf(
				"curl -s 'http://127.0.0.1:8080/json.htm?type=command&param=updateuservariable&idx=%d&vname=Stop_flag&vtype=2&vvalue=Switch_off'",
				$variable_id
			);

			$result = shell_exec($update_cmd);
			//echo "Успешно обновлено! ID: $variable_id\n";
			//echo "Ответ сервера: $result";
		} else {
			//echo "Ошибка: Переменная Stop_flag не найдена!\n";
			//echo "Сырой JSON ответ:\n" . $json;
		}

	

    shell_exec('curl "http://127.0.0.1:8080/json.htm?type=command&param=system_reboot" > /dev/null 2>&1 &'); 
	
    shell_exec('sudo reboot > /dev/null 2>&1 &'); 
	exit();  
}

	
        





if(isset($_GET['shutdown'])) 
{
    echo '
    <div class="settings_palel" style="opacity: 0.8;">	
        <div class="settins_label">Выключение</div>
        <div id="container">
            <div id="indicator" style="animation: progress-bar 20s linear forwards;"></div>
        </div>
        <script>
            window.addEventListener(\'DOMContentLoaded\', (event) => {
                setTimeout(function() {
                    document.getElementById(\'message\').textContent = \'Можно отключать питание\';
                    document.getElementById(\'closeButton\').style.display = \'block\';
                }, 20000);
            });
            function clearPage() {
                document.body.innerHTML = ""; // Очистка содержимого страницы
                // Или можно задать: location.href = ""; // Это загрузит пустую страницу
            }
        </script>
        <h2 id="message"></h2>
        <button 
            id="closeButton" 
            onclick="clearPage()" 
            style="
                display: none;
                margin: 20px auto;
                padding: 10px 25px;
                font-size: 18px;
                background: #4CAF50;
                color: white;
                border: none;
                border-radius: 4px;
                cursor: pointer;
            ">
            OK
        </button>
    </div>
    </body>
    </html>
';

    	
		// Начначаем переменной stop_flag = "Switch_off" - выключение всех выключателей
		// Получаем сырой JSON
		$json = shell_exec("curl -s 'http://127.0.0.1:8080/json.htm?type=command&param=getuservariables'");

		// Экстрактим ID для Stop_flag (используем комбинацию grep и awk)
		$command = <<<CMD
		echo '$json' | grep -A4 -B1 '"Name" : "Stop_flag"' | awk -F'"' '/idx/ {print \$4}'
		CMD;

		$variable_id = trim(shell_exec($command));

		if (is_numeric($variable_id)) {
			// Обновляем переменную
			$update_cmd = sprintf(
				"curl -s 'http://127.0.0.1:8080/json.htm?type=command&param=updateuservariable&idx=%d&vname=Stop_flag&vtype=2&vvalue=Switch_off'",
				$variable_id
			);

			$result = shell_exec($update_cmd);
			//echo "Успешно обновлено! ID: $variable_id\n";
			//echo "Ответ сервера: $result";
		} else {
			//echo "Ошибка: Переменная Stop_flag не найдена!\n";
			//echo "Сырой JSON ответ:\n" . $json;
		}

	
	
	    //Выключение машины
		//shell_exec('curl "http://127.0.0.1:8080/json.htm?type=command&param=system_shutdown" > /dev/null 2>&1 &'); 
		shell_exec('sudo shutdown -h now > /dev/null 2>&1 &'); 
		exit();
	
}




if(isset($_GET['reboot_domoticz'])) 
	{
	
		$comand = 'sudo service domoticz stop';
		$output = shell_exec($comand);
		$comand = 'sleep 5';
		$output = shell_exec($comand);
		$comand = 'sudo service domoticz start';
		$output = shell_exec($comand);
	
	// Эта форма отправляется автоматом после загрузки страницы
	echo 
		 '
	<html>
	<body onload="document.frm1.submit()">
	   <form action="index.php" name="frm1" method="POST">

	   </form>
	</body>
	</html>
	' ; exit();


	}



?>
