  <style>
  	@import "../style.css"screen;
  	/* Стиль для вывода результата на монитор */
  	@import "../style.css"print, handheld;
  	/* Стиль для печати и смартфона */

  	body {
  		height: 100%;
  		margin: 0;
  		display: flex;
  		align-items: center;
  		justify-content: center;
  	}

  	.settings_palel {
  		text-align: center;
  		width: 40%;
  	}

  	#indicator {
  		height: 20px;
  		background-color: green;
  		animation: progress-bar 60s linear forwards;
  	}

  	/* Анимация индикатора */
  	@keyframes progress-bar {
  		0% {
  			width: 0%;
  		}

  		100% {
  			width: 100%;
  		}
  	}

  </style>




  <?php

if(isset($_GET['reboot'])) 
{   // Загрузка index.php после завершения индикатора
    echo '
    <script>
     setTimeout(function() {
     window.location.href = "../index.php";
     }, 60000);
    </script>
<div class="settings_palel">	
<p class="settins_label">Перезагрузка</p>
<br>
<div id="container">	

    	<div id="indicator"></div>

</div>
</div>
  ';
  
    
    $comand = 'sudo reboot';
   // $output = shell_exec($comand);
        
}




if(isset($_GET['shutdown'])) 
{
  
    $comand = 'sudo shutdown -h now';
    //$output = shell_exec($comand);
    echo'
	<div class="settings_palel">	
	<p class="settins_label">Выключение</p>
	<br>
    <div id="container">
	<div id="indicator" style="animation: progress-bar 20s linear forwards;"></div>
    </div>

    <script>
  window.addEventListener(\'DOMContentLoaded\', (event) => {
    setTimeout(function() {
      document.getElementById(\'message\').textContent = \'Можно отключать питание\';
    }, 20000);
  });
</script>

  <h2 id="message"></h2>
  </div>
    ';
}


if(isset($_GET['reboot_domoticz'])) 
	{
	$comand = '/home/pi/bin/restart_domoticz';
	$output = shell_exec($comand);	
	
	
	// Эта форма отправляется автоматом после загрузки страницы
	echo 
		 '
	<html>
	<body onload="document.frm1.submit()">
	   <form action="index.php" name="frm1" method="POST">

	   </form>
	</body>
	</html>
	' ;


	}



?>
