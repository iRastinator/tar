<?php
$file_contents = file_get_contents('https://raw.githubusercontent.com/iRastinator/tar/main/version_info');
echo 'Доступна версия Rastinator '.$file_contents;
?>