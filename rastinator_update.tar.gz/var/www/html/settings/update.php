<?php


$fileUrl = 'https://github.com/iRastinator/tar/raw/main/rastinator_update.tar.gz';
$savePath = '../backup/rastinator_update.tar.gz';

if (copy($fileUrl, $savePath)) {
    echo 'Файл успешно скачан';
	$comand = 'sudo tar xPf /var/www/html/backup/rastinator_update.tar.gz -C /';
	$output = shell_exec($comand); 
} else {
    echo 'Ошибка при скачивании файла';
}



// Перенаправление на ту же страницу после выполнения скрипта
header("Location: index.php");
exit;
?>
   
