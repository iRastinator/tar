
<?php


$file =  "/var/www/html/backup/rastinator_backup.tar.gz";

// Команда  tar только система /var/www/html 	  
if ($_POST['only_system'] == "on") 
    {   
		$comand = 'tar --exclude=/var/www/html/backup --exclude=/var/www/html/log/log_watering --exclude=/var/www/html/token -zcvf '.$file.' /var/www/html/*';
		shell_exec($comand);  
    }

else	
	{  // Все данные

		$comand = 'sudo service domoticz restart';
		$output = shell_exec($comand);

		$comand = 'tar --exclude=/var/www/html/backup --exclude=/var/www/html/log/log_watering --exclude=/var/www/html/token -zcvf '.$file.' /var/www/html/* /home/pi/domoticz/scripts/lua/* /home/pi/domoticz/domoticz.db';

		shell_exec($comand);

		//$comand = 'sudo service domoticz start';
		//$output = shell_exec($comand);
	}
// Процесс загрузки
  if (file_exists($file)) {
    // сбрасываем буфер вывода PHP, чтобы избежать переполнения памяти выделенной под скрипт
    // если этого не сделать файл будет читаться в память полностью!
    if (ob_get_level()) {
      ob_end_clean();
    }
    // заставляем браузер показать окно сохранения файла
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename=' . basename($file));
    header('Content-Transfer-Encoding: binary');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($file));
    // читаем файл и отправляем его пользователю
    readfile($file);
    exit;
  }

//$comand = 'rm -f ras_back_up.tar.gz';
//$output = shell_exec($comand);

    
?>