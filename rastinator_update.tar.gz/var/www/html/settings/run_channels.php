<?php



$cmd = '/home/pi/bin/show_gpio';
$text = shell_exec($cmd);
//Этот код извлечет числа после слова "GPIO" в качестве ключей массива и определит значение для каждого ключа на основе значения "func". Строки, где "func" имеет значения отличные от "INPUT" и "OUTPUT", не будут включены в итоговый массив.
$matches = array();
preg_match_all("/GPIO (\d+):.*func=(\w+)/", $text, $matches, PREG_SET_ORDER);
$result = array();
foreach($matches as $match) {
	if ($match[2] == 'INPUT') {
		$result[$match[1]] = 0;
	} elseif ($match[2] == 'OUTPUT') {
		$result[$match[1]] = 1;
	}
}

$ifo_gpio = array(
					"ch1-1" => 10, "ch2-1" => 6,
					"ch1-2" => 9,  "ch2-2" => 12,
					"ch1-3" => 25, "ch2-3" => 13, 
					"ch1-4" => 11, "ch2-4" => 19,
					"ch1-5" => 8,  "ch2-5" => 16,
					"ch1-6" => 7,  "ch2-6" => 26,
					"ch1-7" => 5,  "ch2-7" => 20
				 );

//Этот код создаст новый массив, используя ключи из $ifo_gpio и их соответствующие значения из первого массива. Ключи из $ifo_gpio будут использоваться для нового массива, а их значения из первого массива будут присвоены ключам в новом массиве.
$new_array = array();
foreach($ifo_gpio as $key => $value) {
	$new_array[$key] = $result[$value];
}
//print_r($new_array); // Вывод результирующего массива








if ($new_array['ch'.$_GET['param2']."-".$_GET['param']] ==  0)
{$cmd = "/home/pi/bin/ch".$_GET['param2']."-".$_GET['param'].' 1';}

if ($new_array['ch'.$_GET['param2']."-".$_GET['param']] ==  1)
{$cmd = "/home/pi/bin/ch".$_GET['param2']."-".$_GET['param'].' 0';}


if ( (int)$_GET['param2'] > 2 )
{$cmd = "sudo /home/pi/bin/ch".$_GET['param2']."-".$_GET['param'].' '.$_GET['param3'];}

shell_exec($cmd);
?>

