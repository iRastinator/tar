<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Rastinator</title>
<script type="text/javascript" src="/ajax/jquery-3.7.0.min.js"></script>
<style>
         @import "../style.css" screen; /* Стиль для вывода результата на монитор */
         @import "../style.css" print, handheld; /* Стиль для печати и смартфона */
    
                    *{
    padding: 0%;
    margin: 0%;
            }
            .container{
            grid-template-columns: auto;
            display: grid;
            
    
          }
          
          .item {
              
              padding: 0px;
              border: 0px solid black;
                        
            }


    
</style>      
          
</head>

<body>


<?php
	
//var_dump($_POST);	//exit();
//Авторизация
include('../login/in.php');    
    
function debug_to_console($data) {
    $output = $data;
    if (is_array($output))
        $output = implode(',', $output);
    echo "<script>console.log('Debug Objects: " . $output . "' );</script>";
}    
?>
    
    
    
<div class="container">

<!-- Верхнее меню -->     
<div class="item item_1">
        <ul>
          <li><svg width="clamp(6.25rem, 3.977rem + 11.36vw, 12.5rem)" height="clamp(1.4rem, 0.369rem + 2.84vw, 2.5rem)" viewBox="150 -30 180 180"> <?php include('../pic/Rastinator.svg'); ?> </svg> </li>
          <li><a href="../poliv/index.php" >Полив</a></li>    
          <li><a href="../climat/index.php">Климат</a></li>
          <li><a href="../sensors/index.php">Датчики</a></li>
          <li><a class="active" >Настройки</a></li>
          <li><a href="../log_poliva/index.php">Журнал полива</a></li>
          <li><a href="../log_domoticz/index.php">Лог системы</a></li>

        </ul>  
    

    
</div>              

<!-- Информационная панель - отображение данных лога -->     
<div class="item item_2" >
                               
             <script type="text/javascript">        
                $(document).ready(function() 
                { 
                var func = function() {$("#info").load('../log/log.php');}
                setInterval(func, 2000);

                });

            </script>                                

    
            <div id="info" >
               <?php include('../log/log.php'); ?>
                
            </div> 
</div>  
    
    
<!-- item item_4 - Кнопки  -  ----------> 
<div class="item item_3">
    
                                                  


<div class="btn-group">

	<a class="btn_pag"  href="index.php" >Вернуться в настройки</a> 
	
  
</div> 
    
 

</div> 

    
    
<!--   -->
<div class="item item_4">
	
		<?php

		$filename = '/home/pi/domoticz/scripts/lua/script_device_pumps_calibration.lua';
		$file = fopen($filename, 'r');
		$pump = [];
		$required_volume;
		$division;

		for ($i = 0; $i < 50; $i++) 
		  {

			$stroka = fgets($file);


			// Выборка калибровочный объем
			if (substr($stroka , 0, 19) == 'set_required_volume')
				{
					$pos1 = strripos($stroka, '=');
					$pos2 = strlen ($stroka);
					$required_volume =  trim(substr($stroka , $pos1+2 , $pos2-$pos1-3));

				}

			// Выборка деление ml
			if (substr($stroka , 0, 12) == 'set_division')
				{
					$pos1 = strripos($stroka, '=');
					$pos2 = strlen ($stroka);
					$division =  trim(substr($stroka , $pos1+2 , $pos2-$pos1-3));

				}

			// Выборка 	объемов  
			if (substr($stroka , 0, 8) == 'set_pump')
				{
				$pump_number =  substr($stroka , strripos($stroka, '[')+1 , strripos($stroka, ']')-strripos($stroka, '[')-1 ) ;

				$pos1 = strripos($stroka, '=');
				$pos2 = strlen ($stroka);
				$value =  trim(substr($stroka , $pos1+2 , $pos2-$pos1-3));

				if ($value == '0'){ $value = '';}
				
				$pump[$pump_number]	= $value;
				}


		  }
	
	
	// Выбираем значение pumps_calibraton
	$comand = 'curl "127.0.0.1:8080/json.htm?type=command&param=getuservariables" | '."jq '.result[] | select(.Name==".'"pumps_calibraton"'.") | .Value' | sed 's/".'"'."//g'" ;
	$value = shell_exec($comand);
	$calibration_data = explode(",", $value);
	
		?>
	
   <div class="settings_palel">
   <form id="form_cal" method="POST" action="calibration_save_file.php">
	   	<p class="settins_label">Калибровка дозировочных насосов</p>
    <div class="div_content_settings_panel">   
	   
	   		<label class="labels" for="cal_value" >Объем жидкости для калибровки</label>
			<input  class="input_calibration" type="text" id="cal_value"  name="cal_value"  value="<?php echo $required_volume; ?>"  autocomplete="off" onkeydown="if(event.keyCode==13){return false;}">
	   		<label class="labels" for="cal_value" > мл</label>     
	   		<br>
	     	<label class="labels" for="division">На сколько раз делиться 1мл:</label>
			<input  class="input_calibration" type="text" id="division"  name="division"  value="<?php echo $division; ?>"  autocomplete="off" onkeydown="if(event.keyCode==13){return false;}">
	   		<label class="labels" for="division"> - такой же как у профилей растений!</label>
	   		<br>  <br>
	   
		   <?php
					for ($n = 1; $n <= 7; $n++) 
					{
					echo '
					<label class="labels" for="pump_cal_'.$n.'">#'.$n.'</label>

					<input  class="input_calibration" type="text" id="pump_cal_'.$n.'"  name="pump_cal_'.$n.'"  value="'.$pump[$n].'"  autocomplete="off" onkeydown="if(event.keyCode==13){return false;}">

					<label class="labels" for="pump_cal_'.$n.'">мл &nbsp;&nbsp;&nbsp;&nbsp :'.round($calibration_data[$n-1], 3).'</label>


					<br>
					';


					}


			?>

	   
	    <br> 
	   </div>
	  
	    <input class="button_text" type="submit" name="start" value="Начать калибровку" onclick="return confirm('Для начала калибровки дозировочных насосв убедитесь что статус полива выключен!')">
	   	
	   <a class="button_text" href="off_reboot.php?reboot_domoticz" >Остановить калибровку</a>
	   
	   
	   <input class="button_text" type="submit" name="reset_calibraton_data" value="Сбросить калибровочные значения" onclick="return confirm('Внимание! Будут сброшены калибровочные значения дозировочных насосов! Необходима дальнейшая калибровка!')">
	   
	</form>    
	</div>
	
	<!-- включение насосов --->
	<div class="settings_palel">
		 	<p class="settins_label">Включение дозировочных насосов</p>
		 <div class="div_content_settings_panel">
		<label class="labels" for="inputParam" >Время включения насосов</label>
		<input class="input_calibration" type="text" id="inputParam" value="1" placeholder="Введите значение для параметра 2">
		<label class="labels" for="inputParam" >секунд</label>
		</div>
		<br>
		<div style="display :flex; width :100%; flex-direction :row ; justify-content:space-evenly ; align-items: stretch ;">
			  <?php
for ($n = 1; $n <= 7; $n++) {
    echo '
        
        <button class="button_text" id="executeCommand' . $n . '">' . $n . '</button>
		
        
        <script>
            document.getElementById(\'executeCommand' . $n . '\').addEventListener(\'click\', function() {
                var parameterValue = \'' . $n . '\'; // Установка значения параметра
				
				var parameterValue2 = document.getElementById(\'inputParam\').value; // Получение значения второго параметра из input
				
                var xhr = new XMLHttpRequest();
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === XMLHttpRequest.DONE) {
                        if (xhr.status === 200) {
                            // Обработка ответа от сервера, если необходимо
                            console.log(xhr.responseText);
                        } else {
                            console.error(\'Произошла ошибка при выполнении запроса\');
                        }
                    }
                };
               var url = \'run_pumps.php?param=\' + parameterValue + \'&param2=\' + parameterValue2; // Добавление обоих параметров к URL запроса
                xhr.open(\'GET\', url, true);
                xhr.send();
            });
        </script>

    ';
}
?>

	
	</div>
	</div>

</div>

    
    
  </body>
</html>
