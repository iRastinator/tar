<?php

$cmd = "/home/pi/bin/pump".$_GET['param'].' 1; sleep '.$_GET['param2'].';'."/home/pi/bin/pump".$_GET['param'].' 0';



shell_exec($cmd);





?>

