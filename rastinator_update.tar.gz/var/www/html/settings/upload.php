<?php
$target_dir = "/var/www/html/backup/";
//$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$target_file = $target_dir . 'upload.tar.gz';
$uploadOk = 1;
//var_dump($_POST); exit();

// Проверка, не установлено ли для $uploadOk значение 0 из-за ошибки
if ($uploadOk == 0) {
  echo "К сожалению, ваш файл не был загружен";
// если все в порядке, поробуем загрузить файл
} else {
  if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) 
  {
    echo "Файл ". htmlspecialchars( basename( $_FILES["fileToUpload"]["name"]))." был загружен";
      
    $comand = 'sudo service domoticz stop';
    $output = shell_exec($comand);
        
      
      
    // стирать страрые профили 
    if ($_POST['without_old_scrips'] == "on" )
    {
    $comand = 'rm -f /home/pi/domoticz/scripts/lua/*plant*';
    $output = shell_exec($comand); 
    $comand = 'rm -f /home/pi/domoticz/scripts/lua/*climat*';
    $output = shell_exec($comand);   
        
    }
      
 	$comand = 'sudo tar xPf /var/www/html/backup/upload.tar.gz -C /';
	  
    // Команда Распоковка tar с базой    
    if ($_POST['without_bd'] == "on") 
    {   
    // Команда Распоковка tar без базы
    $comand = 'sudo tar xPf /var/www/html/backup/upload.tar.gz --exclude="home/pi/domoticz/domoticz.db" -C /';
    } 
	
    $output = shell_exec($comand); 
       
      
    //   
    $comand = 'sudo chown -R pi:www-data /var/www/html/';
    $output = shell_exec($comand);
    $comand = 'sudo chmod -R 770 /var/www/html/';
    $output = shell_exec($comand);
      
    
    // тоже для /home/pi/domoticz/scripts/lua
    $comand = 'sudo /bin/chown -R pi:www-data /home/pi/domoticz/scripts/lua';
    $output = shell_exec($comand);
    $comand = 'sudo /bin/chmod -R 770 /home/pi/domoticz/scripts/lua';
    $output = shell_exec($comand);
      
          // тоже для /home/pi/domoticz/bd
    $comand = 'sudo /bin/chown -R pi:www-data /home/pi/domoticz/domoticz.db';
    $output = shell_exec($comand);
    $comand = 'sudo /bin/chmod -R 770 /home/pi/domoticz/domoticz.db';
    $output = shell_exec($comand);
    
    echo '<br>';
    echo 'Пререзагрузка, ждём 1 минуту.';
    
  //  $comand = 'sudo reboot';
//$comand = 'sudo service domoticz start';
 //   $output = shell_exec($comand);
      
header("Location: off_reboot.php?reboot");
exit;
 
   

   
      
  } else {
    echo "К сожалению, при загрузке вашего файла произошла ошибка";
  }
}

 


?>