<?php

// Включаем отображение ошибок для отладки
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Проверяем наличие файла autoload.php
$autoloadFile = __DIR__ . '/vendor/autoload.php';

if (!file_exists($autoloadFile)) {
    die("Ошибка: не найден файл vendor/autoload.php. Выполните 'composer install' в директории " . __DIR__);
}

require $autoloadFile;

use phpseclib3\Net\SSH2;
use phpseclib3\Crypt\RSA;

function testConnection($remoteIP, $username, $password, $port = 22) {
    try {
        echo "Тестирование подключения к $remoteIP:$port...\n";
        $ssh = new SSH2($remoteIP, $port);
        if (!$ssh->login($username, $password)) {
            throw new Exception("Ошибка авторизации");
        }

        $result = $ssh->exec('echo "Test connection successful"');
        echo "Результат: $result\n";
        return true;
    } catch (Exception $e) {
        echo "Ошибка подключения: " . $e->getMessage() . "\n";
        return false;
    }
}

function generateAndSaveSSHKeys($keysDir) {
    echo "Проверка существующих SSH ключей...\n";

    // Определяем пути к ключам
    $privateKeyPath = $keysDir . '/id_rsa';
    $publicKeyPath = $keysDir . '/id_rsa.pub';

    // Проверяем, существуют ли ключи
    if (file_exists($privateKeyPath) && file_exists($publicKeyPath)) {
        echo "SSH ключи уже существуют, используя существующие ключи...\n";
        return file_get_contents($publicKeyPath); // Возвращаем существующий публичный ключ
    }

    echo "Генерация SSH ключей...\n";

    // Создаем ключ RSA
    $rsa = RSA::createKey(2048); // Создание ключа RSA

    $privateKey = $rsa->toString('PKCS8'); // Приватный ключ в PKCS8 формате
    $publicKey = $rsa->getPublicKey()->toString('OpenSSH'); // Публичный ключ в формате OpenSSH

    // Проверяем и создаем директорию, если это необходимо
    if (!file_exists($keysDir)) {
        if (!mkdir($keysDir, 0700, true) && !is_dir($keysDir)) {
            throw new Exception("Не удалось создать директорию $keysDir. Проверьте права доступа.");
        }
    }

    // Сохраняем ключи локально
    if (file_put_contents($privateKeyPath, $privateKey) === false) {
        throw new Exception("Не удалось записать приватный ключ в файл.");
    }

    if (file_put_contents($publicKeyPath, $publicKey) === false) {
        throw new Exception("Не удалось записать публичный ключ в файл.");
    }

    chmod($privateKeyPath, 0600); // Устанавливаем права на приватный ключ
    chmod($publicKeyPath, 0644);   // Устанавливаем права на публичный ключ

    echo "SSH ключи успешно сгенерированы.\n";
    
    return $publicKey; // Возвращаем публичный ключ
}


function setupRemotePublicKeyOnLocal($localPublicKey) {
    // Добавляем публичный ключ удаленной машины в авторизованные ключи локальной машины
    $localAuthorizedKeys = '/var/www/.ssh/authorized_keys';

    // Проверка и создание директории для ключей на локальной машине
    if (!file_exists(dirname($localAuthorizedKeys))) {
        mkdir(dirname($localAuthorizedKeys), 0700, true);
    }

    // Если файл authorized_keys существует
    if (file_exists($localAuthorizedKeys)) {
        // Читаем существующие ключи
        $existingKeys = file_get_contents($localAuthorizedKeys);
        
        // Проверяем, содержится ли ключ в существующих ключах
        if (strpos($existingKeys, trim($localPublicKey)) === false) {
            // Если ключа нет, добавляем его
            file_put_contents($localAuthorizedKeys, $localPublicKey . PHP_EOL, FILE_APPEND);
            chmod($localAuthorizedKeys, 0600);
            echo "Публичный ключ удаленной машины добавлен в авторизованные ключи локальной машины.\n";
        } else {
            echo "Публичный ключ уже существует в authorized_keys на локальной машине.\n";
        }
    } else {
        // Если файл не существует, создаем его и добавляем ключ
        file_put_contents($localAuthorizedKeys, $localPublicKey . PHP_EOL);
        chmod($localAuthorizedKeys, 0600);
        echo "Файл authorized_keys создан и публичный ключ добавлен.\n";
    }
}


function generateKeysOnRemoteServer($ssh) {
    echo "Проверка существующих SSH ключей на удаленной машине...\n";

    // Проверяем существование приватного и публичного ключей
    $publicKeyExists = $ssh->exec('test -f ~/.ssh/id_rsa.pub && echo "exists"'); // Проверка наличия публичного ключа
    $privateKeyExists = $ssh->exec('test -f ~/.ssh/id_rsa && echo "exists"'); // Проверка наличия приватного ключа

    if (trim($publicKeyExists) === 'exists' && trim($privateKeyExists) === 'exists') {
        echo "SSH ключи уже существуют на удаленной машине, используя существующие ключи...\n";
        return; // Выходим из функции, если ключи уже существуют
    }

    // Если ключи не существуют, генерируем их
    echo "Генерация SSH ключей на удаленной машине...\n";
    
    $ssh->exec('mkdir -p ~/.ssh');
    $ssh->exec('chmod 700 ~/.ssh');
    $ssh->exec('ssh-keygen -t rsa -b 2048 -f ~/.ssh/id_rsa -N ""'); // Генерация ключа без пароля
    $ssh->exec('chmod 600 ~/.ssh/id_rsa');
    $ssh->exec('chmod 644 ~/.ssh/id_rsa.pub');

    echo "SSH ключи успешно сгенерированы на удаленной машине.\n";
}


function setupSSHKeys($remoteIP, $username, $password, $port = 22) {
    try {
        // Проверяем подключение к удаленной машине
        if (!testConnection($remoteIP, $username, $password, $port)) {
            throw new Exception("Не удалось установить тестовое подключение");
        }

        // Создаем SSH подключение к удаленной машине
        $ssh = new SSH2($remoteIP, $port);
        if (!$ssh->login($username, $password)) {
            throw new Exception("Ошибка авторизации");
        }

        // Генерация SSH ключей локально
        $keysDir = '/var/www/.ssh';
        $localPublicKey = generateAndSaveSSHKeys($keysDir);

        // Генерация SSH ключей на удаленной машине
        generateKeysOnRemoteServer($ssh);

        // Установка необходимостей на удаленной машине
        echo "Настройка удаленного сервера...\n";
        $ssh->exec('chmod 700 ~/.ssh');

        // Добавляем локальный публичный ключ на удаленный сервер
        $addKeyCommand = 'echo "' . trim($localPublicKey) . '" >> ~/.ssh/authorized_keys';
        $ssh->exec($addKeyCommand);
        $ssh->exec('chmod 600 ~/.ssh/authorized_keys');

        // Проверяем, что ключ добавлен
        $result = $ssh->exec('cat ~/.ssh/authorized_keys');
        if (strpos($result, trim($localPublicKey)) === false) {
            throw new Exception("Ошибка при добавлении публичного ключа на удаленной машине");
        }

        echo "Публичный ключ локальной машины успешно добавлен на удаленный сервер.\n";

        // Теперь добавляем публичный ключ удаленной машины на локальную машину
        setupRemotePublicKeyOnLocal($ssh->exec('cat ~/.ssh/id_rsa.pub'));

        return [
            'private_key_path' => $keysDir . '/id_rsa',
            'public_key_path' => $keysDir . '/id_rsa.pub',
        ];
        
		// Закрываем SSH-соединение
        $ssh->disconnect();
		
		
    } catch (Exception $e) {
        echo "Ошибка: " . $e->getMessage() . "\n";
        return false;
    }
}

// Параметры подключения
$remoteIP = "192.168.1.65"; // Замените на нужный IP
$username = "pi";           // Замените на нужное имя пользователя
$password = "userras";     // Замените на нужный пароль
$port = 22;                 // SSH порт (по умолчанию 22)

// Выполняем настройку
$result = setupSSHKeys($remoteIP, $username, $password, $port);

if ($result) {
    echo "\nУспешно!\n";
    echo "Приватный ключ сохранен в: " . $result['private_key_path'] . "\n";
    echo "Публичный ключ сохранен в: " . $result['public_key_path'] . "\n";
} else {
    echo "\nПроизошла ошибка при установке ключей.\n";
}





//Копируем authorized_keys из /var/www/.ssh в /home/pi/.ssh


// Путь к директории .ssh для www-data
$sourceDir = '/var/www/.ssh/';

// Путь к директории .ssh для pi
$destinationDir = '/home/pi/.ssh/';

try {
    // Проверка существования исходной директории
    if (!is_dir($sourceDir)) {
        throw new Exception("Директория $sourceDir не найдена.");
    }

    // Команды для копирования всех файлов и папок
    $copyCommand = "sudo cp -r $sourceDir* $destinationDir";

    // Устанавливаем владельца для всех файлов в целевой директории
    $chownCommand = "sudo chown -R pi:pi $destinationDir";
    // Устанавливаем права доступа для директории
    $chmodCommand = "sudo chmod 700 $destinationDir"; // Права на директорию
    // Устанавливаем права доступа для всех файлов в целевой директории
    $chmodFilesCommand = "sudo chmod 600 $destinationDir*"; // Права на файлы

    // Выполняем команды
    shell_exec($copyCommand);
    shell_exec($chownCommand);
    shell_exec($chmodCommand);
    shell_exec($chmodFilesCommand);

    echo "Все файлы из директории .ssh успешно скопированы и заменены для пользователя pi.\n";

} catch (Exception $e) {
    echo "Ошибка: " . $e->getMessage() . "\n";
}





?>