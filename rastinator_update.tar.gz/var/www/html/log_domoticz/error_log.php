
<?php

$comand = 'tail -n250 /var/www/html/log/error_detected.log | cat -E ';// -E добовляет $ в конец строки
//разбиваем одну большую строку на массив строк
$arr = explode( '$' , shell_exec($comand));
$arr= array_reverse($arr);
foreach ($arr as $line) {
 echo '<span style="color: darkviolet;">' . $line . "</span><br>";    
}


?>