<!DOCTYPE html>
<html>

<head>
<meta name = "viewport" content = "width=device-width, initial-scale=1">
	<meta charset="utf-8" />
	<title>Rastinator</title>
	<script type="text/javascript" src="/ajax/jquery-3.7.0.min.js"></script>
	<style>
		@import "../style.css"screen;
		/* Стиль для вывода результата на монитор */
		@import "../style.css"print, handheld;
		/* Стиль для печати и смартфона */

		* {
			padding: 0%;
			margin: 0%;

		}

		body {
			background-color: gainsboro;
		}

		.container {
			grid-template-columns: auto;
			display: grid;


		}

		.item {

			padding: 0px;
			border: 0px solid black;

		}

	</style>

</head>

<body>


	<?php
//Авторизация
include('../login/in.php');    
    
function debug_to_console($data) {
    $output = $data;
    if (is_array($output))
        $output = implode(',', $output);
    echo "<script>console.log('Debug Objects: " . $output . "' );</script>";
} 

?>



	<div class="container">

		<!-- Верхнее меню -->
		<div class="item item_1">
			<ul>
				<li><svg width="clamp(6.25rem, 3.977rem + 11.36vw, 12.5rem)" height="clamp(1.4rem, 0.369rem + 2.84vw, 2.5rem)" viewBox="150 -30 180 180"> <?php include('../pic/Rastinator.svg'); ?> </svg> </li>
				<li><a href="../poliv/index.php">Полив</a></li>
				<li><a href="../climat/index.php">Климат</a></li>
				<li><a href="../sensors/index.php">Датчики</a></li>
				<li><a href="../settings/index.php">Настройки</a></li>
				<li><a href="../log_poliva/index.php">Журнал полива</a></li>
				<li><a class="active" href="">Лог системы</a></li>

			</ul>



		</div>

		<!-- Информационная панель - отображение данных лога -->
		<div class="item item_2">

			<script type="text/javascript">
				$(document).ready(function() {
					var func = function() {
						$("#info").load('../log/log.php');
					}
					setInterval(func, 2000);

				});

			</script>


			<div id="info">
				<?php include('../log/log.php'); ?>

			</div>
		</div>


		<!-- item item_4 - Кнопки  -  ---------->
		<div class="item item_3">



			<?php 
		if (isset($_POST['clear_log']))
		{
			$command = 'echo -n > /var/www/html/log/error_detected.log';
			shell_exec($command);	
			
		}
	?>

			<div class="btn-group">
				<form id="clear" method="POST" action="index.php">
					<?php 
	if (isset($_POST['error_button'])) 
	{
	echo'
	<button class="button" name="clear_log" id="clear_log" type="submit" onclick="return confirm(\'Вы уверены, что хотите очистить Журнал?\')"  >Очистить</button>';
	}
	?>
				</form>





				<a class="btn_pag" name="b_download" <?php if (isset($_POST['error_button']))  {echo 'href="../log/error_detected.log"';} else {echo 'href="../log_domoticz/domoticz.txt"';}?> download>Скачать весь журнал</a>


				<form id="error_form" method="POST" action="index.php">

					<button class="button" id="error_button" onclick="toggleLog()" name=<?php if (isset($_POST['error_button']))  {echo '"log_button" >Переключить на лог';} else {echo '"error_button" >Лог ошибок';} ?> </button>


				</form>



			</div>




		</div>






		<!--  Ajax загрузка лога домотикз каждые -->


		<script>
			$(window).on('load', function() {
				var resultDiv = $('#result');

				function refreshData() {
					$.ajax({

						<?php
		
		if (isset($_POST['error_button']))  
		   {echo "url: 'error_log.php',";}
		else {echo "url: 'sys_log.php',";}
		
		?>
						success: function(data) {
							resultDiv.html(data);
						},
						complete: function() {
							setTimeout(refreshData, 10000); // Запуск нового запроса через 10 000 миллисекунд (10 секунд)
						}
					});
				}

				$(window).on('resize', function() {
					resultDiv.height($(window).height()); // Установка высоты блока результатов равной высоте окна браузера при изменении размера окна
				});

				$(window).trigger('resize'); // Инициирование изменения размера окна

				refreshData();
			});

		</script>


		<div class="log_domoticz" id="result"></div>

	</div>




</body>

</html>
