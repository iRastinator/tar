Place your scripts you want to be executed by domoticz in here.

Special scripts:
domoticz_main (on windows domoticz_main.bat), will be executed when a switch is pressed (On/Off)
to use this script, remove the underscore in front of the filename
