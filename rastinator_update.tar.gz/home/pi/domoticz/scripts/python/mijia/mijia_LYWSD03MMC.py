import sys
from bluepy.btle import Peripheral, BTLEDisconnectError
import struct
import time
import requests
from multiprocessing import Process, Queue
import signal

def connect_with_retry(mac_address, max_retries=3):
    for retry in range(max_retries):
        try:
            print(f"Попытка подключения {retry + 1} из {max_retries}")
            device = Peripheral(mac_address)
            print("Успешное подключение!")
            return device
        except BTLEDisconnectError as e:
            print(f"Ошибка подключения: {e}")
            if retry < max_retries - 1:
                print("Ожидание перед повторной попыткой...")
                time.sleep(3)
            else:
                raise

def send_data_to_domoticz(domoticz_ip, idx_temp, temperature, humidity, battery):
    url = f"http://{domoticz_ip}:8080/json.htm?type=command&param=udevice&idx={idx_temp}&nvalue=0&svalue={temperature:.1f};{humidity};0&battery={battery}"
    try:
        response = requests.get(url, timeout=5)  # Таймаут для HTTP-запроса
        if response.status_code == 200:
            print("Данные успешно отправлены на Domoticz.")
        else:
            print(f"Ошибка при отправке данных: {response.status_code} {response.text}")
    except Exception as e:
        print(f"Ошибка запроса: {e}")

def worker(mac_address, domoticz_ip, idx_temp, queue):
    try:
        device = connect_with_retry(mac_address)
        temp_humid_uuid = "ebe0ccc1-7a0a-4b0c-8a1a-6ff2997da3a6"
        temp_char = device.getCharacteristics(uuid=temp_humid_uuid)[0]
        data = temp_char.read()
        temperature = struct.unpack('<h', data[0:2])[0] / 100.0
        humidity = data[2]
        battery_uuid = "00002a19-0000-1000-8000-00805f9b34fb"
        battery_char = device.getCharacteristics(uuid=battery_uuid)[0]
        battery = ord(battery_char.read())
        device.disconnect()
        if idx_temp != "-1":
            send_data_to_domoticz(domoticz_ip, idx_temp, temperature, humidity, battery)
        queue.put((True, temperature, humidity, battery))
    except Exception as e:
        queue.put((False, str(e)))

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Использование: python3 script.py <IP> <MAC> <IDX>")
        sys.exit(1)

    domoticz_ip = sys.argv[1]
    mac_address = sys.argv[2]
    idx_temp = sys.argv[3]

    queue = Queue()
    p = Process(target=worker, args=(mac_address, domoticz_ip, idx_temp, queue))
    p.start()
    p.join(timeout=30)  # Таймаут 30 секунд

    if p.is_alive():
        p.terminate()
        p.join()
        print("Ошибка: превышено время выполнения скрипта (30 секунд)")
        sys.exit(1)

    success, *result = queue.get()
    if not success:
        print(f"Ошибка: {result[0]}")
        sys.exit(1)
    
    temperature, humidity, battery = result
    print(f"Температура: {temperature:.1f}°C")
    print(f"Влажность: {humidity}%")
    print(f"Заряд батареи: {battery}%")
