from bluepy.btle import Peripheral, UUID, BTLEDisconnectError
import struct
import time

mac_address = "A4:C1:38:B2:39:F1"

def connect_with_retry(mac_address, max_retries=3):
    for retry in range(max_retries):
        try:
            print(f"Попытка подключения {retry + 1} из {max_retries}")
            device = Peripheral(mac_address)
            print("Успешное подключение!")
            return device
        except BTLEDisconnectError as e:
            print(f"Ошибка подключения: {e}")
            if retry < max_retries - 1:
                print("Ожидание перед повторной попыткой...")
                time.sleep(3)
            else:
                raise

try:
    device = connect_with_retry(mac_address)
    
    # UUID для температуры и влажности LYWSD03MMC
    temp_humid_uuid = "ebe0ccc1-7a0a-4b0c-8a1a-6ff2997da3a6"
    
    # Получаем характеристику
    temp_char = device.getCharacteristics(uuid=temp_humid_uuid)[0]
    
    # Читаем данные
    data = temp_char.read()
    
    # Разбираем данные
    temperature = struct.unpack('<h', data[0:2])[0] / 100.0
    humidity = data[2]
    
    print(f"Температура: {temperature:.1f}°C")
    print(f"Влажность: {humidity}%")
    
    # Также получим уровень заряда батареи
    battery_uuid = "00002a19-0000-1000-8000-00805f9b34fb"
    battery_char = device.getCharacteristics(uuid=battery_uuid)[0]
    battery = ord(battery_char.read())
    
    print(f"Заряд батареи: {battery}%")

except Exception as e:
    print(f"Ошибка: {e}")
finally:
    try:
        device.disconnect()
    except:
        pass
