from bluepy.btle import Peripheral, UUID, BTLEDisconnectError
import struct
import time

# MAC-адрес вашего устройства
mac_address = "4c:65:A8:DF:05:5C"

# UUID для датчиков
sensors = {
    "LYWSD03MMC": {
        "temp_humid_uuid": "ebe0ccc1-7a0a-4b0c-8a1a-6ff2997da3a6",
        "battery_uuid": "00002a19-0000-1000-8000-00805f9b34fb"
    },
    "MJ_HT_V1": {
        "temp_humid_uuid": "00001800-0000-1000-8000-00805f9b34fb",  # Замените на актуальный UUID для MJ_HT_V1
        "battery_uuid": "0000180f-0000-1000-8000-00805f9b34fb"  # Замените на актуальный, если нужно
    }
}

def connect_with_retry(mac_address, max_retries=3):
    for retry in range(max_retries):
        try:
            print(f"Попытка подключения {retry + 1} из {max_retries}")
            device = Peripheral(mac_address)
            print("Успешное подключение!")
            return device
        except BTLEDisconnectError as e:
            print(f"Ошибка подключения: {e}")
            if retry < max_retries - 1:
                print("Ожидание перед повторной попыткой...")
                time.sleep(3)
            else:
                raise

def identify_sensor(device):
    """Определяет тип датчика на основе_UUID характеристик"""
    try:
        characteristics = device.getCharacteristics()
        for char in characteristics:
            if char.uuid == UUID(sensors["LYWSD03MMC"]["temp_humid_uuid"]):
                return "LYWSD03MMC"
            elif char.uuid == UUID(sensors["MJ_HT_V1"]["temp_humid_uuid"]):
                return "MJ_HT_V1"
    except Exception as e:
        print(f"Ошибка при определении типа датчика: {e}")
    return None

def get_sensor_data(device, sensor_type):
    """Получает данные от датчика в зависимости от его типа"""
    if sensor_type == "LYWSD03MMC":
        temp_humid_uuid = sensors["LYWSD03MMC"]["temp_humid_uuid"]
        temp_char = device.getCharacteristics(uuid=temp_humid_uuid)[0]
        data = temp_char.read()

        temperature = struct.unpack('<h', data[0:2])[0] / 100.0
        humidity = data[2]

        print(f"Температура: {temperature:.1f}°C")
        print(f"Влажность: {humidity}%")

    elif sensor_type == "MJ_HT_V1":
        temp_humid_uuid = sensors["MJ_HT_V1"]["temp_humid_uuid"]
        temp_char = device.getCharacteristics(uuid=temp_humid_uuid)[0]
        data = temp_char.read()

        # В зависимости от спецификации MJ_HT_V1, данные могут различаться, это пример
        temperature = struct.unpack('<h', data[0:2])[0] / 100.0  # Пример, адаптируйте по необходимости
        humidity = struct.unpack('<B', data[2:3])[0]  # Пример, адаптируйте по необходимости

        print(f"Температура: {temperature:.1f}°C")
        print(f"Влажность: {humidity}%")

    # Получаем уровень заряда батареи
    battery_uuid = sensors[sensor_type]["battery_uuid"]
    battery_char = device.getCharacteristics(uuid=battery_uuid)[0]
    battery = ord(battery_char.read())

    print(f"Заряд батареи: {battery}%")

# Главная логика выполнения
try:
    device = connect_with_retry(mac_address)

    # Определяем тип датчика
    sensor_type = identify_sensor(device)

    if sensor_type:
        print(f"Определен тип датчика: {sensor_type}")
        get_sensor_data(device, sensor_type)
    else:
        print("Тип датчика не распознан.")

except Exception as e:
    print(f"Ошибка: {e}")

finally:
    try:
        device.disconnect()
    except:
        pass

