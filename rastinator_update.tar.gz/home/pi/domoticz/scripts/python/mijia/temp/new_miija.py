from datetime import datetime, timedelta
from threading import Lock
import re
from subprocess import PIPE, Popen  # Импортируем Popen и PIPE
import logging
import time
import signal
import os

MI_TEMPERATURE = "temperature"
MI_HUMIDITY = "humidity"
MI_BATTERY = "battery"

LOGGER = logging.getLogger(__name__)
LOCK = Lock()

def write_readnotif_ble(mac, handle, value, retries=3, timeout=20, adapter='hci0'):
    global LOCK
    attempt = 0
    LOGGER.debug("Enter write_readnotif_ble")

    while attempt <= retries:
        cmd = "gatttool --device={} --char-write-req -a {} -n {} --adapter={} --listen".format(mac, handle, value, adapter)

        with LOCK:
            LOGGER.debug("Running gatttool")
            with Popen(cmd, shell=True, stdout=PIPE, preexec_fn=os.setsid) as process:
                try:
                    result = process.communicate(timeout=timeout)[0]
                    result = result.decode("utf-8").strip(' \n\t')
                    LOGGER.debug("Got %s", result)
                    res = re.search("( [0-9a-fA-F][0-9a-fA-F])+", result)
                    if res:
                        return [int(x, 16) for x in res.group(0).split()]
                except TimeoutExpired:
                    os.killpg(process.pid, signal.SIGINT)

        attempt += 1
        time.sleep(2)

    LOGGER.debug("Exit write_readnotif_ble, no data")
    return None

def read_ble(mac, handle, retries=3, timeout=20, adapter='hci0'):
    global LOCK
    attempt = 0
    LOGGER.debug("Enter read_ble")

    while attempt <= retries:
        cmd = "gatttool --device={} --char-read -a {} --adapter={}".format(mac, handle, adapter)

        with LOCK:
            with Popen(cmd, shell=True, stdout=PIPE, preexec_fn=os.setsid) as process:
                try:
                    result = process.communicate(timeout=timeout)[0]
                    result = result.decode("utf-8").strip(' \n\t')
                    LOGGER.debug("Got %s", result)
                    res = re.search("( [0-9a-fA-F][0-9a-fA-F])+", result)
                    if res:
                        return [int(x, 16) for x in res.group(0).split()]
                except TimeoutExpired:
                    os.killpg(process.pid, signal.SIGINT)

        attempt += 1
        time.sleep(2)

    LOGGER.debug("Exit read_ble, no data")
    return None

class MijiaPoller:
    def __init__(self, mac, cache_timeout=600, retries=3, adapter='hci0'):
        self._mac = mac
        self._adapter = adapter
        self._cache = None
        self.retries = retries

    def fill_cache(self):
        self._cache = write_readnotif_ble(self._mac, "0x10", "0100", retries=self.retries)
        if self._cache is None:
            print("Ошибка при получении данных")

    def parameter_value(self, parameter):
        if parameter == MI_TEMPERATURE or parameter == MI_HUMIDITY:
            self.fill_cache()
            if self._cache:
                return self._parse_data()[parameter]

    def _parse_data(self):
        data = self._cache
        temp, humid = "".join(map(chr, data)).replace("T=", "").replace("H=", "").rstrip(' \t\r\n\0').split(" ")
        return {MI_TEMPERATURE: temp, MI_HUMIDITY: humid}

# Использование
mac_address = "4c:65:A8:DF:05:5C"
sensor = MijiaPoller(mac_address)

temperature = sensor.parameter_value(MI_TEMPERATURE)
humidity = sensor.parameter_value(MI_HUMIDITY)

print(f"Температура: {temperature}°C")
print(f"Влажность: {humidity}%")
