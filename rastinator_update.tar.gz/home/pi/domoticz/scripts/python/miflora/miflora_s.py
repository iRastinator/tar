import urllib.request
import base64
import time
import os
import sys

from miflora.miflora_poller import MiFloraPoller, \
    MI_CONDUCTIVITY, MI_MOISTURE, MI_LIGHT, MI_TEMPERATURE, MI_BATTERY

# Settings for the domoticz server

# Forum see: http://domoticz.com/forum/viewtopic.php?f=56&t=13306&hilit=mi+flora&start=20#p105255

# So id devices use: sudo hcitool lescan

# Sensor IDs

# Create 4 virtual sensors in dummy hardware
# type temperature
# type lux
# type percentage (moisture)
# type custom (fertility)


import ssl
ssl_context = ssl.create_default_context()
ssl_context.check_hostname = False
ssl_context.verify_mode = ssl.CERT_NONE


#base64string = base64.encodebytes(('%s:%s' % (domoticzusername, domoticzpassword)).encode()).decode().replace('\n', '')

def domoticzrequest(url):
    # Создаем объект запроса без заголовка Authorization
    request = urllib.request.Request(url)

    context = ssl.create_default_context()
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE

    try:
        response = urllib.request.urlopen(request, context=context)
        return response.read()
    except urllib.error.URLError as e:
        print(e.reason)

def update(address,idx_moist,idx_temp,idx_lux,idx_cond):

    poller = MiFloraPoller(address)

    # reading error in poller (happens sometime, you go and bug the original author):
    #
    # 26231 fertility
    # 136% moisture
    # 4804.2 temperature
    # 61149 lux
         # 0
    loop = 1  
    try:
        temp = poller.parameter_value("temperature")
    except:
        temp = 201
               # 2 
    while loop < 1 and temp > 200:
        print("Patched: Error reading value retry after 3 seconds...\n")
        os.system('sudo service bluetooth restart')
        time.sleep(3)
        poller = MiFloraPoller(address)
        loop += 1
        try:
            temp = poller.parameter_value("temperature")
        except:
            temp = 201
    
    if temp > 200:
        print("Patched: Error reading value\n")
        return
    
    global domoticzserver

    print("Mi Flora: " + address)
    print("Firmware: {}".format(poller.firmware_version()))
    print("Name: {}".format(poller.name()))
    print("Temperature: {}°C".format(poller.parameter_value("temperature")))
    print("Moisture: {}%".format(poller.parameter_value(MI_MOISTURE)))
    print("Light: {} lux".format(poller.parameter_value(MI_LIGHT)))
    print("Fertility: {} uS/cm?".format(poller.parameter_value(MI_CONDUCTIVITY)))
    print("Battery: {}%".format(poller.parameter_value(MI_BATTERY)))

    val_bat  = "{}".format(poller.parameter_value(MI_BATTERY))
    
    # Update temp
    val_temp = "{}".format(poller.parameter_value("temperature"))
    domoticzrequest("http://" + sys.argv[1] + ":8080/json.htm?type=command&param=udevice&idx=" + idx_temp + "&nvalue=0&svalue=" + val_temp + "&battery=" + val_bat)

    # Update lux
    val_lux = "{}".format(poller.parameter_value(MI_LIGHT))
    domoticzrequest("http://" + sys.argv[1] + ":8080/json.htm?type=command&param=udevice&idx=" + idx_lux + "&svalue=" + val_lux + "&battery=" + val_bat)

    # Update moisture
    val_moist = "{}".format(poller.parameter_value(MI_MOISTURE))
    domoticzrequest("http://" + sys.argv[1] + ":8080/json.htm?type=command&param=udevice&idx=" + idx_moist + "&svalue=" + val_moist + "&battery=" + val_bat)

    # Update fertility
    val_cond = "{}".format(poller.parameter_value(MI_CONDUCTIVITY))
    domoticzrequest("http://" + sys.argv[1] + ":8080/json.htm?type=command&param=udevice&idx=" + idx_cond + "&svalue=" + val_cond + "&battery=" + val_bat)
    time.sleep(1)

# format address, moist (%), temp (°C), lux, fertility
# print("\n1: Sensor 1")
# update("C4:7C:8D:65:64:C5","1","2","3","4")

domoticzserver   = sys.argv[1]
update(sys.argv[2],sys.argv[3],sys.argv[4],sys.argv[5],sys.argv[6])




