This folder will contain scripts that are created inside Domoticz using
the internal script editor. Don't remove this folder and do not edit the scripts in
here as they will be overwritten.