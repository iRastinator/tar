**Scripts folder**

Place all your scripts in this folder. Only these scripts will be executed by dzVents. See the example folder for some script examples and check the README.md in the root for instructions.