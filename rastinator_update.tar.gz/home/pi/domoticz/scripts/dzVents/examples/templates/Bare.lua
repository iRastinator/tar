return {
	on = {
		devices = {},
		timer = {},
		variables = {},
		scenes = {},
		groups = {},
		security = {},
		httpResponses = {},
		customEvents = {},
		system = {},
	},
	data = {},
	logging = {},
	execute = function(domoticz, triggeredItem)

	end
}
