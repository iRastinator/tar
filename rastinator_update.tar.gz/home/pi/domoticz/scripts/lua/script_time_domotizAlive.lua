commandArray = {}
print('…………………………………………………………………………………………………………………')
return commandArray

