commandArray = {}
------------------------------------------------------------------------------
------------------------------ Установки -------------------------------------
Name_unit = "SampleX3"
--info: = по датчику
--separation
setm_Pump_1 = {1.50} -- label<Дозировочный насос - 1>label info<Нитрат кальция>info
setm_Pump_2 = {1.58} -- label<Дозировочный насос - 2>label info<Нитрат калия>info
setm_Pump_3 = {1.50} -- label<Дозировочный насос - 3>label info<Cульфат магния>info
setm_Pump_4 = {0.94} -- label<Дозировочный насос - 4>label info<Монофосфат калия>info
setm_Pump_5 = {2.00} -- label<Дозировочный насос - 5>label info<Аквамикс>info
setm_Pump_6 = {0} -- label<Дозировочный насос - 6>label info<>info
setm_Pump_7 = {0} -- label<Дозировочный насос - 7>label info<>info
--separation
setm_Concentration = {0.1} -- label<Концентрация EC раствора>label info<Во сколько раз будет изменена концентрация вносимых удобрений>info
--separation
sets_Day_option = "OFF" -- label<Опция День>label info<Если рецепт раствора не один: ON -  растягивает рецепт раствора на день; OFF - рецепт раствора меняется каждый полив на следующий>info
set_Time_fertilize = 0 -- label<Время полива с удобрениями>label info<Время в сек. от начала полива в течении которого вносятся удобрения>info
set_Time_clear_water = 10 -- label<Время полива чистой водой>label info<Время в сек. полива чистой водой после периода внесения удобрений>info
set_Quota = 1 -- label<Квота>label info<Во сколько раз будет изменено количество раствора>info
--separation
sets_Canal = "ch1-5" -- label<Канал полива>label info<Канал управления клапаном полива>info
--separation
set_Shift_time_watering = 89 -- label<Время очереди полива>label info<Время в минутах - определяет очередь в цикле полива или в часе полива>info
setm_Hour_watering = {} -- label<Часы полива>label info<Часы полива через запятую>info
set_Period = 3 -- label<Период полива>label info<Период повтора попытки полива  часах от начала суток  - один для всех растений  минимальный -  1 час ( только при использовании датчиков влажности )>info
set_Delay = 4 -- label<Кратность дней полива>label info<В сутках, задает кратность - в какие дни будет полив (например: 1 - каждый день,  2 -  полив по дням кратным 2 )>info
--separation
setm_Sens_id = {15} -- label<Датчики влажности ID>label info<Если датчиков несколько - для полива будет выбираться датчик с наименьшей влажностью если датчик включается режим полива по времени>info
set_Water_level = 23 -- label<Уровень влажности полива>label info<Значение датчика влажности при котором (или ниже) произойдет полив>info
sets_Canal_out = "" -- label<Канал слива>label info<канал управления слива>info
set_Time_drain = 60 -- label<Время слива>label info<время слива в секундах>info
setm_Sens_out_id = {15} -- label<ID Датчики слива>label info<При срабатывании любого датчика произойдет слив>info
--separation
set_Temp_set = 20 -- label<Начальная температура коректировки>label info<Значение температуры от которой происходит корректировка влажности полива>info
set_Temp_corection = 1 -- label<Температурный Коэффициент>label info<Значение корректирующее заданную влажность в зависимости от температуры среды (при изменении температуры на 1 градус заданная влажность для полива меняется на set_Temp_corection)>info
set_Temp_stop_watering = 16 -- label<Температура прекращения полива>label info<При понижении температуры до указанного значения полив прекращается>info
--separation
setm_Sens_drainage_id = {} -- label<Датчики дренажа ID>label info<Если датчиков несколько будет выбираться максимальное значение>info
set_max_ppm = 1800 -- label<Максимальное EC дренажа>label info<Значение солёности дренажа при котором и выше которого будет применяться разбавление удобрений, согласно кратности>info
set_dilution_ppm = 1.5 -- label<Кратность разбавления>label info<Во сколько измениться концентрация удобрений при достижении максимального значения солёности дренажа>info
--separation
set_Alarm_level_low = 6 -- label<Нижний уровень влажности>label info<при котором будет выслано сообщение с предупреждением>info
set_Alarm_level_high = 85 -- label<Верхний уровень влажности>label info<при котором будет выслано сообщение с предупреждением>info
--separation
set_start_time_watering = 0 -- label<Час начала полива>label info<(от 0 до 23) включительно>info
set_stop_time_watering = 23 -- label<Час конца полива>label info<(от 0 до 23) включительно>info
--separation
setm_Sens_alarm_id = {} -- label<ID Датчики - протечки>label info<При срабатывании любого датчика полив прекращается и высылается сообщение, если нет обновления данных ни одного датчика протечки - перезагрузка>info
--separation
set_time_alarm = 70 -- label<Время обновления дачиков>label info<в минутах после которого данные датчика не используется и высылается сообщение с предупреждением>info
set_Shift_time_restart = 50 -- label<Экстренная перезагрузка>label info<(0 - 59) сдвиг в минутах для перезапуска системы в случае превышения у датчика влажности времени обновления>info
--separation
sets_m_valve = "ch3-7" -- label<Главный клапан>label info<Канал подключённый к главному клапану или насосу (обычно общий для всех)>info
--separation
sets_email = "vertufir@gmail.com" -- label<Адрес электронной почты>label info<для отсылки сообщений>info
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>x<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<--
-->>>>>>>>>>>>>>>>>>>>>>>>>>>> Программная часть <<<<<<<<<<<<<<<<<<<<<<<<<<<<<--
------------------------------ Ver. 14.11.24 Программа полива

-- Отключение скрипта
if (uservariables['Stop_flag'] == '-1' ) 
    then
    print (Name_unit .. '-> ПОЛИВ ВЫКЛЮЧЕН !!! ...........')
    return 
end
if (sets_Canal_out ~= "" ) then
    setm_Sens_alarm_id = setm_Sens_out_id
end

if (sets_Day_option == 'ON') then set_Day_option = 1 end 
if (sets_Day_option == 'OFF') then set_Day_option = 0 end



m = os.date('%M')
sec = os.date('%S')
hr = os.date('%H')
day = os.date('%d')
month = os.date('%m')
year = os.date('%Y')
vr = hr .. ':' .. m ..':' .. sec

set_time_alarm = set_time_alarm*60
hr_offset = math.floor(set_Shift_time_watering/60) 

local function timedifference (s)
   year = string.sub(s, 1, 4)
   month = string.sub(s, 6, 7)
   day = string.sub(s, 9, 10)
   hour = string.sub(s, 12, 13)
   minutes = string.sub(s, 15, 16)
   seconds = string.sub(s, 18, 19)
   t1 = os.time()
   t2 = os.time{year=year, month=month, day=day, hour=hour, min=minutes, sec=seconds}
   difference = os.difftime (t1, t2)
   return difference
end

local function updatenum(dev, value1)
    local cmd = string.format("%d|0|%d", otherdevices_idx[dev], value1)
    table.insert (commandArray, { ['UpdateDevice'] = cmd } )
end

local function updatestr(dev, value1)
    local cmd = string.format("%d|0|%s", otherdevices_idx[dev], value1)
    table.insert (commandArray, { ['UpdateDevice'] = cmd } )
end

---- Функция получение имени по id
function getdevname4idx(deviceIDX)
	for i, v in pairs(otherdevices_idx) do
		if v == deviceIDX then
			return i
		end
	end
	return 0
end

-- Если Stop_flag не создан
if (uservariables['Stop_flag'] == nil ) then
    print ( Name_unit .. " -- Stop_flag не создан!")
    return commandArray
end 

--  Если запущен этот скрипт - инфо и прерывание
if ( uservariables['Stop_flag'] == Name_unit ) then
    print ( Name_unit .. " -> Происходит полив!") 
    return commandArray
end



--- Создание переменной для удобрений если ранее не создовалась
if ( uservariables[Name_unit] == nil ) then 
    print ( Name_unit .. " -> Создание переменной для удобрений ...") 
    st = 'curl "127.0.0.1:8080/json.htm?type=command&param=adduservariable&vname=' .. Name_unit .. '&vtype=0&vvalue=' .. 1 .. '"'
    os.execute (st)
    return commandArray
end



if ( uservariables[Name_unit] ~= nil ) then 
    
-- Добавление еденицы к счетчику удобрений при включенной опции: set_Day_option = 1 в конце каждого дня.
    if (set_Day_option == 1 and tonumber(m) == 59 and tonumber(hr) == 23 ) then 
       local temp = tonumber( uservariables[Name_unit] ) + 1
       commandArray[ 'Variable:' .. Name_unit ] = tostring (temp)
       print ("Добавление еденицы к счетчику удобрений ... ")
    end 

-- Сброс переменной до "1" если она превышает матрицу удобрений
    local temp = tonumber( uservariables[Name_unit] )
    local i = 1 ; h = 0
    for s in string.gmatch(uservariables['pumps_calibraton'], "[^,]+")  do
        local tp = "setm_Pump_" .. tostring(i)
        if (temp  <= #_G[tp] ) then h = 1 end
        i = i + 1
    end
    if (h == 0) then 
        commandArray[ 'Variable:' .. Name_unit ] = tostring(1) 
        print ("Сброс до еденицы счетчика удобрений ... ")
        return commandArray
    end


end    

---- Увеличение квотой времени полива и концентрации удобрений
set_Time_fertilize = set_Time_fertilize * set_Quota
set_Time_clear_water = set_Time_clear_water * set_Quota

Concentration_Q = setm_Concentration[ uservariables[ Name_unit ]] * set_Quota -- Добавка квоты для увеличения концентрации
-- Если коэфициент разбавления не указан - равен нулю - нет впрыска удобрений
if (Concentration_Q == nil) then Concentration_Q = 0 end

--print ("Concentration_Q:" .. Concentration_Q)


-----------------------------------------------------------------------------
----- Проверка датчиков дренажа по времени последнего обновления данных, определение наибольшего значения из группы

n = 0
w = -1
s_temp = 0
if (sets_Canal_out == "") then -- Если не включен режим слива
    for p=1, #setm_Sens_drainage_id do
        
	   if(otherdevices_lastupdate[ getdevname4idx(setm_Sens_drainage_id[p]) ] ~= null) then 
			tm_sensor = timedifference(otherdevices_lastupdate[ getdevname4idx(setm_Sens_drainage_id[p]) ] )

			if (tm_sensor < set_time_alarm) then
			   if (tonumber (otherdevices[ getdevname4idx(setm_Sens_drainage_id[p]) ]) > w ) 
			   then w = tonumber (otherdevices[ getdevname4idx(setm_Sens_drainage_id[p]) ]) ; s_temp = p
			   end
			   n = n + 1
			else 
			   local str = 'sudo echo "' .. vr ..' -> время опроса датчика дренажа-> ' .. getdevname4idx(setm_Sens_drainage_id[p]) ..  ': превысило ' .. math.floor(tm_sensor/60) ..' мин. !! "' ..'| mail -s "' .. vr .." " ..Name_unit .. '-> время опроса датчика дренажа-> ' .. getdevname4idx(setm_Sens_drainage_id[p]) ..  ' превысило ' .. math.floor(tm_sensor/60) ..' мин. !! " ' .. sets_email
			   if (sets_email ~= "" and tonumber(m) == set_Shift_time_watering - hr_offset*60 ) 
				  then 
				  os.execute (str)
				  print (str) 
				end    
				print (Name_unit .. '-> время опроса датчика дренажа-> ' .. getdevname4idx(setm_Sens_drainage_id[p]) ..  ': превысило ' .. math.floor(tm_sensor/60) ..' мин. !!!')    
			end
        else -- Если ID не существует
		    print (Name_unit .."-> ID: ".. setm_Sens_drainage_id[p] .. " - Не верный ID датчика Дренажа !!!")
		end
		
    end 


    if ( #setm_Sens_drainage_id > 1 ) then
    if (n == 0 or w == -1 )
        then 
        print (Name_unit .. "-> все датчики дренажа не обновляются !!!")
        local str = 'sudo echo "' .. vr ..' ' ..Name_unit .. '-> все датчики дренажа не обновляются !!" | mail -s "' .. vr ..' ' ..Name_unit .. '-> все датчики дренажа не обновляются !! " ' .. sets_email
        if (sets_email ~= "" and tonumber(m) == set_Shift_time_watering - hr_offset*60) then os.execute (str) print (str) end    
        return commandArray
    end
    end
end

Max_drainage = w
Max_drainage_id = s_temp


-----------------------------------------------------------------------------
-- Изменение концентрации если датчик дренажа показывает больше установленного
plus_info = ''
if (Max_drainage >= set_max_ppm) then 
plus_info = " -> Превышение EC дренажа: ".. Max_drainage .. " uS Включено разбавление в " .. set_dilution_ppm .. " раз(а)"
Concentration_Q = Concentration_Q/set_dilution_ppm
end

if (Max_drainage ~= -1 and Max_drainage < set_max_ppm ) then 
plus_info = " -> EC дренажа: ".. Max_drainage.. " uS"

end


----- Проверка датчиков влажности по времени последнего обновления данных, определение наименьшего значения из группы


n = 0
w = 101
s_temp = 0
if (sets_Canal_out == "") then -- Если не включен режим слива
    for p=1, #setm_Sens_id do
        -- Если ID существует
		if (otherdevices_lastupdate[ getdevname4idx(setm_Sens_id[p]) ] ~= null) then
			tm_sensor = timedifference(otherdevices_lastupdate[ getdevname4idx(setm_Sens_id[p]) ] )   
			if (tm_sensor < set_time_alarm) then
			   if (tonumber (otherdevices[ getdevname4idx(setm_Sens_id[p]) ]) > 0 and tonumber (otherdevices[ getdevname4idx(setm_Sens_id[p]) ]) < w ) 
			   then w = tonumber (otherdevices[ getdevname4idx(setm_Sens_id[p]) ]) ; s_temp = p
			   end
			   n = n + 1
			else 
			   local str = 'sudo echo "' .. vr ..' -> время опроса датчика-> ' .. getdevname4idx(setm_Sens_id[p]) ..  ': превысило ' .. math.floor(tm_sensor/60) ..' мин. !! "' ..'| mail -s "' .. vr .." " ..Name_unit .. '-> время опроса датчика-> ' .. getdevname4idx(setm_Sens_id[p]) ..  ' превысило ' .. math.floor(tm_sensor/60) ..' мин. !! " ' .. sets_email
			   if (sets_email ~= "" and tonumber(m) == set_Shift_time_watering - hr_offset*60 ) 
				  then 
				  os.execute (str)
				  print (str) 
				end    
				print (Name_unit .. '-> время опроса датчика-> ' .. getdevname4idx(setm_Sens_id[p]) ..  ': превысило ' .. math.floor(tm_sensor/60) ..' мин. !!!')    
			end
        else -- Если ID не существует
			print (Name_unit .."-> ID: ".. setm_Sens_id[p] .. " - Не верный ID датчика Влажности !!!")
		end
		
    end 

    if ( #setm_Sens_id > 1 ) then
    if (n == 0 or w == 101 )
    then 
        print (Name_unit .. "-> все датчики не обновляются !!!")
        local str = 'sudo echo "' .. vr ..' ' ..Name_unit .. '-> все датчики не обновляются !!" | mail -s "' .. vr ..' ' ..Name_unit .. '-> все датчики не обновляются !! " ' .. sets_email
        if (sets_email ~= "" and tonumber(m) == set_Shift_time_watering - hr_offset*60) then os.execute (str) print (str) end    
        return commandArray
    end
    end
end 
-- перезагрузка системы при привышении времени обновления датчиков больше time_alarm
if (#setm_Sens_id > 0 and s_temp == 0 and tonumber(m) == set_Shift_time_restart - hr_offset*60 and sets_Canal_out == "") 
then 
    local str = 'sudo echo "' .. vr ..' ' ..Name_unit .. '-> Перезагрузка !!" | mail -s "' .. vr ..' ' ..Name_unit .. '-> все датчики не обновляются !! " ' .. sets_email
    if (sets_email ~= "" ) then os.execute (str) end 
    os.execute ("sudo reboot")  
end

local Temperature = set_Temp_set
if (s_temp ~= 0) then  Temperature = tonumber (otherdevices[ getdevname4idx(setm_Sens_id[s_temp] +1) ]) end

Water_sensor = w
set_Water_level = set_Water_level  + ( tonumber(Temperature)  - set_Temp_set ) * set_Temp_corection 

st = 'с учетом текущей температуры '
if (set_Temp_corection == 0 or set_Temp_corection < 0 ) then st = ' Температура: ' end 

if (n == 1 ) then print (Name_unit .." -> Влажность:  " .. Water_sensor .. " % ... (Требуемая влажность " .. set_Water_level .." % " .. st .. Temperature .. " °C)" .. plus_info) end
if (n > 1 ) then print (Name_unit .." -> Наименьшая в группе влажность:  " .. Water_sensor .. " % ... (Требуемая влажность " .. set_Water_level .." % " .. st .. Temperature .. " °C)" .. plus_info) end
--if (#setm_Sens_id == 0 ) then print (Name_unit .." -> Включен режим полива без дачика влажности") end

-----------------------------------------------------------------------------
-- Если температура ниже set_Temp_stop_watering
if (set_Temp_stop_watering >= Temperature) 
    then
        print (Name_unit .. '-> Полив остановлен - понижение температуры ниже заданного значения!')
        return commandArray
    end
 
       
-----------------------------------------------------------------------------
----- Проверка датчиков протечки/слива по времени последнего обновления данных, определение наибольшего значения из группы

n = 0
w = -1
s_temp = 0
for p=1, #setm_Sens_alarm_id do
 	-- Если ID существует
	if (otherdevices_lastupdate[ getdevname4idx(setm_Sens_alarm_id[p]) ] ~= null) then  
 
			tm_sensor = timedifference(otherdevices_lastupdate[ getdevname4idx(setm_Sens_alarm_id[p]) ] )
			if (tm_sensor < set_time_alarm) then
			   if (tonumber (otherdevices[ getdevname4idx(setm_Sens_alarm_id[p]) ]) > w ) 
			   then w = tonumber (otherdevices[ getdevname4idx(setm_Sens_alarm_id[p]) ]) ; s_temp = p
			   end
			   n = n + 1
			else 
			   local str = 'sudo echo "' .. vr ..' -> время опроса датчика протечки(или слива)-> ' .. getdevname4idx(setm_Sens_alarm_id[p]) ..  ': превысило ' .. math.floor(tm_sensor/60) ..' мин. !! "' ..'| mail -s "' .. vr .." " ..Name_unit .. '-> время опроса датчика протечки(или слива)-> ' .. getdevname4idx(setm_Sens_alarm_id[p]) ..  ' превысило ' .. math.floor(tm_sensor/60) ..' мин. !! " ' .. sets_email
			   if (sets_email ~= "" and tonumber(m) == set_Shift_time_watering - hr_offset*60 ) 
				  then 
				  os.execute (str)
				  print (str) 
				end    
				print (Name_unit .. '-> время опроса датчика протечки(или слива)-> ' .. getdevname4idx(setm_Sens_alarm_id[p]) ..  ': превысило ' .. math.floor(tm_sensor/60) ..' мин. !!!')    
			end
     else   -- Если ID не существует
			print (Name_unit .."-> ID: ".. setm_Sens_alarm_id[p] .. " - Не верный ID датчика Протечки(или Слива) !!!")
	 end

end 

if ( #setm_Sens_alarm_id > 1 ) then
if (n == 0 or w == -1 )
    then 
    print (Name_unit .. "-> все датчики протечки(или слива) не обновляются !!!")
    local str = 'sudo echo "' .. vr ..' ' ..Name_unit .. '-> все датчики протечки(или слива) не обновляются !!" | mail -s "' .. vr ..' ' ..Name_unit .. '-> все датчики протечки (или слива) не обновляются !! " ' .. sets_email
    if (sets_email ~= "" and tonumber(m) == set_Shift_time_watering - hr_offset*60) then os.execute (str) print (str) end    
    return commandArray
end
end

Water_overflow = w
Water_overflow_id = s_temp


-- перезагрузка системы при привышении времени обновления датчиков больше time_alarm
if (#setm_Sens_alarm_id > 0 and s_temp == 0 and tonumber(m) == set_Shift_time_restart - hr_offset*60) 
then 
    local str = 'sudo echo "' .. vr ..' ' ..Name_unit .. '-> Перезагрузка !! " | mail -s "' .. vr ..' ' ..Name_unit .. '-> все датчики протечки (или слива) не обновляются !! " ' .. sets_email
    if (sets_email ~= "" ) then os.execute (str) end 
    print (str)
    os.execute ("sudo reboot")  
end





-----------------------------------------------------------------------------
-- Запуск сливаа по кнопке Выборочный полив
Tiger_St = 0;
if (devicechanged ~= nil) 
then
    if (devicechanged['Выборочный полив'] == 'On' and #setm_Sens_alarm_id ~= NULL and sets_Canal_out ~= "") 
    then Tiger_St = 1 end 
end

-- слив бачка в севисном режиме на следуший час в момент попытки полива
if (tonumber(m) == set_Shift_time_watering - hr_offset*60 or Tiger_St == 1) 
then
    
    -- Датчик Пеерелива как датчик солености в сервисном бачке
    if (#setm_Sens_alarm_id ~= NULL and sets_Canal_out ~= "" and Water_overflow > 5 or Tiger_St == 1) then
       
        -- Открыть сливной клапан
        local str = "bash /home/pi/bin/" .. sets_Canal_out .. " 1"
        os.execute (str)
        print (Name_unit .. " ->  ПРОИСХОДИТ СЛИВ ... >>>")
        
		for i = 1, set_Time_drain  do
			if (tonumber(os.date('%S')) == 0 ) then print (Name_unit .. " ->  ПРОИСХОДИТ СЛИВ ... >>>") end
			
			str = "sleep 0.9" 
        	os.execute (str)
					
			-- Экстренное отключение слива 
				-- Определяем Stop_flag и заканчиваем скрипт если =-1
				local url = 'curl "127.0.0.1:8080/json.htm?type=command&param=getuservariables" | grep -C 3 "Stop_flag" | grep "Value"  ' .. " | egrep -o '([-]*[0-9]+)' " 
				local file = assert(io.popen(url, 'r'))
				local out = file:read('*all')
				file:close()
				-- Отключение скрипта если Stop_flag=-1
				if (tonumber(out) == -1) 
				then
				   print (Name_unit .. " --- >>> Слив прерван !!! <<< ---")
				   -- Закрыть сливной клапан
				   local str = "bash /home/pi/bin/" .. sets_Canal_out .. " 0"
				   os.execute (str)

				   -- Ввостанавливаем Stop_flag
				   commandArray[ 'Variable:Stop_flag' ] = '0'

				   return commandArray
				end
			  ------------
			
		end
		

        -- Закрыть сливной клапан
		local str = "bash /home/pi/bin/" .. sets_Canal_out .. " 0"
        os.execute (str)
        print (Name_unit .. " ->  ЗАКОНЧИЛСЯ СЛИВ ... >>>")    
        return commandArray
        
    end  
end

if (#setm_Sens_alarm_id ~= NULL and sets_Canal_out ~= "") then
print (Name_unit .." -> Режим Слива ") 
return commandArray
end

------ Определение времени полива --------------------------------------------------------

addday = 1 

if (set_Period >= 24 ) -- определение сколько дней между поливами и какой час полива = set_Period
    then
    addday = math.floor(set_Period/24)
    set_Period = set_Period - 24*addday
    addday = addday + 1
end
-- определение минуты полива
chas_poliva = math.floor(set_Period + set_Shift_time_watering/60)
min_poliva = math.floor(  ((set_Period*60 + set_Shift_time_watering) - chas_poliva * 60)   )


-- Если включен режим без датчика -----
Tiger_Start = 0
if (#setm_Sens_id == 0 ) 
    then
	
	addday = set_Delay -- Если по расписанию то дополнительную задержку брать с set_Delay
	
    
	local text = ""

    for i = #setm_Hour_watering , 1 , -1  do 
    text =  tostring (setm_Hour_watering[i]) .. ", " .. text
        if (#setm_Hour_watering ~= nil) then
          if (day % addday == 0 and  tonumber(hr) == tonumber(setm_Hour_watering[i] + hr_offset) and tonumber(m) == min_poliva)
          then 
          Tiger_Start = 1
          
          end
        end
    end
    
    print (Name_unit .." -> Режим полива по расписанию -> Полив каждый " .. addday .. " днень" 
           .. " Часы полива: " .. text .. " + Сдвиг " .. math.floor(set_Shift_time_watering/60) .. ":" .. min_poliva .. ") ".. plus_info)

else -- Если включен режим с датчиком влажности
    if (day % addday == 0 and  (hr - hr_offset) % set_Period == 0 and tonumber(m) == set_Shift_time_watering - hr_offset*60 and tonumber(hr) >= set_start_time_watering and tonumber(hr) <= set_stop_time_watering ) 
        then
        Tiger_Start = 1
        end

end

-- Запуск полива по кнопке при переключении Triger=Device
if (devicechanged ~= nil) 
then
    if (devicechanged['Выборочный полив'] == 'On') 
    then Tiger_Start = 2 end 
end



-- Запуск процедуры полива
if (Tiger_Start == 1 or Tiger_Start == 2)
then

   
    
    -- Сработал один из датчиков протечки
    if (#setm_Sens_alarm_id ~= NULL) then
        if (Water_overflow > 5  ) then
        -- Перелив- отправить сообщение    
            local str = 'sudo echo ' .. '"' .. vr .. ' ' .. getdevname4idx(setm_Sens_alarm_id[s_temp]) .. Water_overflow ..'"%' .. ' | mail -s ' .. '"' .. 'Сработал датчик протечки ' .. Name_unit .. ' !! ' .. '"'.. ' ' .. sets_email
            if (sets_email ~= "") then os.execute (str) end
            print("! ! ! ========== Прелеив в " .. Name_unit .. "-> " .. getdevname4idx(setm_Sens_alarm_id[s_temp]) ..": ".. Water_overflow .. "%")
            return commandArray
        end
       
    end 



    if ( Tiger_Start == 2 or #setm_Sens_id == 0 or Water_sensor < set_Water_level  and Water_sensor > 0 ) -- Полив если  мало влаги и датчик не сухой либо включен режим без дачика влажности
    then                                                                                                -- Нажата кнопка Выборочный полив
       
        -- Флаг полива включЁн - для предотвращения запуска другого скрипта
        if ( uservariables['Stop_flag'] ==  '0' ) then
            st = 'curl "127.0.0.1:8080/json.htm?type=command&param=updateuservariable&vname=Stop_flag&vtype=2&vvalue=' .. Name_unit .. '"'
            os.execute (st)
        end
       
        --  Если запущен скрит во время работы другог 
        if ( uservariables['Stop_flag'] ~= Name_unit and uservariables['Stop_flag'] ~= '0' ) then
            st = Name_unit .. '-> Полив невозможен!!! Происходит полив другого растения - ' .. uservariables['Stop_flag'] .. '!!! - Ошибка в планировании полива !!!'
            print (st)
            --updatestr (	'Журнал событий' , st)
            
            --local str = 'sudo echo "' .. vr ..' ' .. st ..'" | mail -s "' .. vr ..' ' .. st .. '" ' .. sets_email
            local str = 'sudo echo "' .. vr ..' ' .. st .. '" | mail -s "' .. vr ..' ' .. Name_unit .. '- Полив невозможен !!' .. '" ' .. sets_email

            if (sets_email ~= "" ) then os.execute (str) end 
            
            return commandArray
        end
        
        

       
       
        -- Открыть поливочный клапан
        local str = "bash /home/pi/bin/" .. sets_Canal .. " 1"
        os.execute (str)
        print (Name_unit .. " -> НАЧАЛСЯ ПОЛИВ")
     
        -- Открыть главный клапан
        local str = "bash /home/pi/bin/" .. sets_m_valve .. " 1"
        os.execute (str)
   
        
        -- Впрыск удобрений --
        
        local flag = "" -- flag - переменная сод. пропись используемых удобрений
        
        -- Если концентрация = 0 то вместо впрыска задержка = set_Time_fertilize 
        if ( Concentration_Q == 0 ) 
        then 
        local str = 'sleep ' .. tonumber(set_Time_fertilize)
        os.execute (str)
        end
        
        -- Начало впрыска
        if ( set_Time_fertilize > 0 and Concentration_Q > 0 ) 
        then
            print (' >>>> Началась дозация удобрений для ' .. Name_unit .. " ...")
            
            --- Замена отсутсвующих значений удобрений нулями и 
            --- создание flag - переменная сод. пропись используемых удобрений
            flag = "с удобрениями {"
            local i = 1
            for s in string.gmatch(uservariables['pumps_calibraton'], "[^,]+")  do
            local tp = "setm_Pump_" .. tostring(i)
            if (_G[tp][ uservariables[ Name_unit ]] == nil ) then _G[tp][ uservariables[ Name_unit ]] = 0 
            else
                if (_G[tp][ uservariables[ Name_unit ]] ~= 0 ) then
                flag = flag .. '  #' .. i .. ":(" .. _G[tp][ uservariables[ Name_unit ]] .. ")" 
                end
            end
            i = i + 1
            end
            flag = flag .. "  } концентрация: " .. Concentration_Q .. "  с учётом PPM дренажа: ".. Max_drainage .. " uS" 
            
            if (Max_drainage >= set_max_ppm ) then flag = flag .. " - повышенный PPM дренажа - разбавление в ".. set_dilution_ppm end 

            -----
            
            -- Получение поправок насосов из переменной пользователя
            setm_Pump_v = {}
            local i = 1
            for s in string.gmatch(uservariables['pumps_calibraton'], "[^,]+")  do
            setm_Pump_v [i] = tonumber (s)
            i = i + 1
            end
            ----------------
            
            -- Поиск наибольшего колличества удобрения в текущем рецепте
            local i = 1
            local max = 0
            for s in string.gmatch(uservariables['pumps_calibraton'], "[^,]+")  do
            local tp = "setm_Pump_" .. tostring(i)
            sh =  _G[tp][ uservariables[ Name_unit ]]
            if (sh > max) then max = sh end
            i = i + 1
            end
			
			-- Получение set_division - значения на сколько раз делиться ml удобрений при впрыске
			-------
			local file_path = "/home/pi/domoticz/scripts/lua/script_device_pumps_calibration.lua"
			local file = io.open(file_path, "r")
			if not file then
				print("Не удалось открыть файл: " .. file_path)
				return
			end
			local set_division_value -- Переменная для хранения значения set_division
			-- Читаем файл построчно
			for line in file:lines() do
				-- Проверяем, содержит ли строка нужную переменную
				local set_division_str = line:match("set_division%s*=%s*(%d+)")
				if set_division_str then
					set_division_value = tonumber(set_division_str)
					break
				end
			end
			
			file:close()
    		local set_division = set_division_value
			


        
            
            ------------ Цыкл впрыска удобрений    commandArray[ 'Variable:' .. Name_unit ] 
            
                        
            local store_pumps  = {0,0,0,0,0,0,0,0,0,0,0,0}  -- счетчик удобрений, сколько было впрыснуто
       
            for p=0, max*set_division*Concentration_Q do 
                
                    -- Экстренное отключение полива
                        -- Определяем Stop_flag и заканчиваем скрипт если =-1
                        local url = 'curl "127.0.0.1:8080/json.htm?type=command&param=getuservariables" | grep -C 3 "Stop_flag" | grep "Value"  ' .. " | egrep -o '([-]*[0-9]+)' " 
                        local file = assert(io.popen(url, 'r'))
                        local out = file:read('*all')
                        file:close()
                        -- Отключение скрипта если Stop_flag=-1
                        if (tonumber(out) == -1) 
                        then
                           print (Name_unit .. " --- >>> Полив прерван !!! <<< ---")
                            -- Закрыть главный клапан
                           local str = "bash /home/pi/bin/" .. sets_m_valve .. " 0"
                           os.execute (str)
                            -- Закрыть поливочный клапан     
                           local str = "bash /home/pi/bin/" .. sets_Canal .. " 0"
                           os.execute (str)
                           -- Ввостанавливаем Stop_flag
                           commandArray[ 'Variable:Stop_flag' ] = '0'
                           
                           return commandArray
                        end
                    ------------
                
                local delay = 0 -- общее время впрыска в одном цикле
                local i = 1
                for s in string.gmatch(uservariables['pumps_calibraton'], "[^,]+")  do
                    
                    local tp = "setm_Pump_" .. tostring(i) 
                    if ( _G[tp][ uservariables[ Name_unit ]] > 0 and _G[tp][ uservariables[ Name_unit ]] ~= NULL ) 
                    then
                        if ( tonumber(store_pumps[i]) < tonumber (_G[tp][ uservariables[ Name_unit ] ])*Concentration_Q ) 
                        then 
                            local st = "bash /home/pi/bin/pump" .. i .. " 1 ; sleep ".. setm_Pump_v[i]/set_division .. "; bash /home/pi/bin/pump" .. i .. " 0 " 
                                
                                delay = delay + setm_Pump_v[i]/set_division -- общее время потраченное на впрыск в одном цикле
                                local step = max/tonumber (_G[tp][ uservariables[ Name_unit ] ])
                                if ( p/(step*set_division) >= store_pumps[i] ) 
                                then    
                                os.execute (st)
                                store_pumps[i] = store_pumps[i] + 1/set_division
                                end
                        
                        end
 
                    end     
                    
                    i = i + 1
            
                end

            st = "sleep " .. tostring (  set_Time_fertilize/(max*set_division*Concentration_Q) - delay - delay*0.1 )  -- delay*0.1 - уточняющая время добавка   
            os.execute (st)
            
            end
            ------------ Конец впрыска удобрений
            
            local i = 1
            for s in string.gmatch(uservariables['pumps_calibraton'], "[^,]+")  do
            print ("Произведен впрыск удобрений -> насос-".. i .. ": ".. store_pumps[i] .. " ml")
            i = i + 1
            end
        
        else
            set_Time_fertilize = 0
        end
        

    
     -- Ждать время полива чистой водой
    
	for p=1 , set_Time_clear_water do
		-- Экстренное отключение полива
			-- Определяем Stop_flag и заканчиваем скрипт если =-1
			local url = 'curl "127.0.0.1:8080/json.htm?type=command&param=getuservariables" | grep -C 3 "Stop_flag" | grep "Value"  ' .. " | egrep -o '([-]*[0-9]+)' " 
			local file = assert(io.popen(url, 'r'))
			local out = file:read('*all')
			file:close()
			-- Отключение скрипта если Stop_flag=-1
			if (tonumber(out) == -1) 
			then
			   print (Name_unit .. " --- >>> Полив прерван !!! <<< ---")
				-- Закрыть главный клапан
			   local str = "bash /home/pi/bin/" .. sets_m_valve .. " 0"
			   os.execute (str)
				-- Закрыть поливочный клапан     
			   local str = "bash /home/pi/bin/" .. sets_Canal .. " 0"
			   os.execute (str)
			   -- Ввостанавливаем Stop_flag
			   commandArray[ 'Variable:Stop_flag' ] = '0'

			   return commandArray
			end
		------------
		local str = 'sleep 0.9'
    	os.execute (str)
	end

  
     -- Закрыть главный клапан
    local str = "bash /home/pi/bin/" .. sets_m_valve .. " 0"
    os.execute (str)

     -- Закрыть поливочный клапан     
    local str = "bash /home/pi/bin/" .. sets_Canal .. " 0"
    os.execute (str)
    print (Name_unit .. " -> ЗАКОНЧИЛСЯ ПОЛИВ ")
    
    -- Флаг полива вЫключЁн
        temp = '0'
        st = 'curl "127.0.0.1:8080/json.htm?type=command&param=updateuservariable&vname=Stop_flag&vtype=2&vvalue=' .. temp .. '"'
        os.execute (st)

     -- Счетчик удобрений - добовляет еденицу к переменной Domoticz после полива с удобрениями
     -- Если привышение матрицы удобрений - сброс на 1
    if (set_Day_option == 0 and set_Time_fertilize > 0) then 
        local temp = tonumber( uservariables[Name_unit] ) + 1
        local i = 1
        local h = 0
        for s in string.gmatch(uservariables['pumps_calibraton'], "[^,]+")  do
        local tp = "setm_Pump_" .. tostring(i)
        if (temp  <= #_G[tp] ) then h = 1 end
        i = i + 1
        end
        if (h == 0) then commandArray[ 'Variable:' .. Name_unit ] = tostring(1)
        else commandArray[ 'Variable:' .. Name_unit ] = tostring (temp)
        end
    end
    
    -- Отослать сообщение о поливе

    local str = 'sudo echo ' .. '"'  .. Name_unit .. '- сработал полив ' .. flag   .. '" | mail -s "' .. hr .. ":" .. m .. " " .. Name_unit .. '-> Влажность: '.. Water_sensor .. '% (' .. Temperature ..'°C) - сработал полив" ' .. sets_email
    if (sets_email ~= "") then os.execute (str) end
    print ('e-mail оповещение:  ' .. str )
     
    -- Передать в Info время полива 
    local st = ""
    if ( #setm_Sens_id ~=0 ) then st = day .. '.'.. month ..'.'.. year.. '   ' ..hr..":"..m.." "..Name_unit.." ( ".. Water_sensor .."% ) полив " .. flag 
        else
        st = day .. '.'.. month ..'.'.. year.. '   ' ..hr ..":"..m.." "..Name_unit.." Полив по расписанию. " .. flag
        end

    --updatestr (	'Журнал событий' , st)

    os.execute ('echo "'..tostring(st)..'" >> /var/www/html/log/log_watering')
    os.execute ('sudo chmod 666 /var/www/html/log/log_watering')
     
    end
--------------------------    
 
    -- Если влажность > установленного
    if (Water_sensor > set_Alarm_level_high and Water_sensor ~= 101)  
    then 
        local str = 'sudo echo ' .. '"' .. vr .. ' Влажность: '..Water_sensor ..'"%' .. ' | mail -s ' .. '"' .. Name_unit .. ' Повышенная влажность !!' .. '"'.. ' ' .. sets_email
        if (sets_email ~= "") then os.execute (str) end
        print ('e-mail оповещение:  ' .. str)
    end    
    
    -- Если влажность < устаовленного
    if (Water_sensor < set_Alarm_level_low )  
    then 
        local str = 'sudo echo ' .. '"' .. vr .. ' Влажность: '..Water_sensor ..'"%' .. ' | mail -s ' .. '"' .. Name_unit .. ' Пониженная влажность !!' .. '"'.. ' ' .. sets_email
        if (sets_email ~= "") then os.execute (str) end
        print ('e-mail оповещение:  ' .. str)
    end  



end

return commandArray


-- Конец програмной части
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------