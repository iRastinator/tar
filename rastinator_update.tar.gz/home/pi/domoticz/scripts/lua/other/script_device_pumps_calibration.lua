commandArray = {}
set_pump = {}
------------------------------ Установки -------------------------------------
set_required_volume = 10
set_division = 10
set_pump[1] = 10
set_pump[2] = 10
set_pump[3] = 10
set_pump[4] = 10
set_pump[5] = 10
set_pump[6] = 10
set_pump[7] = 10
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>x<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<--
-->>>>>>>>>>>>>>>>>>>>>>>>>>>> Программная часть <<<<<<<<<<<<<<<<<<<<<<<<<<<<<--
------------------------------ Ver. 27.12.24

single_calibraton = 0
local time_colibration = set_required_volume * set_division  
local name = "pumps_calibraton"
local pump_v = {}

-- Отключение скрипта
if uservariables['Stop_flag'] == '-1' then
    --print ('Калибровка включена !!! ')
else
    --print ('Калибровка ВЫКЛЮЧЕНА! ')
    return
end
	
if (uservariables[name] == NULL ) then 
        -- Создание переменной пользователя pumps_calibraton если ранее не создавалась
        local start_dev = 0.5
        local st = 'curl "127.0.0.1:8080/json.htm?type=command&param=adduservariable&vname=' .. "pumps_calibraton" .. '&vtype=2&vvalue=' .. '0.5,0.5,0.5,0.5,0.5,0.5,0.5' .. '"'
        os.execute (st)
        print ("Создание переменной pumps_calibration")
        
        
    end
    
if (devicechanged['Калибровка дозировочных насосов'] == 'On') 
    then
        
        local i = 1
        for s in string.gmatch(uservariables[name], "[^,]+")  do
            pump_v [i] = tonumber (s)
            
            if (set_pump[i] ~= 0) then
            if (set_pump[i] ~= set_required_volume ) then t = pump_v [i] * set_required_volume / set_pump[i] ; pump_v [i] = t
            end
            end
            i = i + 1
            
        end
    
        for p=0 , time_colibration do 
            local i = 1
            for s in string.gmatch(uservariables[name], "[^,]+")  do

                 local tm = set_required_volume * pump_v [i]/time_colibration
                 local st = "bash /home/pi/bin/pump" .. i .. " 1 ; sleep ".. tm .. "; bash /home/pi/bin/pump" .. i .. " 0 " 
                
                
                 if (single_calibraton == 1 and set_pump[i] ~= set_required_volume and set_pump[i] ~= 0) then os.execute (st) end
                 
                 if (single_calibraton == 0 and set_pump[i] ~= 0 )  then os.execute (st) end
                 
                 i = i + 1
                 
            end
            os.execute ("sleep 1")
        end    
    
        local nm = 'Variable:' ..   name 
        local f = pump_v [1] ..', '.. pump_v [2] ..', '.. pump_v [3] ..', '.. pump_v [4] ..', '.. pump_v [5] ..', '.. pump_v [6] ..', '.. pump_v [7] 
        commandArray[ nm ] = f
        print (">->-> Результаты калибровки дозировочных насосов: " .. f)

end   






return commandArray
