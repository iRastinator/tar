commandArray = {}
------------------------------------------------------------------------------
------------------------------ Установки -------------------------------------
Name_unit = "Mijia-Температура-Влажность-test"
--info:поясняющая информация ...
--separation
set_rate_mijia = 1 -- label<Опросить датчики каждый>label info<в минутах>info
--separation
sens = {
"4c:65:A8:DF:13:FC , 14",  -- label<>label info<Температура и Влажность-id:14>info
}
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>x<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<--
-->>>>>>>>>>>>>>>>>>>>>>>>>>>> Программная часть <<<<<<<<<<<<<<<<<<<<<<<<<<<<<--
------------------------------ Ver. 09.11.23 -----------------------------------

--print("Mijia")

--Функция получение имени по id
function getdevname4idx(deviceIDX)
	for i, v in pairs(otherdevices_idx) do
		if v == deviceIDX then
			return i
		end
	end
	return 0
end
---------------------------------

m = os.date('%M')
hr = os.date('%H')
if ( m % set_rate_mijia == 0 ) then
    --print("Отпрос датчиков температура и влажность")
    for p=1, #sens do
        zap= string.find(sens[p],",")
        mac = string.sub(sens[p], 0, string.find(sens[p],",")-1)
        mac = mac:gsub("%s+", "")
        id = string.sub(sens[p], string.find(sens[p],",")+1,100)
        id = id:gsub("%s+", "")
        stt = '"'.. mac..'"'..' '..'"'..id..'"'

        local str = 'python3 /home/pi/domoticz/scripts/python/mijia/mijia_s.py "127.0.0.1:8080" ' .. stt 
        os.execute (str)
        print (" ... Опрос датчика влажности и температуры воздуза: " .. getdevname4idx(tonumber(id)) )
        os.execute ("sleep 5")
    end 
end
---------------------------------------------------------------

return commandArray
