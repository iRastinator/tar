import requests
import sys

def get_chat_id(token):
    """
    Получает chat_id последнего обновления для данного бота.
    """
    url = f"https://api.telegram.org/bot{token}/getUpdates"
    response = requests.get(url)

    if response.status_code == 200:
        updates = response.json().get('result', [])
        if updates:
            # Предполагаем, что берем первое обновление
            chat_id = updates[-1]['message']['chat']['id']
            return chat_id
        else:
            print("Нет обновлений. Убедитесь, что вы отправили сообщение вашему боту.")
    else:
        print(f"Ошибка при получении обновлений: {response.status_code}, {response.text}")
    return None

def send_message(token, chat_id, message):
    """
    Отправляет сообщение в Telegram.

    :param token: Токен доступа к Telegram Bot API
    :param chat_id: ID чата, куда будет отправлено сообщение
    :param message: Текст сообщения
    """
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    payload = {
        'chat_id': chat_id,
        'text': message,
        'parse_mode': 'Markdown'  # Для использования HTML установите 'HTML'
    }

    response = requests.post(url, data=payload)

    if response.status_code == 200:
        print("Сообщение отправлено успешно!")
    else:
        print(f"Ошибка при отправке сообщения: {response.status_code}, {response.text}")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Использование: python send_telegram_message.py <TOKEN> <MESSAGE>")
        sys.exit(1)

    bot_token = sys.argv[1]  # Токен бота
    message = sys.argv[2]     # Сообщение для отправки

    # Получаем chat_id
    chat_id = get_chat_id(bot_token)

    if chat_id is not None:
        send_message(bot_token, chat_id, message)
    else:
        print("Не удалось получить chat_id.")
