import sys
import subprocess
from bluepy.btle import Peripheral, BTLEDisconnectError
import logging

# Настройка логирования
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

def restart_bluetooth_service():
    """Перезагрузка службы Bluetooth."""
    logger.info("Перезагрузка службы Bluetooth.")
    try:
        subprocess.run(['sudo', 'systemctl', 'restart', 'bluetooth'], check=True)
        logger.info("Служба Bluetooth перезагружена.")
    except subprocess.CalledProcessError as e:
        logger.error(f"Ошибка при перезагрузке Bluetooth: {e}")

def get_device_name(mac_address):
    max_attempts = 4
    attempts = 0

    while attempts < max_attempts:
        try:
            # Подключаемся к устройству
            logger.info(f"Подключение к устройству с MAC-адресом: {mac_address}")
            device = Peripheral(mac_address)

            # Получаем и выводим название устройства
            name_char = device.getCharacteristics(uuid="00002a00-0000-1000-8000-00805f9b34fb")
            if name_char:
                name_value = name_char[0].read().decode('utf-8')
                logger.info(f"Имя устройства: {name_value}")
                device.disconnect()
                logger.info("Отключено от устройства.")
                return name_value  # Возвращаем имя устройства
            else:
                logger.warning("Не удалось найти характеристику для имени устройства.")
                device.disconnect()
                logger.info("Отключено от устройства.")
                return None  # Возвращаем None, если не удалось получить имя

        except BTLEDisconnectError as e:
            logger.error(f"Ошибка подключения: {e}")
            attempts += 1
            if attempts < max_attempts:
                restart_bluetooth_service()  # Перезагрузка Bluetooth при ошибке
            else:
                logger.error("Превышено максимально допустимое число попыток подключения.")
                return None  # Возвращаем None, если не удалось подключиться

        except Exception as e:
            logger.error(f"Произошла ошибка: {e}")
            attempts += 1
            if attempts < max_attempts:
                restart_bluetooth_service()  # Перезагрузка Bluetooth при ошибке
            else:
                logger.error("Превышено максимально допустимое число попыток подключения.")
                return None  # Возвращаем None на случай других ошибок


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Использование: python3 get_device_name.py <MAC-адрес>")
        sys.exit(1)

    mac_address = sys.argv[1]
    device_name = get_device_name(mac_address)  # Вызываем функцию и получаем имя устройства
    print(f"Имя устройства: {device_name}")  # Печатаем имя устройства
