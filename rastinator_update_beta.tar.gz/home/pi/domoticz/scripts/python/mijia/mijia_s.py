import sys
import subprocess
from get_device_name import get_device_name

def name_mac():
    # Получаем аргументы командной строки
    if len(sys.argv) != 4:
        print("Использование: python script.py <адрес_сервера> <MAC-адрес> <дополнительный_параметр>")
        sys.exit(1)

    domoticzserver = sys.argv[1]    # Сервер Domoticz
    mac_address = sys.argv[2]        # MAC адрес
    additional_param = sys.argv[3]   # Дополнительный параметр

    # Получаем имя устройства
    device_name = get_device_name(mac_address)  # Вызываем функцию
    print(f"Имя устройства: {device_name}, MAC-адрес: {mac_address}")

    # В зависимости от наличия имени запускаем соответствующий скрипт
    if "MJ_HT_V1" in device_name:
        script_to_run = "/home/pi/domoticz/scripts/python/mijia/mijia_MJ_HT_V1.py"
    elif "LYWSD03MMC" in device_name:
        script_to_run = "/home/pi/domoticz/scripts/python/mijia/mijia_LYWSD03MMC.py"
    else:
        print("Неизвестное устройство, запуск ничего не будет.")
        return

    # Запуск соответствующего скрипта с теми же аргументами
    try:
        subprocess.run(["/home/pi/domoticz/Domoticz_Python_Environment/bin/python3", script_to_run, domoticzserver, mac_address, additional_param])
    except Exception as e:
        print(f"Ошибка при запуске скрипта {script_to_run}: {e}")

if __name__ == "__main__":
    name_mac()
