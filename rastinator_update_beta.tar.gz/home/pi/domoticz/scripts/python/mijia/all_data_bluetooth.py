from bluepy.btle import Peripheral, BTLEDisconnectError, ADDR_TYPE_RANDOM, ADDR_TYPE_PUBLIC
import time

mac_address = "4c:65:A8:DF:05:5C"  # ваш MAC-адрес

def connect_with_retry(mac_address, max_retries=3):
    for retry in range(max_retries):
        try:
            print(f"Попытка подключения {retry + 1} из {max_retries}")
            # Пробуем оба типа адреса
            try:
                device = Peripheral(mac_address, ADDR_TYPE_RANDOM)
            except:
                device = Peripheral(mac_address, ADDR_TYPE_PUBLIC)
            print("Успешное подключение!")
            return device
        except BTLEDisconnectError as e:
            print(f"Ошибка подключения: {e}")
            if retry < max_retries - 1:
                print("Ожидание перед повторной попыткой...")
                time.sleep(3)
            else:
                print("Достигнуто максимальное количество попыток")
                raise
        except Exception as e:
            print(f"Неожиданная ошибка: {e}")
            raise

try:
    # Подключаемся к устройству
    device = connect_with_retry(mac_address)
    
    # Получаем список сервисов
    services = device.getServices()
    
    # Выводим информацию о сервисах
    for service in services:
        print(f"Service: {service.uuid}")
        
        # Получаем характеристики сервиса
        characteristics = service.getCharacteristics()
        for char in characteristics:
            print(f"  Characteristic: {char.uuid}")
            # Пробуем прочитать значение, если возможно
            if char.supportsRead():
                try:
                    value = char.read()
                    print(f"    Value: {value}")
                except:
                    print("    Невозможно прочитать значение")

except BTLEDisconnectError as e:
    print(f"Ошибка подключения к устройству: {e}")
except Exception as e:
    print(f"Произошла ошибка: {e}")
finally:
    try:
        device.disconnect()
    except:
        pass
