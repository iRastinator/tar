import time
import os
import sys
from miflora.miflora_poller import MiFloraPoller, MI_CONDUCTIVITY, MI_MOISTURE, MI_LIGHT, MI_TEMPERATURE, MI_BATTERY

def update(address):
    poller = MiFloraPoller(address)

    # Попробуем прочитать температуру
    loop = 1  
    try:
        temp = poller.parameter_value("temperature")
    except:
        temp = 201  # Код ошибки
    

    while loop < 1 and temp > 200:
        print("Ошибка чтения значения, повтор через 3 секунды...\n")
        os.system('sudo service bluetooth restart')
        time.sleep(3)
        poller = MiFloraPoller(address)
        loop += 1
        try:
            temp = poller.parameter_value("temperature")
        except:
            temp = 201

    if temp > 200:
        print("Ошибка чтения значения\n")
        return

    print("Mi Flora: " + address)
    print("Firmware: {}".format(poller.firmware_version()))
    print("Name: {}".format(poller.name()))
    print("Temperature: {}°C".format(poller.parameter_value("temperature")))
    print("Moisture: {}%".format(poller.parameter_value(MI_MOISTURE)))
    print("Light: {} lux".format(poller.parameter_value(MI_LIGHT)))
    print("Fertility: {} uS/cm?".format(poller.parameter_value(MI_CONDUCTIVITY)))
    print("Battery: {}%".format(poller.parameter_value(MI_BATTERY)))

# Проверяем наличие MAC-адреса при запуске скрипта
if len(sys.argv) != 2:
    print("Использование: python script.py <MAC_ADDRESS>")
    sys.exit(1)

# Получаем MAC-адрес из аргументов командной строки
mac_address = sys.argv[1]
update(mac_address)

