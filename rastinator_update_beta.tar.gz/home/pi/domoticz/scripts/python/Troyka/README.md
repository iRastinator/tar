# Troyka_Gpio_Expander_python

Зайдите в терминал Raspberry pi и введите:

sudo raspi-config

Interfacing Options → P5 I2C → Enabled → Finish

sudo apt-get update

y

sudo apt-get upgrade

y

sudo apt-get install python-dev python-pip

y

sudo pip install wiringpi2

sudo apt-get install git

y

git clone https://github.com/amperka/Troyka_Gpio_Expander_python.git

cd Troyka_Gpio_Expander_python/

python example.py

