import gpioexp
from time import sleep

exp = gpioexp.gpioexp()

exp.__init__(42)    #  Start address
exp.changeAddr(4)  #  End address
sleep (1)
exp.__init__(4)    #  End address
sleep (1)
exp.saveAddr ()

    

