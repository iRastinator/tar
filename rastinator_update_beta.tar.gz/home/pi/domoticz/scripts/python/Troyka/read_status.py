import gpioexp
from time import sleep
import sys

st = 1
exp = gpioexp.gpioexp()


for i in range(1, 50):
    print(exp.digitalRead(i) )

