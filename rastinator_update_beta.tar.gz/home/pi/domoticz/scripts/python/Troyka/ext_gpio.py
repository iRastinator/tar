import gpioexp
from time import sleep
import sys

st = 1
exp = gpioexp.gpioexp()
exp.__init__(int(sys.argv[1])) #43

if int(sys.argv[3]) == 0 : st = 1
if int(sys.argv[3]) == 1 : st = 0
	

exp.digitalWrite(int(sys.argv[2]), st) 

