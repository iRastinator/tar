from bluepy.btle import Peripheral, BTLEException
import struct
import urllib.request
import time
import sys

# Константы для уровня заряда батареи
BATT_100 = 3190
BATT_0 = 2900
READ_UUID = "0000ff02-0000-1000-8000-00805f9b34fb"

def decode(byte_frame):
    frame_array = list(byte_frame)
    size = len(frame_array)

    for i in range(size - 1, 0, -1):
        tmp = frame_array[i]
        hibit1 = (tmp & 0x55) << 1
        lobit1 = (tmp & 0xAA) >> 1
        tmp = frame_array[i - 1]
        hibit = (tmp & 0x55) << 1
        lobit = (tmp & 0xAA) >> 1
        frame_array[i] = 0xFF - (hibit1 | lobit)
        frame_array[i - 1] = 0xFF - (hibit | lobit1)

    return frame_array

def decode_position(decoded_data, idx):
    return struct.unpack('>h', bytes(decoded_data[idx:idx + 2]))[0]

def domoticzrequest(url):
    request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    try:
        urllib.request.urlopen(request)
    except Exception as e:
        print(f"Request error: {e}")

def read_sensor_data(address, retries=3):
    for attempt in range(retries):
        try:
            print(f"\n{'='*40}\nAttempt {attempt+1} of {retries}")
            print(f"Connecting to {address}...")
            
            device = Peripheral(address)
            print("Connection successful!")
            
            char = device.getCharacteristics(uuid=READ_UUID)[0]
            data = char.read()
            decoded = decode(data)
            
            result = {
                'temperature': decode_position(decoded, 13) / 10.0,
                'ec': decode_position(decoded, 5),
                'ph': decode_position(decoded, 3) / 100.0,
                'orp': decode_position(decoded, 9),#/ 1000.0,
                'cloro': decode_position(decoded, 11) / 10.0,
                'tds': decode_position(decoded, 7),
                'battery': min(max(0, round(100 * (decode_position(decoded, 15) - BATT_0) / (BATT_100 - BATT_0))), 100)
            }
            
            device.disconnect()
            print("Disconnected from device")
            return result
            
        except BTLEException as e:
            print(f"Connection error: {e}")
            if attempt < retries - 1:
                print("Retrying in 5 seconds...")
                time.sleep(5)
    return None

def print_sensor_data(data):
    print("\nSensor Data:")
    print(f"  Temperature:    {data['temperature']:>5.1f} °C")
    print(f"  EC:             {data['ec']:>5} µS/cm")
    print(f"  pH:             {data['ph']:>5.2f}")
    print(f"  ORP:            {data['orp']:>6} mV")
    print(f"  Free Chlorine:  {data['cloro']:>5.1f} ppm")
    print(f"  TDS:            {data['tds']:>5} ppm")
    print(f"  Battery:        {data['battery']:>5}%")
    print("="*40 + "\n")

def update_domoticz(server, address, idx_temp, idx_ec, idx_ph, idx_orp, idx_cloro, idx_tds):
    data = read_sensor_data(address)
    
    if not data:
        print("\n❌ Failed to get sensor data after retries")
        return

    print_sensor_data(data)
    battery = str(data['battery'])
    
    params = [
        (idx_temp, "temperature", str(data['temperature'])),
        (idx_ec, "ec", str(data['ec'])),
        (idx_ph, "ph", str(data['ph'])),
        (idx_orp, "orp", str(data['orp'])),
        (idx_cloro, "cloro", str(data['cloro'])),
        (idx_tds, "tds", str(data['tds']))
    ]

    print("Sending data to Domoticz:")
    for idx, param_type, value in params:
        if idx == '0': 
            print(f"  {param_type.capitalize():<12} [skipped]")
            continue
            
        url = f"http://{server}:8080/json.htm?type=command&param=udevice&idx={idx}"
        if param_type == "temperature":
            url += f"&nvalue=0&svalue={value}"
        else:
            url += f"&svalue={value}"
        
        url += f"&battery={battery}"
        
        print(f"  {param_type.capitalize():<12} => IDX {idx}")
        domoticzrequest(url)
        time.sleep(1)
    
    print("Data transmission complete!\n")

if __name__ == "__main__":
    # Режим отображения данных (только MAC-адрес)
    if len(sys.argv) == 2:
        mac_address = sys.argv[1]
        print(f"\n{'='*30}\nReading data from {mac_address}\n{'='*30}")
        data = read_sensor_data(mac_address)
        if data:
            print_sensor_data(data)
        else:
            print("\n❌ Failed to get sensor data")
    
    # Режим отправки в Domoticz (полный набор параметров)
    elif len(sys.argv) == 9:
        domoticz_server = sys.argv[1]
        mac_address = sys.argv[2]
        
        update_domoticz(
            server=domoticz_server,
            address=mac_address,
            idx_temp=sys.argv[3],
            idx_ec=sys.argv[4],
            idx_ph=sys.argv[5],
            idx_orp=sys.argv[6],
            idx_cloro=sys.argv[7],
            idx_tds=sys.argv[8]
        )
    
    # Некорректные параметры
    else:
        print("Usage options:")
        print("1. Local display: python3 script.py <MAC_ADDRESS>")
        print("2. Domoticz update: python3 script.py <DOMOTICZ_IP> <MAC> <idx_temp> <idx_ec> <idx_ph> <idx_orp> <idx_cloro> <idx_tds>")
        print("\nExample:")
        print("  Local:   python3 script.py AA:BB:CC:DD:EE:FF")
        print("  Domoticz: python3 script.py 192.168.1.100 AA:BB:CC:DD:EE:FF 100 101 102 103 104 105")
        sys.exit(1)
