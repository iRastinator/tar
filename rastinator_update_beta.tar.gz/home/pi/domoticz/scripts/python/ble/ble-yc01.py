from bluepy.btle import Peripheral, BTLEException
import struct

# MAC-адрес устройства
DEVICE_ADDRESS = "C0:00:00:03:EC:C4"  # Замените на ваш MAC-адрес

# UUID для чтения данных
READ_UUID = "0000ff02-0000-1000-8000-00805f9b34fb"

# Константы для уровня заряда батареи
BATT_100 = 3190
BATT_0 = 2900

def decode(byte_frame):
    """Декодирование байтовой строки в массив чисел."""
    frame_array = list(byte_frame)  # Преобразуем байты в список чисел
    size = len(frame_array)

    for i in range(size - 1, 0, -1):
        tmp = frame_array[i]
        hibit1 = (tmp & 0x55) << 1
        lobit1 = (tmp & 0xAA) >> 1
        tmp = frame_array[i - 1]
        hibit = (tmp & 0x55) << 1
        lobit = (tmp & 0xAA) >> 1
        frame_array[i] = 0xFF - (hibit1 | lobit)
        frame_array[i - 1] = 0xFF - (hibit | lobit1)

    return frame_array

def decode_position(decoded_data, idx):
    """Извлечение 2-байтового значения (int16, big-endian)."""
    return struct.unpack('>h', bytes(decoded_data[idx:idx + 2]))[0]

def read_device_data(address):
    """Подключение к устройству и чтение данных."""
    try:
        # Подключение к устройству
        device = Peripheral(address)
        print(f"Подключено к устройству {address}")

        # Получение характеристики
        char = device.getCharacteristics(uuid=READ_UUID)[0]
        data = char.read()

        # Декодирование данных
        decoded_data = decode(data)

        # Извлечение значений
        temperature = decode_position(decoded_data, 13) / 10.0  # Температура
        ec = decode_position(decoded_data, 5)  # Электропроводность
        ph = decode_position(decoded_data, 3) / 100.0  # Уровень pH
        orp = decode_position(decoded_data, 9) / 1000.0  # ORP
        cloro = decode_position(decoded_data, 11) / 10.0  # Свободный хлор
        tds = decode_position(decoded_data, 7)  # Общее количество растворенных веществ
        battery = round(100 * (decode_position(decoded_data, 15) - BATT_0) / (BATT_100 - BATT_0))  # Уровень заряда батареи
        battery = min(max(0, battery), 100)  # Ограничение значения от 0 до 100

        # Вывод данных
        print("Данные с устройства:")
        print(f"Температура: {temperature} °C")
        print(f"Электропроводность (EC): {ec} µS/cm")
        print(f"Уровень pH: {ph}")
        print(f"Окислительно-восстановительный потенциал (ORP): {orp} mV")
        print(f"Свободный хлор: {cloro} ppm")
        print(f"Общее количество растворенных веществ (TDS): {tds} ppm")
        print(f"Уровень заряда батареи: {battery} %")

    except BTLEException as e:
        print(f"Ошибка подключения к устройству: {e}")
    finally:
        # Отключение от устройства
        if 'device' in locals():
            device.disconnect()
            print("Отключено от устройства")

if __name__ == "__main__":
    # Запуск чтения данных
    read_device_data(DEVICE_ADDRESS)
