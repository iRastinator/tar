

commandArray = {} 
------------------------------------------------------------------------------ 
------------------------------ Установки -------------------------------------

-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>x<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<--
-->>>>>>>>>>>>>>>>>>>>>>>>>>>> Программная часть <<<<<<<<<<<<<<<<<<<<<<<<<<<<<--
------------------------------ Ver. 09.10.22 (0)-----------------------------------

m = os.date('%M')
sec = os.date('%S')
hr = os.date('%H')
day = os.date('%d')
vr = hr .. ':' .. m ..':' .. sec

local function timedifference (s)
   year = string.sub(s, 1, 4)
   month = string.sub(s, 6, 7)
   day = string.sub(s, 9, 10)
   hour = string.sub(s, 12, 13)
   minutes = string.sub(s, 15, 16)
   seconds = string.sub(s, 18, 19)
   t1 = os.time()
   t2 = os.time{year=year, month=month, day=day, hour=hour, min=minutes, sec=seconds}
   difference = os.difftime (t1, t2)
   return difference
end



--- Создание переменной для стопора запуска других сриптов если ранее не создовалась и присвоение 0
--print (">>> Сервис-1 в работе")

if ( uservariables['Stop_flag'] == nil ) then 
    print ( "--> Создание переменной для котроля запуска других скриптов ...") 
    st = 'curl "127.0.0.1:8080/json.htm?type=command&param=adduservariable&vname=Stop_flag&vtype=2&vvalue=0"'
    os.execute (st)
    return commandArray
end

-- Если Stop_flag устанвлен больше 60 мин - сброс до 0 и пеезагрузка
if ( uservariables['Stop_flag'] ~= nil and   uservariables['Stop_flag'] ~= '0' and   uservariables['Stop_flag'] ~= '-1') then


    -- Определение времени обновления Переменной пользователя Stop_flag
    local url = 'curl "127.0.0.1:8080/json.htm?type=command&param=getuservariables" | grep -C 3 "Stop_flag" | grep "LastUpdate" | awk '.."'{print $3 "..'" " $4}'.."' | sed 's/"..'"//g'.."' | sed 's/,//g'"
    local file = assert(io.popen(url, 'r'))
    local output = file:read('*all')
    file:close()

    output= timedifference(output)
    --print ("Stop_Flag ВЫКлючен - идет полив: " .. output .. " сек.")

    if(output > 3600 ) then 
         commandArray[ 'Variable:Stop_flag' ] = '0'
         print (">>>  Stop_flag - обнулен! ... Презагрузка!...")
             
         local str = 'sudo echo "' .. vr ..' ' .. 'Stop_flag - обнулен!! Перезагрузка !!!" | mail -s "' .. vr ..' ' .. 'Stop_flag - обнулен!! Перезагрузка !!! " ' .. email
         if (email ~= "" ) then os.execute (str) end 
         os.execute ("sudo reboot")  
         
    end

end

function trim(s)
  return (string.gsub(s, "^%s*(.-)%s*$", "%1"))
end 

-- Действия при старте процесса Domoticz
-- Обнуление Stop_flag
local cmd = 'pidof domoticz'  -- получить id процесса domoticz
local file = assert(io.popen(cmd, 'r'))
local output = file:read('*all')
file:close()

local cmd = 'ps -p ' .. tonumber(output) .. ' -o etime=' -- время с последней загрузки процесса domoticz
local file = assert(io.popen(cmd, 'r'))
local output = file:read('*all')
file:close()
output = trim (output)
if (string.len(trim(output)) == 5 and string.sub(output,1,2) == '00')
then
    commandArray[ 'Variable:Stop_flag' ] = '0'
    print ("Stop_flag - обнулен при перезагрузке!")  
    print ("Выключение выключателей ...")
            -- Загрузка библиотеки JSON
            json = (loadfile "/home/pi/domoticz/scripts/lua/JSON.lua")()
            
            -- Получение списка всех используемых выключателей
            local handle = io.popen([[
            curl -s 'http://127.0.0.1:8080/json.htm?type=devices&filter=light&used=true&order=name'
            ]])
            local response = handle:read('*a')
            handle:close()
            
            -- Декодирование JSON ответа
            local devices = json:decode(response)
            
            if devices and devices.result then
                for _, device in ipairs(devices.result) do
                    -- Проверяем только устройства типа Light/Switch
                    if device.Type == 'Light/Switch' then
                        -- Проверяем текущий статус
                        if device.Status == 'On' then
                            commandArray[device.Name] = 'Off'
                            print('Выключаем: '..device.Name..' ('..device.idx..')')
                        end
                    end
                end
            end



end

return commandArray


-- Конец програмной части
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------




