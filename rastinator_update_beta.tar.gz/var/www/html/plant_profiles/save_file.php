<style>
	@import "../style.css" screen; /* Стиль для вывода результата на монитор */
    @import "../style.css" print, handheld; /* Стиль для печати и смартфона */

</style>                                    

<div style="Position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);">
	<?php include('../pic/process.svg'); ?> 
</div>

<?php
                                      
//echo '</br>_POST=';
//var_dump($_POST); exit;
//echo '</br>Button=';
//var_dump(isset($_POST['run_script']));
//exit();
    //var_dump($_POST['Name_unit_info']); exit();
    
//var_dump($_POST);
//var_dump($_POST['Name_unit']); exit();

// Если произошел сбой при отправкие формы  и последний проверочный input отсутствует - то выход.
if($_POST["cheсk"] != "check") { exit();}

$filename=''; // Имя файла для отправки в climat.php

function utf8_urldecode($str) 
    {$str = preg_replace("/%u([0-9a-f]{3,4})/i","&#x\\1;",urldecode($str));
     return html_entity_decode($str,null,'UTF-8');;
    }




// Если  сохранить изменения - удаляется старый файл и дальше генерится новой -----------------
// удаляем переменную для старого названия и создаем новую

if(isset($_POST['save_changes']) or isset($_POST['del'])) 
{   
    
   //Удаление файла скрипта
$comand = ' rm '.$_POST['origen_file'];
    //echo $comand; 
$output = shell_exec($comand);
	$fileName =""; // если удаление файла

}
    
//exit();





// Создание нового файла профиля растения ------------------------------------------------------

if (isset($_POST['save_changes']) || isset($_POST['new_porfile'])) 
{  

        
    //$filename = "rast_".$_POST[Name_unit];
    
    //$name_o = str_replace('/home/pi/domoticz/scripts/lua/plant_profiles/', '', $_POST['origen_file']);
	
// Директория для сохранения файла
$directory = "/home/pi/domoticz/scripts/lua/plant_profiles/";

// Имя файла по ключу "Name_unit"
$fileName = $directory .'rast_'. $_POST["Name_unit"];
//echo $fileName; exit;
// Открываем файл для записи
$fileHandle = fopen($fileName, 'w');

if ($fileHandle) {
    // Перебираем массив и формируем строки для записи
    foreach ($_POST as $key => $value) {
		$value = trim($value);
        // Обрабатываем ключи с "Name_unit_info_"
		
		if (strpos($key, "Name_unit_info_") === 0 and $value == '')
		{
		$del = 1;	
		}
		elseif (strpos($key, "Name_unit_info_") === 0 and $value != '')
		{
		$del = 0;	
		}
		if ($del == 1){continue;}
		
		
        if (strpos($key, "Name_unit_info_") === 0 ) {
            fwrite($fileHandle, "info: " . $value . "\n");
			
        }
        // Обрабатываем ключи с "kg_"
        else if (strpos($key, "kg_") === 0) {
            fwrite($fileHandle, $value . " ");
        }
		        // Обрабатываем ключи с "gl_"
        else if (strpos($key, "gl_") === 0) {
            fwrite($fileHandle, $value . " ");
        }
        // Обрабатываем ключи с "label_"
        else if (strpos($key, "label_") === 0) {
            fwrite($fileHandle, "label<" . $value . ">label ");
        }
        // Обрабатываем ключи с "info_"
        else if (strpos($key, "info_") === 0) {
            fwrite($fileHandle, "info<" . $value . ">info\n");
        }
    }

    // Закрываем файл
    fclose($fileHandle);
    //echo "Файл успешно создан: $fileName";
} else {
    //echo "Не удалось создать файл.";
}



}
else { $query_string = $_SERVER['QUERY_STRING'];}




 


 

// Эта форма отправляется автоматом после загрузки страницы
echo 
     '
<html>
<body onload="document.frm1.submit()">
   <form action="index.php" name="frm1" method="POST">
      <input type="hidden" name="rast" value="'.$fileName.'" />
   </form>
</body>
</html>
' 




?>


