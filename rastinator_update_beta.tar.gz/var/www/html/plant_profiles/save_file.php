<style>
	@import "../style.css" screen; /* Стиль для вывода результата на монитор */
    @import "../style.css" print, handheld; /* Стиль для печати и смартфона */

</style>                                    

<div style="Position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);">
	<?php include('../pic/process.svg'); ?> 
</div>

<?php
                                      
//echo '</br>_POST=';
//var_dump($_POST); exit;
//echo '</br>Button=';
//var_dump(isset($_POST['run_script']));
//exit();
    //var_dump($_POST['Name_unit_info']); exit();
    
//var_dump($_POST);
//var_dump($_POST['Name_unit']); exit();

// Если произошел сбой при отправкие формы  и последний проверочный input отсутствует - то выход.
if($_POST["cheсk"] != "check") { exit();}

$filename=''; // Имя файла для отправки в climat.php

function utf8_urldecode($str) 
    {$str = preg_replace("/%u([0-9a-f]{3,4})/i","&#x\\1;",urldecode($str));
     return html_entity_decode($str,null,'UTF-8');;
    }




// Если  сохранить изменения - удаляется старый файл и дальше генерится новой -----------------
// удаляем переменную для старого названия и создаем новую

if(isset($_POST['save_changes']) or isset($_POST['del'])) 
{   
    
   //Удаление файла скрипта
$comand = ' rm '.$_POST['origen_file'];
    //echo $comand; 
$output = shell_exec($comand);
	$fileName =""; // если удаление файла

}
    
//exit();





// Создание нового файла профиля растения ------------------------------------------------------

if (isset($_POST['save_changes']) || isset($_POST['new_porfile']) or $_POST['butt_delete_flag'] == "del") 
{  
	
// Директория для сохранения файла
$directory = "/home/pi/domoticz/scripts/lua/plant_profiles/";

// Имя файла по ключу "Name_unit"
$fileName = $directory .'rast_'. $_POST["Name_unit"];

	

// Проверка на существование файла и создание нового имени если файл есть
		$baseName =  'rast_'. $_POST["Name_unit"];
		$count = 1; // Инициализируем счетчик

		// Проверка существования файла и добавление суффикса, если файл существует
		while (file_exists($fileName) and $_POST['butt_delete_flag'] != "del") {
			// Проверяем, если имя файла уже содержит суффикс -N
			if (preg_match('/-(\d+)$/', $baseName, $matches)) {
				// Увеличиваем текущий счетчик на 1
				$count = (int)$matches[1] + 1; 
				// Убираем суффикс -N для основы
				$baseName = preg_replace('/-\d+$/', '', $baseName);
			}

			// Если нет суффикса, начинаем с 1
			$fileName = $directory . $baseName . '-' . $count; // Обновляем имя файла
			$count++; // Увеличиваем счетчик
		}
//-------------	
	
	
	
	
// Открываем файл для записи
$fileHandle = fopen($fileName, 'w');


	

	
if ($fileHandle) {
    // Перебираем массив и формируем строки для записи
    foreach ($_POST as $key => $value) {
		$value = trim($value);
        // Обрабатываем ключи с "Name_unit_info_"
		
		if (strpos($key, "Name_unit_info_") === 0 and $value == '')
		{
		$del = 1; 
		}
		elseif (strpos($key, "Name_unit_info_") === 0 and $value != '')
		{
		$del = 0;	
		}
		if ($del == 1 ){continue;}
		
		
        if (strpos($key, "Name_unit_info_") === 0 ) {
            fwrite($fileHandle, "info: " . $value . " ");
			
        }
		else if (strpos($key, "Unit_info_") === 0 ) {
        fwrite($fileHandle, " info<" . $value .">info\n" );
        // Обрабатываем ключи с "kg_"
		}
		else if (strpos($key, "kg_") === 0) {
            fwrite($fileHandle, $value . " ");
        }
		        // Обрабатываем ключи с "gl_"
        else if (strpos($key, "gl_") === 0) {
            fwrite($fileHandle, $value . " ");
        }
        // Обрабатываем ключи с "label_"
        else if (strpos($key, "label_") === 0) {
            fwrite($fileHandle, "label<" . $value . ">label ");
        }
        // Обрабатываем ключи с "info_"
        else if (strpos($key, "info_") === 0) {
            fwrite($fileHandle, "info<" . $value . ">info\n");
        }
    }

    // Закрываем файл
    fclose($fileHandle);
    //echo "Файл успешно создан: $fileName";
} else {
    //echo "Не удалось создать файл.";
}



}
else { $query_string = $_SERVER['QUERY_STRING'];}




// Добавляем копию записи
if ($_POST['butt_delete_flag'] != "del" and $_POST['butt_delete_flag'] != "") 
	
{
	$butt_delete_flag = $_POST['butt_delete_flag'];
    $only_digits = preg_replace('/\D/', '', $butt_delete_flag);
	
	$str_start = $only_digits;
	if ($only_digits == null){$str_start = 0;}
	
	// Директория для сохранения файла
	$directory = "/home/pi/domoticz/scripts/lua/plant_profiles/";
	// Имя файла по ключу "Name_unit"
	$fileName = $directory . 'rast_' . $_POST["Name_unit"];

	// Открываем файл для чтения
	$fileContent = file($fileName);

	// Проверяем, достаточно ли строк
	if (count($fileContent) >= 8) { 
		// Получаем строки 
		$linesToCopy = array_slice($fileContent, $str_start, 8);

		// Объединяем строки в одну строку
		$copyContent = implode('', $linesToCopy); // Сохраняем строки, которые будем дублировать

		// Открываем файл на запись
		$fileHandle = fopen($fileName, 'w');

		if ($fileHandle) {
			// Записываем обратно все строки
			foreach ($fileContent as $line) {
				fwrite($fileHandle, $line);
			}

			// Дублируем строки
			fwrite($fileHandle, $copyContent); // Добавляем повторные строки

			// Закрываем файл
			fclose($fileHandle);

			//echo "Строки успешно скопированы и добавлены в файл.";
		} else {
			//echo "Ошибка: не удалось открыть файл для записи.";
		}
	} else {
		//echo "Недостаточно строк в файле для выполнения операции.";
	}
	
}
 


 

// Эта форма отправляется автоматом после загрузки страницы
echo 
     '
<html>
<body onload="document.frm1.submit()">
   <form action="index.php" name="frm1" method="POST">
      <input type="hidden" name="rast" value="'.$fileName.'" />
   </form>
</body>
</html>
' 




?>


