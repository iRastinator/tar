<!DOCTYPE html>
<html>
  <head>
   <meta name = "viewport" content = "width=device-width, initial-scale=1">
    <meta charset="utf-8" />
    <title>Rastinator</title>
<script type="text/javascript" src="/ajax/jquery-3.7.0.min.js"></script>
<style>
     @import "../style.css" screen; /* Стиль для вывода результата на монитор */
     @import "../style.css" print, handheld; /* Стиль для печати и смартфона */

     *{
        padding: 0%;
        margin: 0%;
      }
		.container {
			grid-template-columns: clamp(11rem, 5.909rem + 25.45vw, 25rem) clamp(6.25rem, 2.841rem + 17.05vw, 15.625rem) clamp(2.5rem, -1.136rem + 18.18vw, 12.5rem) auto;
			display: grid;
		}

		.item {

			padding: 0px;
			border: 0px solid black;

		}

		.item_1 {
			grid-column-start: 1;
			grid-column-end: 5;
		}

		.item_2 {
			grid-column-start: 1;
			grid-column-end: 5;
		}

		.item_4 {
			grid-row-start: 3;

			grid-column-start: 1;
			grid-column-end: 5;
		}

		.item_3 {
						
		grid-row-start: 4;
		grid-row-end: 150;	
			padding-top: 3px;
			padding-right: 1px;
		}
		.zatichka {
		    grid-row-start: 150;
			grid-row-end: 150;
				
		}

		@media (max-width: 1000px) {
			.container {
			grid-template-columns: 1px clamp(8rem, 6.857rem + 12.19vw, 16rem) clamp(4rem, 2.714rem + 13.71vw, 13rem) auto;
			display: grid;
			}

			.zatichka {
		    grid-row-start: 5;
			grid-row-end: 150;
				
			}

			.item_3 {
				grid-row-start: 4;
				grid-row-end: 4;
				grid-column-start: 1;
				grid-column-end: 5;
				padding-top: 3px;
				padding-right: 1px;
				display: flex;
			}





		  }
    
</style>      
          
</head>

<body>



<?php
	
// Включаем отображение ошибок
//error_reporting(E_ALL);          // Сообщать обо всех ошибках
//ini_set('display_errors', 1);  // Включить отображение ошибок
//var_dump ($_POST);//exit;	
	
//Авторизация
include('../login/in.php');    
    
function debug_to_console($data) {
    $output = $data;
    if (is_array($output))
        $output = implode(',', $output);
    echo "<script>console.log('Debug Objects: " . $output . "' );</script>";
}    
?>
    

<div class="container">
     <div class="zatichka"></div>

<!-- Верхнее меню -->     
<div class="item item_1">
        <ul>
		<li><svg width="clamp(6.25rem, 3.977rem + 11.36vw, 12.5rem)" height="clamp(1rem, 0.786rem + 2.29vw, 2.5rem)" viewBox="150 -30 180 180"> <?php include('../pic/Rastinator.svg'); ?> </svg> </li>
          <li><a href="../poliv/index.php" >Полив</a></li>   
          <li><a href="../climat/index.php">Климат</a></li>
          <li><a href="../sensors/index.php">Датчики</a></li>
          <li><a href="../settings/index.php">Настройки</a></li>
          <li><a class="active" >Профили</a></li>
          <li><a href="../log_poliva/index.php">Журнал полива</a></li>
          <li><a href="../log_domoticz/index.php">Лог системы</a></li>
          <!--  <li style="float:right"><a href="">Ver.13.08.2023</a></li>  -->
        </ul>  
    

    
</div>           

		<!-- Информационная панель - отображение данных лога -->
		<div class="item item_2">
			<script type="text/javascript">
				$(document).ready(function() {
					var updateInfo = function() {
						$.ajax({
							url: '../log/log.php',
							cache: false, // Предотвращаем кэширование запроса
							success: function(response) {
								var trimmedResponse = response.trim();
								// Проверка наличия времени в формате HH:MM
								if (/(\b[01]?[0-9]:[0-5][0-9]\b|\b2[0-3]:[0-5][0-9]\b)/.test(trimmedResponse)) {
									$("#info").css("color", ""); // Сброс цвета
									$(".info_climat").css("color", ""); // Сброс цвета для классов
									$("#info").html(trimmedResponse); // Обновление содержимого
								} else {
									$("#info").css("color", "gray"); // Окрашивание в серый цвет
									$(".info_climat").css("color", "gray"); // Окрашивание в серый цвет для классов
									// Не обновляем содержимое
								}
							},
							error: function() {
								console.error("Ошибка при загрузке данных из log.php");
							}
						});
					};

					var updateInfoBar = function() {
						$("#info_bar").load('../log/log_bar.php');
					};

					setInterval(updateInfo, 2000);
					setInterval(updateInfoBar, 2000);
				});
			</script>

			<div id="info_bar">
				<?php include('../log/log_bar.php'); ?>
			</div>

			<div id="info">
				<?php include('../log/log.php'); ?>
			</div>
		</div>
    
 
<!-- Select с названиями файлов --> 
<div class="item item_3">                        
   
<form id="myform" method="POST" action="index.php">
        
<?php
$path = "/home/pi/domoticz/scripts/lua/plant_profiles/";
	
$des = '';

// Получаем все файлы в директории
$files = glob($path . "rast_*");
$x = count($files) + 1; // +1 для учета заголовка

// Получаем все содержимое директории
$allFiles = scandir($path);
// Фильтруем только файлы и исключаем '.' и '..'
foreach ($allFiles as $file) {
	$fullPath = $path . $file;
	// Проверяем, является ли это файлом
	if (is_file($fullPath)) {
		$firstFile = $file; // Находим первый файл
		break; // Выходим из цикла после нахождения первого файла
	}
}
	

// Открываем директорию
if ($handle = opendir($path)) {
    $count = 0;

    // Начинаем вывод `<select>`
    echo '<select class="main" size="' . $x . '" name="rast" id="select_rast" onchange="this.form.submit()">';

    // Каждому файлу создаем элемент `<option>`
    foreach ($files as $file) {
		// Выделяем загружаемую позицию селекта
		$ins_selected = '';
    	if ($_POST['rast'] == "" and basename($file) == basename($firstFile) ){
		$ins_selected = 'selected';
		}
			
		if ($_POST['rast'] == $file )
		{ $ins_selected = 'selected'; }
		
        // Проверяем, что это файл и имя файла начинается с "rast_"
        if (is_file($file) && strpos(basename($file), 'rast_') === 0) {
            $filename = basename($file); // Получаем только имя файла
            // Убираем префикс "rast_" для отображения
            $displayName = substr($filename, strlen('rast_'));
            echo '<option style="color:gray" '.$ins_selected.' value="' . $file . '">' . htmlspecialchars($displayName, ENT_QUOTES, 'UTF-8') . '</option>';
            $count++;
        }
    }

    // Проверка на последний элемент для управления кнопкой
    if ($count == 1) {
        $des = 'disabled';
    }

    echo '</select>'; // Закрываем тег select
    closedir($handle); // Закрываем директорию
}
	
	
	
if (isset ($_POST['rast']) and $_POST['rast'] != ''){
	$file_for_work = $_POST['rast'];
		}
		else{
	$file_for_work = "/home/pi/domoticz/scripts/lua/plant_profiles/".$firstFile;
		//echo $file_for_work; exit;	
		
		}
?>



</form>   
</div> 
	
	
	
<!-- item item_4 - Кнопки включить отключить удалить Запустить остановить -  ----------> 
<div class="item item_4">
    
    
<div class="btn-group">
    
<form id="myform2" method="POST" action="save_file.php" >
        
    <button class="button" name="del" value="" type="submit" onclick="return confirm('Вы уверены, что хотите Удалить Профиль Растения? ?')" <?php echo $des; ?> >Удалить</button> 

    <?php  //Кнопки Удалить Отключить Включить

		

		echo '<input  name="del_file"  value="'.$file_for_work.'" type="hidden">';//
		
    ?>
    



     
    
    



<input class="button" type="submit" name="new_porfile" value="Сохранить новый профиль">  
<input class="button" type="submit" name="save_changes" value="Сохранить изменения">

    
</div>
        
	<div class="separation_div">  </div>
        
</div> 

    
<!-- item item_5 - Отображение загруженных настроек в инпуты ---------->

       <!----- Информация - имя файла при загрузке type="hidden" ----->
       <input  name="origen_file"  value='<?php echo $file_for_work; ?>' type="hidden" >
   
			
			<input readonly class="input_1"  value="Растение:">
                                  
                                                                                         
                                                                                                                                                                           
                   
      
	<?php
	             
            $Name = substr(basename($file_for_work), strlen('rast_')); // Выдиляем имя удаляем префикс "rast_"
		
	
			$line_count = 0; // Инициализируем счетчик
			// Открываем файл для чтения
			$fileHandle = fopen($file_for_work, 'r');

			if ($fileHandle) {
				// Считываем файл построчно
				while (fgets($fileHandle) !== false) {
					$line_count++; // Увеличиваем счетчик для каждой строки
				}
				fclose($fileHandle); // Закрываем файл
			}
	
	?>
		<!----- Скрытое поле для  имени без пробелов  ----->
		<input class="input_2" name="Name_unit" id="Name_unit" type="hidden" value="<?php echo $Name; ?>" title="Уникальное название!" autocomplete="off" onkeydown="if(event.keyCode==13){return false;}" >
		<!----- поле для отображении имени без _  ----->
		<input class="input_2" name="Name_unit_show" id="Name_unit_show" type="text" value="<?php echo str_replace('_', ' ', $Name); ?>" title="Уникальное название!" autocomplete="off" onkeydown="if(event.keyCode==13){return false;}" >
		
		<input readonly class="input_3_readonly"  value="">
		<div class="separation_div">  </div> 
		
		<div class="div_mac_button">  
		<input readonly class="input_mac"  value="грамм/литр">
		<?php  if($line_count > 8){
		echo '<input class="button_profile" id="butt_del" name="butt_del" value="-" readonly onclick="confirmDelete(0)">';
		} 
		?>
		
		<input class="button_profile" id="butt_add" name="butt_add" value="+" readonly onclick="add_copy(this.id)" />
		<input type="hidden" id="butt_delete_flag" name="butt_delete_flag" value="" >
		</div>
		
		
		
		
		
		
		<script>
			// Получаем доступ к полям
			const nameUnitInput = document.getElementById('Name_unit');
			const nameUnitShowInput = document.getElementById('Name_unit_show');

			// Добавляем обработчик события input
			nameUnitShowInput.addEventListener('input', function() {
				let inputValue = nameUnitShowInput.value;

				// Убираем все пробелы в конце строки
				inputValue = inputValue.replace(/\s+$/, ''); // Заменяем пробелы в конце строки

				// Заменяем все пробелы на "_" и обновляем скрытое поле
				nameUnitInput.value = inputValue.replace(/ /g, '_');
			});
		</script>

		
	
		<script>
			// Получаем элемент поля ввода по его ID
			const inputField = document.getElementById('Name_unit_show');

			// Обработчик события, выполняемый при нажатии клавиши
			inputField.addEventListener("keydown", function() {
				this.style.backgroundColor = "#B0F0B0"; // Изменение цвета фона на светло-зеленый
				this.style.color = "black"; // Изменение цвета текста на черный
			});

			// Обработчик события ввода, который фильтрует вводимые данные
			inputField.addEventListener('input', (event) => {
				const inputValue = event.target.value; // Получаем текущее значение поля

				// Регулярное выражение для допустимых символов (буквы, цифры, пробелы и дефисы)
				const allowedInput = /^[A-Za-zА-Яа-я0-9 -]+$/;

				// Если введенные символы не соответствуют разрешенным, удаляем их
				if (!allowedInput.test(inputValue)) {
					event.target.value = inputValue.replace(/[^A-Za-zА-Яа-я0-9 -]/g, ''); // Удаляем недопустимые символы
				}
			});

			// Дополнительно: сбросим цвет поля, когда оно теряет фокус
			inputField.addEventListener('blur', function() {
				this.style.backgroundColor = ""; // Сбрасываем цвет фона
				this.style.color = ""; // Сбрасываем цвет текста
			});
		</script>
		
		
   
 <?php           
            
	$file = fopen($file_for_work, 'r');

	for ($i = 0; $i < 200; $i++) 
	{
                
            $stroka = fgets($file);
            
			$parts = explode(' ', $stroka);
			// Проверьте, что у нас достаточно частей
			if (count($parts) >= 3) {
				$firstValue = trim($parts[0]); // Первое значение
			}

			// Извлечение второго значения между ">label" и "info<"
			$secondValue = '';
			//	
			if (strripos($stroka, 'label<')) {
				$pos_1 =strripos($stroka, '>label')+6;
				$pos_2 = strripos($stroka, 'info<');

			$secondValue = trim(substr($stroka, $pos_1 , $pos_2 - $pos_1 ));
			}
            
		
		
            if (substr($stroka , 0, 5) == 'info:')
			{
				if ($i > 1){
				echo'<div class="separation_div">  </div>

					<div class="div_mac_button"> 
					<input id="blok_'.$i.'" readonly class="input_mac" value="грамм/литр">

					<input class="button_profile" id="butt_del_'.$i.'" name="butt_del_'.$i.'" value="-" readonly onclick="confirmDelete('.$i.')" >

					<input class="button_profile" id="butt_add_'.$i.'" name="butt_add_'.$i.'" value="+" readonly onclick="add_copy(this.id)" />
					</div>'; }
					echo '

					<script>
					function confirmDelete(i) {
						// Запрос на подтверждение действия
						if (confirm("Вы уверены, что хотите удалить данные?")) {
							// Стираем данные из указанного поля
							document.getElementById("Name_unit_info_" + i).value = "";
							document.getElementById("butt_delete_flag").value = "del";

							// Отправляем форму
							document.getElementById("myform2").submit();
						}
					}

					function add_copy(elementId) {
						// Устанавливаем значение элемента "butt_delete_flag" равным id вызывающего элемента
						document.getElementById("butt_delete_flag").value = elementId;

						// Отправляем форму
						document.getElementById("myform2").submit();
					}
					</script>
							';  
				
				
            echo '<input name="Name_unit_info_'.$i.'" id="Name_unit_info_'.$i.'" class="input_2" value="'.substr($stroka , 6, strlen($stroka)).'" autocomplete="off" onkeydown="if(event.keyCode==13){return false;}">
            <script>Name_unit_info_'.$i.'.addEventListener("input", function(){this.style.backgroundColor = "#B0F0B0";this.style.color="black";})</script>
			<input readonly class="input_3_readonly"  value="">
			'; 
            }
            
            $pos1      = strripos($stroka, 'label<');
            $pos2      = strripos($stroka, '>label');  
                            
            if ($pos1 == TRUE) // Если первый label< существует - всегда существет у всех установок
             {            
                    
			   $Label = substr($stroka , $pos1+6 , $pos2-$pos1-6);
			   $str = $stroka ;
                
				// Создание Label    
echo '

<div class="div_mac_button">
    <input type="text" class="input_rast_kg" id="kg_'.$i.'" name="kg_'.$i.'" 
           value="'.$firstValue.'" autocomplete="off" onkeydown="if(event.keyCode==13){return false;}" 
           oninput="validateInput(this); updateGlValue('.$i.')" >

    <input type="hidden" class="input_rast_kg" id="orig_kg'.$i.'" name="orig_kg'.$i.'" 
           value="'.$firstValue.'" autocomplete="off" onkeydown="if(event.keyCode==13){return false;}" >

    <input type="text" class="input_1" id="label_'.$Label.$i.'" name="label_'.$i.'" 
           value="'.$Label.'" autocomplete="off" onkeydown="if(event.keyCode==13){return false;}" >                       
</div>

<input type="text" class="input_2" id="gl_'.$i.'_dig" name="gl_'.$i.'_dig" 
       value="'.$secondValue.'" autocomplete="off" onkeydown="if(event.keyCode==13){return false;}" 
       oninput="validateInput(this); updateKgValue('.$i.')"> 

<input class="input_2" id="orig_gl'.$i.'_dig" type="hidden" name="orig_gl'.$i.'_dig" 
       value="'.$secondValue.'" autocomplete="off" onkeydown="if(event.keyCode==13){return false;}"> 

<script>
    function validateInput(input) {
        // Удаляем все символы, кроме цифр и одной десятичной точки
        input.value = input.value.replace(/[^0-9.]/g, \'\').replace(/(\\..*?)\\..*/g, \'$1\');
    }

    function updateGlValue(i) {
	    var chkEdit = document.getElementById("chk_edit");
        if (chkEdit.checked) return; // Если чекбокс отмечен, выходим из функции
		
        var kgInput = document.getElementById("kg_" + i);
        var origKgInput = document.getElementById("orig_kg" + i);
        var glInput = document.getElementById("gl_" + i + "_dig");
        var origGlInput = document.getElementById("orig_gl" + i + "_dig");

        var currentKgValue = parseFloat(kgInput.value) || 0;
        var origKgValue = parseFloat(origKgInput.value) || 1; // по умолчанию, чтобы избежать деления на 0
        var origGlValue = parseFloat(origGlInput.value) || 0;

        // Если оригинальное значение kg больше 0, рассчитываем новое значение gl
        if (origKgValue > 0) {
            var multiplier = currentKgValue / origKgValue; // вычисляем множитель
            glInput.value = (origGlValue / multiplier).toFixed(2); // обновляем значение gl
        } else {
            glInput.value = origGlValue; // если был ноль, просто вернуть оригинальное значение
        }
    }

    function updateKgValue(i) {
	    var chkEdit = document.getElementById("chk_edit");
        if (chkEdit.checked) return; // Если чекбокс отмечен, выходим из функции
		
        var kgInput = document.getElementById("kg_" + i);
        var glInput = document.getElementById("gl_" + i + "_dig");
        var origKgInput = document.getElementById("orig_kg" + i);
        var origGlInput = document.getElementById("orig_gl" + i + "_dig");

        var currentGlValue = parseFloat(glInput.value) || 0;
        var origGlValue = parseFloat(origGlInput.value) || 1; // по умолчанию, чтобы избежать деления на 0
        var origKgValue = parseFloat(origKgInput.value) || 0;

        // Если оригинальное значение gl больше 0, рассчитываем новое значение kg
        if (origGlValue > 0) {
            var multiplier = currentGlValue / origGlValue; // вычисляем множитель
            kgInput.value = (origKgValue * multiplier).toFixed(2); // обновляем значение kg
        } else {
            kgInput.value = origKgValue; // если был ноль, просто вернуть оригинальное значение
        }
    }

    // Добавим обработчики для полей ввода
    document.getElementById("kg_'.$i.'").addEventListener("input", function() {
        this.style.backgroundColor = "#B0F0B0";
        this.style.color = "black";
    });

    document.getElementById("gl_'.$i.'_dig").addEventListener("input", function() {
        this.style.backgroundColor = "#B0F0B0";
        this.style.color = "black";
    });
</script>
';
                    
		   		// Добавление названиия 
				$pos1  = strripos($stroka, 'info<');
				$pos2  = strripos($stroka, '>info');
				if ($pos1 !== FALSE) // Если info< существует
				{

					echo'
					<input class="input_3_readonly" id="'.$i.'_info" name="info_'.$i.'" type="text" value="'.substr($stroka , $pos1+5 , $pos2-$pos1-5).'" title="'.substr($stroka , $pos1+5 , $pos2-$pos1-5).'" onkeydown="if(event.keyCode==13){return false;}" >';}
                    
                    
                                       
                 
                    
                }
            
          
                
	}   
	fclose($file); 
        
         


        
        
?>    
    
    

    
    


    
<input type="hidden" name="cheсk" value="check"> <!--  Проверочный инпут в конце ------>


</form>    
    
  
 <div class="separation_div">  </div>
<div class="checkbox_edit">
<input type="checkbox" class="checkbox_edit" id="chk_edit" name="chk_edit" value="Редактировать" >
<label for="chk_edit">Редактировать</label>
 </div>
         
</div>    


 
<div class="input_1" style="color:grey; border: 0px;"> <?php echo $ver ?></div>

<script>
	//Этот JavaScript код будет искать все элементы input с типом "number" на странице и добавлять обработчик события прокрутки колеса мыши. Когда происходит событие прокрутки, код проверяет, является ли целевой элемент активным (то есть, имеет ли фокус), и если это так, предотвращает стандартное поведение прокрутки. Таким образом, данная функция предотвращает изменение значения поля ввода типа "number" при прокрутке колеса мыши.
    document.querySelectorAll("input[type=number]").forEach(function (element) {
        element.addEventListener("wheel", function(event) {
            if (document.activeElement === event.target) {
                event.preventDefault();
            }
        });
    });
</script>
 

    
</body>
</html>