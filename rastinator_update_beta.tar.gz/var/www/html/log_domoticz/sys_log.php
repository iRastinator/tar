<?php
date_default_timezone_set('Europe/Moscow'); // Установите ваш часовой пояс

$comand = 'tail -n150 /tmp/domoticz.txt | cat -E '; // -E добавляет $ в конец строки
// Разбиваем одну большую строку на массив строк
$arr = explode('$', shell_exec($comand));
$arr = array_reverse($arr);
foreach ($arr as $line) {
    // Получаем текущее время
    $current_time = date("Y-m-d H:i");
    // Получаем временную метку из начала строки
    $log_time = substr($line, 0, 17);
  
    if (strpos($line, 'Error') == true or strpos($line, '!!') == true) {
        // Если строка содержит 'Error', выделяем ее красным цветом
        echo '<span style="color: red;">' . $line . "</span><br>";
    } elseif (strpos($log_time, $current_time) == true) {
        // Если временная метка совпадает с текущим временем, выделяем ее синим цветом
        echo '<span style="color: blue;">' . $line . "</span><br>";
    } else {
        // Остальные строки окрашиваем серым цветом
        echo '<span style="color: grey;">' . $line . "</span><br>";
        
    }
}
?>
