<?php


//Опрос одного датчика 
$info = '';
if(isset($_POST['param1']) and isset($_POST['param2']))
{
	
// оПРОС fLORA
	 if ($_POST['param2'] == 'Flora' )
	 {
				 
			// Регулярное выражение для извлечения IP и MAC
			$pattern = '/((\d{1,3}\.){3}\d{1,3})?\/?([0-9A-Fa-f:]{17}|[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2})/';


			if (preg_match($pattern, $_POST['param1'], $matches)) 
			{
				$ip = isset($matches[1]) ? $matches[1] : '127.0.0.1'; // IP (или 127.0.0.1 если не найден)
				$mac = isset($matches[3]) ? $matches[3] : null; // MAC находится в третьей группе

			} 

			//$stt = ' "'.$mac.'" '.'"-1" "-1" "-1" "-1"';

			if ($ip == '127.0.0.1' or $ip == '')
			{
			 $cmd = 'python3 /home/pi/domoticz/scripts/python/miflora/miflora_test.py '.$mac;
			}
			else
			{
			 //$server_ip = $_SERVER['SERVER_ADDR'];
			 //$cmd = "sudo -u pi sshpass -p 'pass' ssh pi@" .$ip. " 'python3 /home/pi/domoticz/scripts/python/miflora/miflora_s.py ".$server_ip. $stt. " '";
			 $cmd = "sudo -u pi ssh pi@" .$ip. " 'python3 /home/pi/domoticz/scripts/python/miflora/miflora_test.py ".$mac. "'";
			 
			}

		 	 
			echo shell_exec($cmd);
		 			 	
		 	

				 
		 
	 }	
	
// Опрос Mijia
if ($_POST['param2'] == 'Mijia' )	
	{
			// Регулярное выражение для извлечения IP и MAC
			$pattern = '/((\d{1,3}\.){3}\d{1,3})?\/?([0-9A-Fa-f:]{17}|[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2})/';

		if (preg_match($pattern, $_POST['param1'], $matches)) 
			{
				$ip = isset($matches[1]) ? $matches[1] : '127.0.0.1'; // IP (или 127.0.0.1 если не найден)
				$mac = isset($matches[3]) ? $matches[3] : null; // MAC находится в третьей группе

			} 

			
			if ($ip == '127.0.0.1' or $ip == '')
			{
			 //$cmd = 'python3 /home/pi/domoticz/scripts/python/miflora/miflora_test.py '.$mac;
			//$cmd = '/home/pi/bin/mijia '.$_POST['param1'] ;	
			$cmd = "python3 /home/pi/domoticz/scripts/python/mijia/mijia_s.py 127.0.0.1 "  .$mac. ' "-1"';
			
			}
			else
			{
			 //$server_ip = $_SERVER['SERVER_ADDR'];
			 //$cmd = "sudo -u pi sshpass -p 'pass' ssh pi@" .$ip. " 'python3 /home/pi/domoticz/scripts/python/miflora/miflora_s.py ".$server_ip. $stt. " '";
			 $cmd = "sudo -u pi ssh pi@" .$ip. " 'python3 /home/pi/domoticz/scripts/python/mijia/mijia_s.py 127.0.0.1 ".$mac. ' "-1"'."'";
			 
			}	
	
	
	
	
	
	
		//echo $cmd;
		 echo shell_exec($cmd);
		 	
		
	}
	
// оПРОС BLE
	 if ($_POST['param2'] == 'BLE' )
	 {
				 
			// Регулярное выражение для извлечения IP и MAC
			$pattern = '/((\d{1,3}\.){3}\d{1,3})?\/?([0-9A-Fa-f:]{17}|[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2})/';


			if (preg_match($pattern, $_POST['param1'], $matches)) 
			{
				$ip = isset($matches[1]) ? $matches[1] : '127.0.0.1'; // IP (или 127.0.0.1 если не найден)
				$mac = isset($matches[3]) ? $matches[3] : null; // MAC находится в третьей группе

			} 

			

			if ($ip == '127.0.0.1' or $ip == '')
			{
			 $cmd = 'python3 /home/pi/domoticz/scripts/python/ble/ble-yc01_s.py '.$mac;
			}
			else
			{
			 //$server_ip = $_SERVER['SERVER_ADDR'];
			 //$cmd = "sudo -u pi sshpass -p 'pass' ssh pi@" .$ip. " 'python3 /home/pi/domoticz/scripts/python/miflora/miflora_s.py ".$server_ip. $stt. " '";
			 $cmd = "sudo -u pi ssh pi@" .$ip. " 'python3 /home/pi/domoticz/scripts/python/ble/ble-yc01_s.py ".$mac. "'";
			 
			}

		 	 
			echo shell_exec($cmd);
		 			 	
		 	

				 
		 
	 }		
	
	
	
}




?>