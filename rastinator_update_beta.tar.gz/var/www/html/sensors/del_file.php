<style>
	@import "../style.css" screen; /* Стиль для вывода результата на монитор */
    @import "../style.css" print, handheld; /* Стиль для печати и смартфона */

</style>                                    

<div style="Position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);">
	<?php include('../pic/process.svg'); ?> 
</div>

<?php

if(isset($_POST['del'])) {

//Удаление загруженного
	// Проверка - евляется ли удаляемы файл последним файлом такого типа 'set_time_shift_flora', 'set_rate_mijia'
    $file = $_POST['del_file'];   
	// Задайте путь к директории и имя файла
	$directory = '/home/pi/domoticz/scripts/lua'; // ваша директория
	$filePath = $directory . '/' . $file;

	// Проверяем, существует ли файл
	if (!is_file($filePath)) {
		echo "Файл не существует: $filePath\n";
		exit;
	}

	// Строки для поиска
	$searchTerms = ['set_time_shift_flora', 'set_rate_mijia' , 'set_rate_ble'];
	$foundStr = '';

	// Проверяем наличие строк в файле
	foreach ($searchTerms as $term) {
		$output = shell_exec("grep -q '$term' '$filePath' && echo '$term'");
		if ($output) {
			$foundStr = trim($output);
			break; // выходим из цикла, найдя первую подходящую строку
		}
	}

	// Проверяем, найдена ли строка
	if ($foundStr === '') {
		echo "В файле не найдены строки: set_time_shift_flora или set_rate_mijia или set_rate_ble.\n";
		exit;
	}

	// Подсчитываем количество файлов в директории, содержащих $foundStr
	$count = shell_exec("grep -l '$foundStr' $directory/* | wc -l");

	// Проверяем, является ли $file единственным файлом с найденной строкой
	if (trim($count) === '1') {
		$newname = $file; // пердаем фокус на то же файл
		//echo "Файл '$file' является единственным, содержащим строку: '$foundStr'.\n";
	} 
	else 
	{
		//echo "Найдено $count файлов, содержащих строку: '$foundStr'.\n";
		 //Удаление файла
		$comand = 'rm '.$filePath;
		$output = shell_exec($comand);
	}
 
    
}




//$newname = '';

//Отключить скрипт - т.е. переименовать c добавкой off
if(isset($_POST['otkl'])) {
    
    $dir = '/home/pi/domoticz/scripts/lua/';
    $file = $_POST['del_file'];
    
   
  
    //Переименование файла
    if (substr($file,0,4)!='off_'){
       // echo 'Переименование ...'.$dir.$file; echo '<br>';
        $newname = 'off_'.substr($file, 12);
        $comand = ' mv '.$dir.$file.' '.$dir.$newname;
        $output = shell_exec($comand);
        
        //var_dump($_POST); 
        

    }
  
}

//Включить скрипт - т.е. переименовать c без добавки off
if(isset($_POST['vkl'])) {

    $dir = '/home/pi/domoticz/scripts/lua/';
    $file = $_POST['del_file'];   
    if (substr($file,0,4) =='off_'){
        //echo 'Переименование ...'.$dir.$file; echo '<br>';
        //Переименование файла
        $newname = 'script_time_'.substr($file,4, strlen ($file));    
        $comand = ' mv '.$dir.$file.' '.$dir.$newname;
        $output = shell_exec($comand);    
            
    }
  
}















echo 
'
<html>
<body onload="document.frm1.submit()">
   <form action="index.php" name="frm1" method="POST">
      <input type="hidden" name="rast" value='.$newname.' >
   </form>
</body>
</html>

'


?>


