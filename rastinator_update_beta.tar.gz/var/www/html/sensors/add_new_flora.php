<?php



	 
  // Определение крайнего idx датчиков
    $url = 'curl "http://127.0.0.1:8080/json.htm?type=devices&used=true&displayhidden=1" | grep "idx" | tail -1 | grep -oE "[0-9]{1,}"';
    $output = shell_exec($url);
    $id_new_flora = (int)$output + 1;





//Датчики Flora
if (isset($_POST['set_rate_flora']) )
 {

	$name = urlencode($_POST['add_name']).'%20Flora%20' . $id_new_flora .'_'.($id_new_flora+3). '%20-';
 
	

	$words = explode(' ', $_POST['add_name']);

	if(count($words) >= 2 and strpos($_POST['add_name'] , '-')) 
		{
		$name = urlencode($_POST['add_name']).'%20Flora%20' . $id_new_flora .'_'.($id_new_flora+3). '%20';
		} 
	
	
		$st = 'curl "http://127.0.0.1:8080/json.htm?type=command&param=createdevice&idx=2&sensorname='.$name.'%20%D0%92%D0%BB%D0%B0%D0%B6%D0%BD%D0%BE%D1%81%D1%82%D1%8C&sensormappedtype=0xF31F&sensoroptions=1;%25"';
		shell_exec($st);
	
		$st = 'curl "http://127.0.0.1:8080/json.htm?type=command&param=createvirtualsensor&idx=2&sensorname='.$name.'%20%D0%A2%D0%B5%D0%BC%D0%BF%D0%B5%D1%80%D0%B0%D1%82%D1%83%D1%80%D0%B0&sensortype=80"';
		shell_exec($st);
		$st = 'curl "http://127.0.0.1:8080/json.htm?type=command&param=createvirtualsensor&idx=2&sensorname='.$name.'%20%D0%9E%D1%81%D0%B2%D0%B5%D1%89%D0%B5%D0%BD%D0%BD%D0%BE%D1%81%D1%82%D1%8C&sensortype=246"';
		shell_exec($st);    
		$st = 'curl "http://127.0.0.1:8080/json.htm?type=command&param=createdevice&idx=2&sensorname='.$name.'%20EC&sensormappedtype=0xF31F&sensoroptions=1;µS/cm" ';
		shell_exec($st);

	
}

//Датчики Mijia
if (isset($_POST['set_rate_mijia']) )
{
	$name = urlencode($_POST['add_name'].' Mijia '.$id_new_flora.' -'. ' Темп/Влаж');
	
	$words = explode(' ', $_POST['add_name']);
	if(count($words) >= 2 and strpos($_POST['add_name'] , '-')) 
		{
		$name = urlencode($_POST['add_name'].' Mijia '.$id_new_flora. ' Темп/Влаж');
		} 
	
//shell_exec($st);
    $st = 'curl "http://127.0.0.1:8080/json.htm?type=command&param=createvirtualsensor&idx=2&sensorname='.$name.'&sensortype=82"';
    //echo $st; exit();
	shell_exec($st);	
	
	
	
}

if (isset($_POST['set_rate_ble']) )
 {

	$name = urlencode($_POST['add_name']).'%20BLE%20' . $id_new_flora .'_'.($id_new_flora+5). '%20-';
 
	

	$words = explode(' ', $_POST['add_name']);

	if(count($words) >= 2 and strpos($_POST['add_name'] , '-')) 
		{
		$name = urlencode($_POST['add_name']).'%20BLE%20' . $id_new_flora .'_'.($id_new_flora+5);
		} 
		
		//Температура
		$st = 'curl "http://127.0.0.1:8080/json.htm?type=command&param=createvirtualsensor&idx=2&sensorname='.$name.'%20%D0%A2%D0%B5%D0%BC%D0%BF%D0%B5%D1%80%D0%B0%D1%82%D1%83%D1%80%D0%B0&sensortype=80"';
		shell_exec($st);
		// EC
		$st = 'curl "http://127.0.0.1:8080/json.htm?type=command&param=createdevice&idx=2&sensorname='.$name.'%20EC&sensormappedtype=0xF31F&sensoroptions=1;µS/cm"';
		shell_exec($st);
		// ph
		$st = 'curl "http://127.0.0.1:8080/json.htm?type=command&param=createdevice&idx=2&sensorname='.$name.'%20pH&sensormappedtype=0xF31F&sensoroptions=1;%25"';
		shell_exec($st);
		// ORP
		$st = 'curl "http://127.0.0.1:8080/json.htm?type=command&param=createdevice&idx=2&sensorname='.$name.'%20ORP&sensormappedtype=0xF31F&sensoroptions=1;mV"';
		shell_exec($st);
		// Free Chlorine
		$st = 'curl "http://127.0.0.1:8080/json.htm?type=command&param=createdevice&idx=2&sensorname='.$name.'%20Free%20Chlorine&sensormappedtype=0xF31F&sensoroptions=1;ppm"';
		shell_exec($st);
		// TDS
		$st = 'curl "http://127.0.0.1:8080/json.htm?type=command&param=createdevice&idx=2&sensorname='.$name.'%20TDS&sensormappedtype=0xF31F&sensoroptions=1;ppm"';
		shell_exec($st);

	
}


?>
