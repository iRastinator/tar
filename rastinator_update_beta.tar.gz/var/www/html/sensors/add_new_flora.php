<?php
// Получение максимального idx датчиков
$url = 'http://127.0.0.1:8080/json.htm?type=command&param=getdevices';
$json = file_get_contents($url);
$data = json_decode($json, true);

$max_idx = 0;
if ($data && isset($data['result'])) {
    foreach ($data['result'] as $device) {
        if (isset($device['idx']) && $device['idx'] > $max_idx) {
            $max_idx = $device['idx'];
        }
    }
}

$id_new_flora = $max_idx + 1;

// Получение idx оборудования с именем "Device" или "Устройства"
$hardware_url = 'http://127.0.0.1:8080/json.htm?type=command&param=gethardware';
$hardware_json = file_get_contents($hardware_url);
$hardware_data = json_decode($hardware_json, true);

$hardware_idx = 0;
$target_hardware_names = ['Device', 'Устройства'];

if ($hardware_data && isset($hardware_data['result'])) {
    foreach ($hardware_data['result'] as $hardware) {
        if (isset($hardware['Name']) && in_array($hardware['Name'], $target_hardware_names)) {
            $hardware_idx = $hardware['idx'];
            break;
        }
    }
}

// Если оборудование не найдено, используем значение по умолчанию 3
if ($hardware_idx === 0) {
    $hardware_idx = 3;
}

// Функция для выполнения команд
function domoticzCmd($cmd) {
    shell_exec('curl -s "' . $cmd . '" > /dev/null 2>&1 ');
}

// Датчики Flora - используем только виртуальные сенсоры
if (isset($_POST['set_rate_flora'])) {
    $name = urlencode($_POST['add_name']) . '%20Flora%20' . $id_new_flora . '_' . ($id_new_flora+3);
    $name .= (strpos($_POST['add_name'], '-') !== false) ? '%20' : '%20-';
    
    // Влажность (Type: Humidity)
    domoticzCmd('http://127.0.0.1:8080/json.htm?type=command&param=createvirtualsensor&idx='.$hardware_idx.'&sensorname='.$name.'%20%D0%92%D0%BB%D0%B0%D0%B6%D0%BD%D0%BE%D1%81%D1%82%D1%8C&sensortype=81');
    // Температура (Type: Temperature)
    domoticzCmd('http://127.0.0.1:8080/json.htm?type=command&param=createvirtualsensor&idx='.$hardware_idx.'&sensorname='.$name.'%20%D0%A2%D0%B5%D0%BC%D0%BF%D0%B5%D1%80%D0%B0%D1%82%D1%83%D1%80%D0%B0&sensortype=80');
    // Освещенность (Type: Illumination)
    domoticzCmd('http://127.0.0.1:8080/json.htm?type=command&param=createvirtualsensor&idx='.$hardware_idx.'&sensorname='.$name.'%20%D0%9E%D1%81%D0%B2%D0%B5%D1%89%D0%B5%D0%BD%D0%BD%D0%BE%D1%81%D1%82%D1%8C&sensortype=246');
    // EC (Type: Custom Sensor)
    domoticzCmd('http://127.0.0.1:8080/json.htm?type=command&param=createdevice&idx='.$hardware_idx.'&sensorname='.$name.'%20EC&sensormappedtype=0xF31F&sensoroptions=1;uS');
}

if (isset($_POST['set_rate_mijia'])) {
    // Формируем полное имя без кодирования
    $name = $_POST['add_name'] . ' Mijia ' . $id_new_flora;
    $name .= (strpos($_POST['add_name'], '-') !== false) ? ' Темп/Влаж' : ' - Темп/Влаж';
    
    // Кодируем только итоговую строку
    $encoded_name = urlencode($name);
    
    domoticzCmd('http://127.0.0.1:8080/json.htm?type=command&param=createvirtualsensor&idx='.$hardware_idx.'&sensorname=' . $encoded_name . '&sensortype=82');
}

// Датчики BLE - используем виртуальные сенсоры
if (isset($_POST['set_rate_ble'])) {
    $name = urlencode($_POST['add_name']) . '%20BLE%20' . $id_new_flora . '_' . ($id_new_flora+5);
    $name .= (strpos($_POST['add_name'], '-') !== false) ? '' : '%20-';
    
    // Температура
    domoticzCmd('http://127.0.0.1:8080/json.htm?type=command&param=createvirtualsensor&idx='.$hardware_idx.'&sensorname='.$name.'%20%D0%A2%D0%B5%D0%BC%D0%BF%D0%B5%D1%80%D0%B0%D1%82%D1%83%D1%80%D0%B0&sensortype=80');

    // EC (Electrical Conductivity)
    domoticzCmd('http://127.0.0.1:8080/json.htm?type=command&param=createdevice&idx='.$hardware_idx.'&sensorname='.$name.'%20EC&sensormappedtype=0xF31F&sensoroptions=1;uS');

    // pH
    domoticzCmd('http://127.0.0.1:8080/json.htm?type=command&param=createdevice&idx='.$hardware_idx.'&sensorname='.$name.'%20pH&sensormappedtype=0xF31F&sensoroptions=2;pH');

    // ORP
    domoticzCmd('http://127.0.0.1:8080/json.htm?type=command&param=createdevice&idx='.$hardware_idx.'&sensorname='.$name.'%20ORP&sensormappedtype=0xF31F&sensoroptions=0;mV');

    // Free Chlorine
    domoticzCmd('http://127.0.0.1:8080/json.htm?type=command&param=createdevice&idx='.$hardware_idx.'&sensorname='.$name.'%20Free%20Chlorine&sensormappedtype=0xF31F&sensoroptions=2;ppm');

    // TDS
    domoticzCmd('http://127.0.0.1:8080/json.htm?type=command&param=createdevice&idx='.$hardware_idx.'&sensorname='.$name.'%20TDS&sensormappedtype=0xF31F&sensoroptions=0;ppm');
}



?>