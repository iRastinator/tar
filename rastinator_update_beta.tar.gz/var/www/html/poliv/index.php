<!DOCTYPE html>
<html>

<head>
	<meta name = "viewport" content = "width=device-width, initial-scale=1">
	<meta charset="utf-8" />
	<title>Rastinator</title>
	<script type="text/javascript" src="/ajax/jquery-3.7.0.min.js"></script>
	<style>
		@import "../style.css"screen;
		/* Стиль для вывода результата на монитор */


		* {
			padding: 0%;
			margin: 0%;
		}

		.container {
			grid-template-columns: clamp(11rem, 5.909rem + 25.45vw, 25rem) clamp(6.25rem, 2.841rem + 17.05vw, 15.625rem) clamp(2.5rem, -1.136rem + 18.18vw, 12.5rem) auto;
			display: grid;
		}

		.item {

			padding: 0px;
			border: 0px solid black;

		}

		.item_1 {
			grid-column-start: 1;
			grid-column-end: 5;
		}

		.item_2 {
			grid-column-start: 1;
			grid-column-end: 5;
		}

		.item_4 {
			grid-row-start: 3;

			grid-column-start: 1;
			grid-column-end: 5;
		}

		.item_3 {

			grid-row-start: 4;
			grid-row-end: 150;
			padding-top: 3px;
			padding-right: 1px;
		}

		.zatichka {
			grid-row-start: 150;
			grid-row-end: 150;

		}

		@media (max-width: 1000px) {
			.container {
				grid-template-columns: 0px clamp(8rem, 6.857rem + 12.19vw, 16rem) clamp(4rem, 2.714rem + 13.71vw, 13rem) auto;
				display: grid;
			}

			.zatichka {
				grid-row-start: 5;
				grid-row-end: 150;

			}

			.item_3 {
				grid-row-start: 4;
				grid-row-end: 4;
				grid-column-start: 1;
				grid-column-end: 5;
				padding-top: 3px;
				padding-right: 1px;
				display: flex;
			}




		}

	</style>


</head>

<body>



	<?php
//Авторизация
include('../login/in.php');    
    
function debug_to_console($data) {
    $output = $data;
    if (is_array($output))
        $output = implode(',', $output);
    echo "<script>console.log('Debug Objects: " . $output . "' );</script>";
}    
?>



	<div class="container">
		<div class="zatichka"></div>

		<!-- Верхнее меню -->
		<div class="item item_1">
			<ul>
				<li><svg width="clamp(6.25rem, 3.977rem + 11.36vw, 12.5rem)" height="clamp(1rem, 0.786rem + 2.29vw, 2.5rem)" viewBox="150 -30 180 180"> <?php include('../pic/Rastinator.svg'); ?> </svg> </li>
				<li><a class="active">Полив</a></li>
				<li><a href="../climat/index.php">Климат</a></li>
				<li><a href="../sensors/index.php">Датчики</a></li>
				<li><a href="../settings/index.php">Настройки</a></li>
				<li><a href="../plant_profiles/index.php">Профили</a></li>
				<li><a href="../log_poliva/index.php">Журнал полива</a></li>
				<li><a href="../log_domoticz/index.php">Лог системы</a></li>
			</ul>



		</div>

		<!-- Информационная панель - отображение данных лога -->
		<div class="item item_2">
			<script type="text/javascript">
				$(document).ready(function() {
					var updateInfo = function() {
						$.ajax({
							url: '../log/log.php',
							cache: false, // Предотвращаем кэширование запроса
							success: function(response) {
								var trimmedResponse = response.trim();
								// Проверка наличия времени в формате HH:MM
								if (/(\b[01]?[0-9]:[0-5][0-9]\b|\b2[0-3]:[0-5][0-9]\b)/.test(trimmedResponse)) {
									$("#info").css("color", ""); // Сброс цвета
									$(".info_climat").css("color", ""); // Сброс цвета для классов
									$("#info").html(trimmedResponse); // Обновление содержимого
								} else {
									$("#info").css("color", "gray"); // Окрашивание в серый цвет
									$(".info_climat").css("color", "gray"); // Окрашивание в серый цвет для классов
									// Не обновляем содержимое
								}
							},
							error: function() {
								console.error("Ошибка при загрузке данных из log.php");
							}
						});
					};

					var updateInfoBar = function() {
						$("#info_bar").load('../log/log_bar.php');
					};

					setInterval(updateInfo, 2000);
					setInterval(updateInfoBar, 2000);
				});
			</script>

			<div id="info_bar">
				<?php include('../log/log_bar.php'); ?>
			</div>

			<div id="info">
				<?php include('../log/log.php'); ?>
			</div>
		</div>











		<!-- Select с названиями файлов -->
		<div class="item item_3">



			<form id="myform" method="POST" action="index.php">




				<?php  // Заполнение Селекта названиями


    $var = $_POST['rast'];   

    $path = "/home/pi/domoticz/scripts/lua/";

    $des = '';

    $files = glob($path . "*plant*");
	$x = count($files)+2;

    $temp_m = array(); // Массив для скриптов полива
    $temp_add = array(); // Массив для сервисных скриптов   
    $temp_add2 = array(); // Массив для отключенных скриптов

    if($handle = opendir($path))
        {
             $count = 0;

             function to_min($seconds) {
             $t = round($seconds);
             //return sprintf('%02d:%02d:%02d', ($t/3600),($t/60%60), $t%60);
             return sprintf('%02d:%02d', ($t/60), $t%60);
             }


        // Загрузка имен файлов в массив где ключи это  set_Shift_time_watering в этом файле, далее сортирровка по Сдвигу по времени(et_Shift_time_watering) 

        while($entry = readdir($handle))
             {

                if ( substr($entry , 0 , 17) == 'script_time_plant' )
                  {
                    //grep ^set_Shift_time_watering script_time_plant_.lua | grep -o '[0-9]*'
                    $comand = "grep ^set_Shift_time_watering ".$path.$entry." | grep -o '[0-9]*'";
                    $output = shell_exec($comand);
                    $output = trim($output);  

                   //grep -Po '^sets_Canal_out\s+=\s+"\K[^"]+' script_time_plant_.lua
                    $comand = " grep -Po '^sets_Canal_out\s+=\s+".'"'.'\K[^"]+'."'".'   '.$path.$entry;
                    $output2 = shell_exec($comand);
                    $output2 = trim($output2);
                    // Если сервисный режим    
                    if ($output2 !=='') 
                          {$temp_add[$entry] = $output;}
                     else { $temp_m[$entry] = $output; }   


                    }

                    if ( substr($entry , 0 , 9) == 'off_plant' )
                       {
                        $temp_add2[$entry] = $output;
                        }


            }
        $sep1['----1'] = "----1"; 
        $sep2['----2'] = "----2"; 
        asort($temp_m); 
        asort($temp_add);

        if (empty($temp_add)==false and empty($temp_m)==false ){$temp_m = array_merge($temp_m, $sep1 );}
        $temp_m = array_merge($temp_m, $temp_add );
        if (empty($temp_add2)==false and empty($temp_m)==false){$temp_m = array_merge($temp_m, $sep2 );}
        $temp_m = array_merge($temp_m, $temp_add2 );

        //var_dump($temp_m);

    echo'<select  class="main" size="'.$x.'" name="rast" id="select_rast" onchange="this.form.submit()";>'; 


        foreach ($temp_m as  $entry => $value)
         {
                if ( substr($entry , 0 , 4) == '----')
                {
                 echo '<option style="color:lightgray" disabled>─────────────────────────────────────────────────────</option>';
                }   



                if ( substr($entry , 0 , 17) == 'script_time_plant')
                {


                    $count = $count + 1;
                     //echo "<a href=action.php?var=$entry >$entry</a><br>";
                    $name = substr($entry , 18 , -4);
					// Заменяем _ на пробелы для отображения
					$name = str_replace('_', ' ', $name);

                          //grep -Po '^sets_Canal\s+=\s+"\K[^"]+' script_time_plant_.lua
                            $comand = " grep -Po '^sets_Canal\s+=\s+".'"'.'\K[^"]+'."'".'   '.$path.$entry;
                            $output = shell_exec($comand);
                            $output = trim($output);
                            // 
                            //$output = str_repeat('&nbsp;', 24- iconv_strlen($name)).$output;

                        //grep ^set_Shift_time_watering script_time_plant_.lua | grep -o '[0-9]*'
                            $comand = "grep ^set_Shift_time_watering ".$path.$entry." | grep -o '[0-9]*'";
                            $output2 = shell_exec($comand);
                            $output2 = trim($output2);

                        //grep ^set_Time_fertilize script_time_plant_.lua | grep -o '[0-9]*'
                            $comand = "grep ^set_Time_fertilize ".$path.$entry." | grep -o '[0-9]*'";
                            $output3 = shell_exec($comand);
                            $output3 = trim($output3);

                        //grep ^set_Time_clear_water script_time_plant_.lua | grep -o '[0-9]*'
                            $comand = "grep ^set_Time_clear_water ".$path.$entry." | grep -o '[0-9]*'";
                            $output4 = shell_exec($comand);
                            $output4 = trim($output4);

                        //grep ^set_set_Quota script_time_plant_.lua | grep -o '[0-9]*'
                            $comand = "grep ^set_Quota ".$path.$entry." | grep -o '[0-9]*'";
                            $output5 = shell_exec($comand);
                            $output5 = trim($output5);


                          //Время полного полива
                        $output4= $output2*60 + ($output3+$output4)*$output5;
                        // Длина времени 
                        $len_str = iconv_strlen(to_min($output2*60).'-'.to_min($output4));

                        // Tc
                        $output = str_repeat('&nbsp;', 35 - ($len_str + iconv_strlen($name))).$output;

                        //grep -Po '^sets_Canal_out\s+=\s+"\K[^"]+' script_time_plant_.lua
                            $comand = " grep -Po '^sets_Canal_out\s+=\s+".'"'.'\K[^"]+'."'".'   '.$path.$entry;
                            $output6 = shell_exec($comand);
                            $output6 = trim($output6);
                    // Если включен сервисный режим
                            if ($output6 !=='') 
                            {
                                //grep ^set_Time_drain script_time_plant_.lua | grep -o '[0-9]*'
                                $comand = "grep ^set_Time_drain ".$path.$entry." | grep -o '[0-9]*'";
                                $output4 = shell_exec($comand);
                                $output4 = trim($output4);
                                $output4 = $output4 + $output2*60;

                                $output = str_repeat('&nbsp;', 30 - ($len_str + iconv_strlen($name))).'Слив:'.$output6;

                            }
						
					

                    // Если список грузится первый раз - выбор первого элемента 
                    if ($var == null and $count == 1) { 
                        echo '<option selected value='.$entry.'>'.to_min($output2*60).'-'.to_min($output4).'&nbsp;'.$name.$output.'</option>';}

                    // Если список грузится первый раз - загрузка последующих элементов
                    if ($var == null and $count !== 1) {                      
                        echo '<option  value='.$entry.'>'.to_min($output2*60).'-'.to_min($output4).'&nbsp;'.$name.$output.'</option>';}


                    // Если список грузится не первый раз - выбор загружаемого элемента
                    if ($var == $entry)   
                       { 
                        echo '<option selected value='.$entry.'>'.to_min($output2*60).'-'.to_min($output4).'&nbsp;'.$name.$output.'</option>';}

                    // Если список грузится не первый раз - загрузка последующих элементов  
                    elseif ($var !== null and $var !=='') 
                     {                      
                        echo '<option  value='.$entry.'>'.to_min($output2*60).'-'.to_min($output4).'&nbsp;'.$name.$output.'</option>';}




                  }

             //Отключенные скрипты 
            if ( substr($entry , 0 , 9) == 'off_plant')
                 {

                        $count = $count + 1;
                        $name = substr($entry , 10 , -4); 
						// Заменяем _ на пробелы для отображения
						$name = str_replace('_', ' ', $name);
                        $len = strlen(trim($name));

                        // Если список грузится первый раз - выбор первого элемента 
                        if ($var == null and $count == 1) 
                        { echo '<option style="color:gray" selected value='.$entry.'>'.$name.' - Отключен</option>';}

                        // Если список грузится первый раз - загрузка последующих элементов
                        if ($var == null and $count !== 1)
                        { echo '<option style="color:gray" value='.$entry.'>'.$name.' - Отключен</option>'; }

                        // Если список грузится не первый раз - выбор загружаемого элемента
                        if ($var == $entry)   
                        { echo '<option style="color:gray" selected value='.$entry.'>'.$name.' - Отключен</option>';}

                        // Если список грузится первый раз - загрузка последующих элементов  
                        elseif ($var !== null and $var !=='') 
                         { echo '<option style="color:gray" value='.$entry.'>'.$name.' - Отключен</option>';} 



                  }




          }



            // Маркер для кнопки удалить - отключает кнопку если последний элемент
            if ($count == 1) {$des = 'disabled';} 


        }closedir($handle);


	
				
				
				
     ?>

				</select>
				<script>
					var select = document.getElementById("select_rast");

						/* Выделение опций селекта по совподающим каналам    
						var optionGroups = {};

						for (var i = 0; i < select.options.length; i++) {
							var option = select.options[i];
							var regex = /ch(\d-\d)/;
							var substring = option.textContent.match(regex);

							if (substring) {
								var key = substring[1];

								if (key in optionGroups) {
									optionGroups[key].push(option);
								} else {
									optionGroups[key] = [option];
								}
							}
						}

						for (var key in optionGroups) {
							var options = optionGroups[key];

							if (options.length > 1) {
								options.forEach(function(option) {
									option.classList.add("red");
								});
							}
						}
						*/
					

					// Выделение опций селекта по совподающему времени
					var options = select.options;

					for (var i = 0; i < options.length - 1; i++) {
						var currentOption = options[i];
						var nextOption = options[i + 1];

						var currentText = currentOption.textContent;
						var nextText = nextOption.textContent;

						var currentNumbersMatch = currentText.match(/\d+:\d+-\d+:\d+/);
						var nextNumbersMatch = nextText.match(/\d+:\d+-\d+:\d+/);

						if (currentNumbersMatch && nextNumbersMatch) {
							var currentNumbers = currentNumbersMatch[0].split("-");
							var nextNumbers = nextNumbersMatch[0].split("-");

							var currentNumberA = parseInt(currentNumbers[0].replace(":", ""));
							var currentNumberC = parseInt(currentNumbers[1].replace(":", ""));
							var nextNumberA = parseInt(nextNumbers[0].replace(":", ""));
							var nextNumberB = parseInt(nextNumbers[1].replace(":", ""));

							if (currentNumberC > nextNumberA || (currentNumberC === nextNumberA && currentNumberD >= nextNumberB)) {
								currentOption.classList.add("red");
								nextOption.classList.add("red");
								
							}
						}
					}

				</script>
			</form>



		<!-- Информация о каналах в работе -->
		<div class="div_chanals">
			<div class="div_chanals_header">
				Используемые каналы:
			</div>
			<div class="div_ch">
				<?php   
				$comand = "grep -E -h -o 'ch[0-9]-[0-9]' /home/pi/domoticz/scripts/lua/script_* | sort"; 
				$string = shell_exec($comand);
				$string = trim($string);
				$elements = explode("\n", $string); // Разбиваем строку на элементы
				$result = [];

				// Подсчет вхождений каждой уникальной записи с группировкой по X
				foreach ($elements as $element) {
					$element = trim($element);
					if (!empty($element)) {
						preg_match('/ch(\d+)-(\d+)/', $element, $matches); // Извлекаем X и Y
						if (isset($matches[1])) {
							$x = $matches[1]; // Значение X
							$y = $matches[2]; // Значение Y

							// Инициализируем массив для X, если его нет еще
							if (!isset($result[$x])) {
								$result[$x] = [];
							}

							// Увеличиваем счетчик для конкретного элемента
							if (!isset($result[$x][$element])) {
								$result[$x][$element] = 0; // Инициализируем счетчик для элемента
							}
							$result[$x][$element]++; // Увеличиваем счетчик
						}
					}
				}

				// Выводим результаты
				foreach ($result as $x => $values) {
					$outputLine = []; // Массив для формирования строки вывода
					foreach ($values as $element => $count) {
						// Форматируем каждую запись
						if ($count == 1) {
							$outputLine[] = "{$element}"; // Не добавляем (N) если count = 1
						} else {
							// Добавляем с (N) для остальных, выделяя красным цветом
							$outputLine[] = "<span style=\"color:red;\">{$element}({$count})</span>"; 
						}
					}
					$finalOutput = implode(" ", $outputLine); // Объединяем с пробелами
					echo "{$finalOutput}<div style=\"height: 3px;\"></div>"; // Выводим элементы на одной строке
				}
				?>
			</div>
		</div>
		<!---- ---->


		</div>

		<!-- item item_4 - Кнопки включить отключить удалить Запустить остановить -  ---------->
		<div class="item item_4">


			<div class="btn-group">
				<form id="delform" method="POST" action="del_file.php">

					<button class="button" name="del" value="" type="submit" onclick="return confirm('Вы уверены, что хотите Удалить Профиль Растения? ?')" <?php echo $des; ?>>Удалить</button>

					<button class="button" name="otkl" value="" type="submit">Отключить</button>

					<button class="button" name="vkl" value="" type="submit">Включить</button>


					<?php  //Кнопки Удалить Отключить Включить

        $file = $_POST['rast'];  

        // Определяем файл для загрузки если в первый раз
        if ($file == '')
        {

            $path = "/home/pi/domoticz/scripts/lua/";
                    // определение первого файла в директории                                       
                    if ($file == null) // Если список грузится первый раз - определения первого файла в директории 
                    {$file = array_key_first($temp_m); }

            echo '<input  name="del_file"  value='.$file.' type="hidden" >'; //type="hidden"
        }                                           
        else 
        {
            echo '<input  name="del_file"  value='.$file.' type="hidden" >';//type="hidden"

        }      

        ?>

				</form>






<form id="myform2" method="POST" action="save_file.php">


	<?php  // 

        //var_dump($_POST); echo '</br>';
        //exit();    

        $var = $_POST['rast'];
        $set = $_POST['set'];

        $path = "/home/pi/domoticz/scripts/lua/";

        // Если список грузится первый раз - определения первого файла в директории                                            
        if ($var == null) 
        {$var = array_key_first($temp_m); }


        if ($set !== null) { $var = $set; } 

        $filename = $path.''.$var;
        $Name = '';
        $flag = 'false';

        //Название растения - если с OFF - имя длиннее на 4 сивола
        if (substr($var, 0,4) ==  "off_"){
            $Name =  substr($var , 10 , strlen(trim($var))-14);
            $flag = 'disabled';
            }
        else{
            $Name =  substr($var , 18 , strlen(trim($var))-22);  }



    
       echo '<input class="button" type="submit" name="run_script" value="Запустить полив" '.$flag.'>';
       echo '<input class="button" type="submit" name="stop_script" value="Остановить полив" '.$flag.'>';
       echo '<input class="button" type="submit" name="new_porfile" value="Сохранить новый профиль">';   
       echo '<input class="button" type="submit" name="save_changes" value="Сохранить изменения">';

    
        echo '</div>'; 
        
        ?>
					<div class="separation_div"> </div>


			</div>


			<!-- Отображение загруженных настроек в инпуты ---------->
<!---- Создаем SELECT с профилями питания --->
	<?php

	// Путь к директории с файлами
	$directory = '/home/pi/domoticz/scripts/lua/plant_profiles';

	// Инициализируем ассоциативный массив для хранения информации
	$profiles = [];

	// Получаем список всех файлов в директории
	$files = scandir($directory);

	foreach ($files as $file) {
		// Проверяем, является ли файл обычным файлом и не является ли он специальным
		if ($file !== '.' && $file !== '..' && is_file($directory . '/' . $file)) {
			// Открываем файл для чтения
			$content = file($directory . '/' . $file);

			$currentColor = null;
			$linesToStore = [];

			foreach ($content as $line) {
				$line = trim($line);

				// Ищем секцию info:
				if (strpos($line, 'info:') === 0) {
					// Если есть ранее собранный набор данных, сохраняем его
					if ($currentColor !== null && count($linesToStore) > 0) {
						// Sохраняем только нужную часть строк с удаленным префиксом rast_
						$key = str_replace(['rast_', '_'], ['', ' '], $file); // Удаляем префикс rast_ и заменяем "_" на пробелы
						$profiles["$key - $currentColor"] = $linesToStore;
					}

					// Устанавливаем новый цвет и очищаем старые строки
					$currentColor = trim (substr($line , strpos($line , "info:")+5, strpos($line , "info<") - strpos($line , "info:")-5)); 
					$linesToStore = [];
				} else {
					// Обрабатываем строки и собираем только до 'info<' включительно
					$infoPos = strpos($line, 'info<');

					if ($infoPos !== false) {
						// Если значение 'info<' найдено, сохраняем подстроку
						$linesToStore[] = substr($line, 0, $infoPos);
					} else {
						// Если 'info<' нет, сохраняем всю строку
						$linesToStore[] = $line;
					}
				}
			}

			// Сохраняем последний набор данных, если он есть
			if ($currentColor !== null && count($linesToStore) > 0) {
				$key = str_replace(['rast_', '_'], ['', ' '], $file); // Удаляем префикс rast_ и заменяем "_" на пробелы
				$profiles["$key - $currentColor"] = $linesToStore;
			}
		}
	}

	// Генерируем HTML-код для элемента <select>
	?>


			<script>
	function showInfo(value) {
		//console.log("Selected value:", value); // Проверка выбранного значения

		// Если значение пустое (например, первая позиция в селекте), ничего не делаем
		if (value === "") {
			return; // Выходим из функции
		}

		// Очищаем инпуты перед заполнением
		for (let i = 1; i <= 7; i++) {
			document.getElementById('setm_Pump_' + i + '_info').value = '';
			document.getElementById('setm_Pump_' + i).value = '';
		}

		// Разбиваем значение на строки
		const lines = value.split('\n');
		//console.log("Lines split:", lines); // Проверка разбитых строк

		lines.forEach((line, index) => {
			const regexLabel = /label<([^<>]*)?>/;// Регулярное выражение для извлечения текста между label<>
			const regexPumpValue = /label<[^<>]*>\s*label\s*(\d+(\.\d+)?)/; // Измененное регулярное выражение

			// Извлекаем значения
			const matchLabel = regexLabel.exec(line);
			const matchPumpValue = regexPumpValue.exec(line);

			//console.log("Текст:", matchLabel); // Проверка найденного значения label
			//console.log("Match pump value:", matchPumpValue); // Проверка найденного значения для setm_Pump_N

			// Проверяем, что индекс меньше 7 (избежать переполнения)
			if (index < 7) {
				// Заполняем инпуты для значений
				if (matchLabel && matchLabel[1]) { // Проверяем, есть ли совпадение и значение
						const labelValue = matchLabel[1].trim(); // Содержимое между label<>
						const pumpInfoValue = labelValue + " (" + line.split(' ')[0] + " гр/л)"; // Задаем значение для info
						document.getElementById('setm_Pump_' + (index + 1) + '_info').value = pumpInfoValue; // Заполняем инпут
					}

				if (matchPumpValue) {
					const pumpValue = matchPumpValue[1]; // Извлекаем значение из конца строки
					document.getElementById('setm_Pump_' + (index + 1)).value = pumpValue; // Заполняем инпут
					//console.log("Filling setm_Pump_" + (index + 1) + " with:", pumpValue);
				} else {
					//console.log("No pump value found in line:", line); // Сообщение об отсутствии совпадений
				}
			}
		});

		// Здесь может быть код для отображения информации, если он нужен
	}


	</script>
	<!--- <div id="infoDisplay"></div>  --->

<!---- конец SELECT с профилями питания --->

    	
			<!-- Кнопки выбора режимов ---------->
			<input class="input_1" value="Режим рабрты" readonly>

			<div class="div_mode">
				<input class="button_cell" name="schedule_watering" value="Полив по расписанию">
				<input class="button_cell" name="sensor_watering" value="Полив по датчику">
				<input class="button_cell" name="service_drain" value="Режим слива">
				
				
				<select class="input_2_light" name="plant_profiles" id="plant_profiles" onchange="showInfo(this.value)">
			<option value="">Загрузить профили питания</option> <!-- Заполнитель -->
			<?php foreach ($profiles as $key => $value): ?>
				<option value="<?= htmlspecialchars(implode("\n", $value)) ?>"><?= htmlspecialchars($key) ?></option>
			<?php endforeach; ?>
		</select>
			</div>

			<script>
				// Режим по расписанию
				document.querySelector('.button_cell[name="schedule_watering"]').addEventListener('click', function() {
					if (confirm('Переключение на режим "Полив по расписанию". Проверте установки после переключения на новый режим!')) {
						document.querySelector('[name="setm_Hour_watering"]').value = "-1";
						document.querySelector('[name="setm_Sens_id"]').value = "";
						document.querySelector('[name="sets_Canal_out"]').value = "";
						document.querySelector('[name="save_changes"]').click();
					}
				});

				document.querySelector('.button_cell[name="sensor_watering"]').addEventListener('click', function() {
					if (confirm('Переключение на режим "Полив по датчику влажности". Проверте установки после переключения на новый режим!')) {
						document.querySelector('[name="sets_Canal_out"]').value = "";
						document.querySelector('[name="setm_Hour_watering"]').value = "";
						document.querySelector('[name="save_changes"]').click();
					 }
				});

				document.querySelector('.button_cell[name="service_drain"]').addEventListener('click', function() {
					if (confirm('Переключение на "Режим cлива"! Проверте установки после переключения на новый режим!')) {
						document.querySelector('[name="sets_Canal"]').value = "";
						document.querySelector('[name="sets_m_valve"]').value = "";
						document.querySelector('[name="sets_Canal_out"]').value = "ch";
						document.querySelector('[name="save_changes"]').click();
						
					}
				});

				
				
				//При загрузке страницы убираем инпуты для других режим
				document.addEventListener('DOMContentLoaded', function() {
				  var setm_Sens_id = document.querySelector('[name="setm_Sens_id"]').value;
				  var sets_Canal_out = document.querySelector('[name="sets_Canal_out"]').value;
				  var setm_Hour_watering = document.querySelector('[name="setm_Hour_watering"]').value;
					
					// Режим по датчикам влажности
					if (setm_Hour_watering === "" && sets_Canal_out === ''){
						//document.querySelector('[name="sets_Canal"]').style.backgroundColor = '#f0f0f0';
						//document.querySelector('[name="setm_Sens_id"]').style.backgroundColor = '#f0f0f0';
						document.querySelector('[name="sensor_watering"]').style.backgroundColor = 'cadetblue';
						document.querySelector('[name="sensor_watering"]').disabled = true;
						
						document.querySelector('[name="label_setm_Hour_watering"]').style.display = 'none';
						document.querySelector('[name="setm_Hour_watering"]').style.display = 'none';
						document.querySelector('[name="info_setm_Hour_watering"]').style.display = 'none';

							//Канал слива
						document.querySelector('[name="label_sets_Canal_out"]').style.display = 'none';
						document.querySelector('[name="sets_Canal_out"]').style.display = 'none';
						document.querySelector('[name="info_sets_Canal_out"]').style.display = 'none';
						// set_proba_max_ec
						document.querySelector('[name="label_set_proba_max_ec"]').style.display = 'none';
						document.querySelector('[name="set_proba_max_ec"]').style.display = 'none';
						document.querySelector('[name="info_set_proba_max_ec"]').style.display = 'none';
						// set_proba_min_ec
						document.querySelector('[name="label_set_proba_min_ec"]').style.display = 'none';
						document.querySelector('[name="set_proba_min_ec"]').style.display = 'none';
						document.querySelector('[name="info_set_proba_min_ec"]').style.display = 'none';
							//Время слива
						document.querySelector('[name="label_set_Time_drain"]').style.display = 'none';
						document.querySelector('[name="set_Time_drain"]').style.display = 'none';
						document.querySelector('[name="info_set_Time_drain"]').style.display = 'none';
							//ID Датчики слива
						document.querySelector('[name="label_setm_Sens_out_id"]').style.display = 'none';
						document.querySelector('[name="setm_Sens_out_id"]').style.display = 'none';
						document.querySelector('[name="info_setm_Sens_out_id"]').style.display = 'none'; 
							
						//Задержка полива - для режима по расписанию
						document.querySelector('[name="label_set_Delay"]').style.display = 'none';
						document.querySelector('[name="set_Delay"]').style.display = 'none';
						document.querySelector('[name="info_set_Delay"]').style.display = 'none'; 
			

						
						}
					
				   // Режим по расписанию
					if (setm_Hour_watering !== "" && sets_Canal_out === '') { 
						document.querySelector('[name="schedule_watering"]').style.backgroundColor = 'cadetblue';
						document.querySelector('[name="schedule_watering"]').disabled = true;
						document.querySelector('[name="setm_Hour_watering"]').style.backgroundColor = '#f0f0f0';
						//document.querySelector('[name="sets_Canal"]').style.backgroundColor = '#f0f0f0';

						// Датчики влажности ID  
						document.querySelector('[name="label_setm_Sens_id"]').style.display = 'none';
						document.querySelector('[name="setm_Sens_id"]').style.display = 'none';
						document.querySelector('[name="info_setm_Sens_id"]').style.display = 'none';
						  //Уровень влажности полива
						document.querySelector('[name="label_set_Water_level"]').style.display = 'none';
						document.querySelector('[name="set_Water_level"]').style.display = 'none';
						document.querySelector('[name="info_set_Water_level"]').style.display = 'none'; 
						 //Период полива по датчикам 				  
						document.querySelector('[name="label_set_Period"]').style.display = 'none';
						document.querySelector('[name="set_Period"]').style.display = 'none';
						document.querySelector('[name="info_set_Period"]').style.display = 'none';


						//Канал слива
						document.querySelector('[name="label_sets_Canal_out"]').style.display = 'none';
						document.querySelector('[name="sets_Canal_out"]').style.display = 'none';
						document.querySelector('[name="info_sets_Canal_out"]').style.display = 'none';
							//Время слива
						document.querySelector('[name="label_set_Time_drain"]').style.display = 'none';
						document.querySelector('[name="set_Time_drain"]').style.display = 'none';
						document.querySelector('[name="info_set_Time_drain"]').style.display = 'none';
							//ID Датчики слива
						document.querySelector('[name="label_setm_Sens_out_id"]').style.display = 'none';
						document.querySelector('[name="setm_Sens_out_id"]').style.display = 'none';
						document.querySelector('[name="info_setm_Sens_out_id"]').style.display = 'none';  
						// set_proba_max_ec
						document.querySelector('[name="label_set_proba_max_ec"]').style.display = 'none';
						document.querySelector('[name="set_proba_max_ec"]').style.display = 'none';
						document.querySelector('[name="info_set_proba_max_ec"]').style.display = 'none';
						// set_proba_min_ec
						document.querySelector('[name="label_set_proba_min_ec"]').style.display = 'none';
						document.querySelector('[name="set_proba_min_ec"]').style.display = 'none';
						document.querySelector('[name="info_set_proba_min_ec"]').style.display = 'none';
						
						// Начальная температура коректировки
						document.querySelector('[name="label_set_Temp_set"]').style.display = 'none';
						document.querySelector('[name="set_Temp_set"]').style.display = 'none';
						document.querySelector('[name="info_set_Temp_set"]').style.display = 'none';  
						
						// Температурный Коэффициент
						document.querySelector('[name="label_set_Temp_corection"]').style.display = 'none';
						document.querySelector('[name="set_Temp_corection"]').style.display = 'none';
						document.querySelector('[name="info_set_Temp_corection"]').style.display = 'none';
						// Температура прекращения полива
						document.querySelector('[name="label_set_Temp_stop_watering"]').style.display = 'none';
						document.querySelector('[name="set_Temp_stop_watering"]').style.display = 'none';
						document.querySelector('[name="info_set_Temp_stop_watering"]').style.display = 'none';
						// Нижний уровень влажности
						document.querySelector('[name="label_set_Alarm_level_low"]').style.display = 'none';
						document.querySelector('[name="set_Alarm_level_low"]').style.display = 'none';
						document.querySelector('[name="info_set_Alarm_level_low"]').style.display = 'none';
						// Верхний уровень влажности
						document.querySelector('[name="label_set_Alarm_level_high"]').style.display = 'none';
						document.querySelector('[name="set_Alarm_level_high"]').style.display = 'none';
						document.querySelector('[name="info_set_Alarm_level_high"]').style.display = 'none';	
						// Время работы
						document.querySelector('[name="label_set_start_time_watering"]').style.display = 'none';
						document.querySelector('[name="set_start_time_watering"]').style.display = 'none';
						document.querySelector('[name="info_set_start_time_watering"]').style.display = 'none';  
						document.querySelector('[name="label_set_stop_time_watering"]').style.display = 'none';
						document.querySelector('[name="set_stop_time_watering"]').style.display = 'none';
						document.querySelector('[name="info_set_stop_time_watering"]').style.display = 'none';  
						//Сепараторы
						document.querySelector('[name="div_separation35"]').style.display = 'none';
						document.querySelector('[name="div_separation39"]').style.display = 'none';
						document.querySelector('[name="div_separation46"]').style.display = 'none';
						document.querySelector('[name="div_separation49"]').style.display = 'none';
					  
				    }
					
				// Если режим слива	
				if (sets_Canal_out !== ""){
					document.querySelector('[name="sets_Canal_out"]').style.backgroundColor = '#f0f0f0';
					document.querySelector('[name="service_drain"]').style.backgroundColor = 'cadetblue';
					document.querySelector('[name="service_drain"]').disabled = true;
					
				}	
					
					
				});

			</script>

			<div class="separation_div"> </div>
		
		
		
		
		

     
     
      
        
            
       
       

       <!----- Информация - имя файла при загрузке  ----->
       <input  name="origen_file"  value='<?php echo $filename; ?>' type="hidden" >
                                                
       <input readonly class="input_1"  value="Растение или зона полива">                 
      

		<!----- Скрытое поле для  имени без пробелов  ----->
		<input class="input_2" name="Name_unit" id="Name_unit" type="hidden" value="<?php echo $Name; ?>" title="Уникальное название!" autocomplete="off" onkeydown="if(event.keyCode==13){return false;}" >
		<!----- поле для отображении имени без _  ----->
		<input class="input_2" name="Name_unit_show" id="Name_unit_show" type="text" value="<?php echo str_replace('_', ' ', $Name); ?>" title="Уникальное название!" autocomplete="off" onkeydown="if(event.keyCode==13){return false;}" >

		<script>
			// Получаем доступ к полям
			const nameUnitInput = document.getElementById('Name_unit');
			const nameUnitShowInput = document.getElementById('Name_unit_show');

			// Добавляем обработчик события input
			nameUnitShowInput.addEventListener('input', function() {
				let inputValue = nameUnitShowInput.value;

				// Убираем все пробелы в конце строки
				inputValue = inputValue.replace(/\s+$/, ''); // Заменяем пробелы в конце строки

				// Заменяем все пробелы на "_" и обновляем скрытое поле
				nameUnitInput.value = inputValue.replace(/ /g, '_');
			});
		</script>




		
	
		<script>
			// Получаем элемент поля ввода по его ID
			const inputField = document.getElementById('Name_unit_show');

			// Обработчик события, выполняемый при нажатии клавиши
			inputField.addEventListener("keydown", function() {
				this.style.backgroundColor = "#B0F0B0"; // Изменение цвета фона на светло-зеленый
				this.style.color = "black"; // Изменение цвета текста на черный
			});

			// Обработчик события ввода, который фильтрует вводимые данные
			inputField.addEventListener('input', (event) => {
				const inputValue = event.target.value; // Получаем текущее значение поля

				// Регулярное выражение для допустимых символов (буквы, цифры, пробелы и дефисы)
				const allowedInput = /^[A-Za-zА-Яа-я0-9 -]+$/;

				// Если введенные символы не соответствуют разрешенным, удаляем их
				if (!allowedInput.test(inputValue)) {
					event.target.value = inputValue.replace(/[^A-Za-zА-Яа-я0-9 -]/g, ''); // Удаляем недопустимые символы
				}
			});

			// Дополнительно: сбросим цвет поля, когда оно теряет фокус
			inputField.addEventListener('blur', function() {
				this.style.backgroundColor = ""; // Сбрасываем цвет фона
				this.style.color = ""; // Сбрасываем цвет текста
			});
		</script>



			
           
           
<?php           
            
        $file = fopen($filename, 'r');
    
    
    
        // Если сервисный режим и sets_Canal_out ="чемуто"
            $serv_mode = '';
            $contents = file_get_contents($filename); // Укажите здесь имя своего файла
            preg_match('/sets_Canal_out\s*=\s"([^"]*)"/', $contents, $matches);

            if (isset($matches[1]) && $matches[1] != '') {
                // Ваши действия здесь. Этот блок кода выполнится, если кавычки содержат ненулевое значение
                $serv_mode = 'type="hidden" ';
				$serv_mode2 = 'style="display: none;" ';
				
                
            } else {
                // Блок кода, который выполнится, если кавычки пусты
                $serv_mode = 'type="text"'; 
            }
    

    
        $ver = '';
        for ($i = 0; $i < 200; $i++) {
                
            $stroka = fgets($file);
            
            //Остовляем строки для сервесного режима
			$ins_serv_sel = $serv_mode2; //видимость селектов с каналами
            $values = array('set_Shift_time_watering', 'sets_Canal_out' , 'set_Time_drain', 'set_proba_max_ec', 'set_proba_min_ec' , 'setm_Sens_out_id', 'set_time_alarm', 'set_Shift_time_restart', 'sets_telegram_bot', 'sets_email');
            $ins_serv = $serv_mode;
            if ($serv_mode == 'type="hidden" ')
            {
                foreach ($values as $value) {

                    if (strpos($stroka, $value) !== false) {
                        $ins_serv = 'type="text"';
						$ins_serv_sel = ""; //видимость селектов с каналами
						
						
                    } 
                }
            }


            
            if (substr($stroka , 0, 12) == '--separation' ) //and $ins_serv == 'type="text"'
            {
                echo'<div '.$serv_mode2.' class="separation_div" name="div_separation'.$i.'"> </div>';      
            }
            
            if (substr($stroka , 0, 10) == '--info: = ')
            {
            echo '<input name="Name_unit_info" id="Name_unit_info" class="input_3" value="'.substr($stroka , 10, strlen($stroka)).'" autocomplete="off" onkeydown="if(event.keyCode==13){return false;}">
            <script>Name_unit_info.addEventListener("input", function(){this.style.backgroundColor = "#B0F0B0";this.style.color="black";})</script>'; 
            }
            
            $pos1      = strripos($stroka, 'label<');
            $pos2      = strripos($stroka, '>label');  
                            
            if ($pos1 == TRUE) // Если первый label< существует - всегда существет у всех установок
                {            
                    
                    $Label = substr($stroka , $pos1+6 , $pos2-$pos1-6);
                    $name =  substr($stroka , 0 , strripos($stroka, ' =')) ;
                
            // Создание Label       
                    echo'
                    <input  readonly class="input_1" '.$ins_serv.' id="label_'.$Label.'" name="label_'.$name.'" value="'.$Label.'"   autocomplete="off" onkeydown="if(event.keyCode==13){return false;}" >                       
                        ';
                
                    
                     $input_2 = 'input_2'; // css стиль для инпута с данными
             // Если значения в кавычках
                     if (substr($stroka , 0, 5) == 'sets_') 
                    {
                        $pos1 = strripos($stroka, '= "')+ 2 ;
                        $pos2 = strripos($stroka, '"')+ 5;
						
						 // Извлечение значения в кавычках
						 if (preg_match('/"([^"]*)"/', $stroka, $matches)) {
    						$firstValue = $matches[1];
    						//echo $firstValue;
						 }
						 if ( trim($firstValue) == "" ) {  // css стиль для инпута с без данных
							 $input_2 = 'input_2_light';
						 }

						//Если опция День 
  						if ($name == "sets_Day_option") {
						echo '
						<input class="button_cell_day" '.$ins_serv.' type="text" id="'.$name.'" name="'.$name.'"  value="'.$firstValue.'" onclick="toggleLabel()" readonly>
						<script>
							function toggleLabel() {
							  var input = document.getElementsByName(\'sets_Day_option\')[0];
							  if (input.value === \'OFF\') {
								input.value = \'ON\';
							  } else {
								input.value = \'OFF\';
							  }
							}
						  </script>';
							}
						 
						// Если выбор канала вставляем select ---------
						elseif ($name == "sets_Canal" or $name == "sets_m_valve"  or $name == "sets_Canal_out")
						{
							// Подготовка массива для хранения значений chX-Y
							$options = [];
							// Генерация значений chX-Y
							for ($x = 1; $x <= 4; $x++) {
								for ($y = 1; $y <= 7; $y++) {
									$options[] = "ch{$x}-{$y}";
								}
							}
							// Создаем выпадающее меню
							echo "
							<select {$ins_serv_sel} id=\"{$name}\" name=\"{$name}\" class=\"input_2_light\"  onchange=\"this.style.backgroundColor='#B0F0B0'; this.style.color='black';\">
							";
							// Добавляем опцию 
							echo "<option value=\"ch\" " . ($firstValue == "ch" ? 'selected' : '') . ">Выбирете канал</option>";
							
							// Опция "Выберите канал" будет скрыта
							echo "<option value=\"\" style=\"display: none;\" " . (empty($firstValue) ? 'selected' : '') . ">Выберите канал</option>";
					
							// Заполнение меню значениями chX-Y
							foreach ($options as $option) {
								// Добавляем опции в селект, устанавливаем 'selected', если опция равна $firstValue
								echo "<option value=\"{$option}\" " . ($option == $firstValue ? 'selected' : '') . ">{$option}</option>";
							}

							echo "
							</select>
							";
						 }
						 // Если выбор высылаемой инфы ---------
						elseif ($name == "sets_email_set")
						{
						 echo "
							<select id=\"{$name}\" name=\"{$name}\" class=\"input_2_light\"  onchange=\"this.style.backgroundColor='#B0F0B0'; this.style.color='black';\">
							";
							// Добавляем опцию 
							echo "<option value=\"1\" " . ($firstValue == "1" ? 'selected' : '') . ">Все сообщения</option>";
							
							// Добавляем опцию "Выберите канал" для пустого значения
							echo "<option value=\"2\" " . ($firstValue == "2" ? 'selected' : '') . ">Только предупреждения</option>";
							echo "
							</select>
							";
						}
						 ///-----------------------------------
						//Все остальное
						 else
						 {
					          echo 
                       '
                        <input  class="'.$input_2.'" '.$ins_serv.' type="text" id="'.$name.'" name="'.$name.'"  value="'.$firstValue.'"  autocomplete="off" onkeydown="if(event.keyCode==13){return false;}">
						<script>'.$name.'.addEventListener("keydown", function(){this.style.backgroundColor = "#B0F0B0";this.style.color="black";})
                        </script> 
                        
                        ';	 
							 
						 }
                        
                    }
                    
                
              // Если  массив данных
                     if (substr($stroka , 0, 5) == 'setm_')
                    {   
                    $stroka = str_replace(",", " ", $stroka);
				    $pos1      = strripos($stroka, '{'); 
                    $pos2      = strripos($stroka, '}');
					$val = trim(substr($stroka , $pos1+1 , $pos2-$pos1-1) );
					
					if ( $val == "" ) 
					   {  
						$input_2 = "input_2_light"; // css стиль для инпута с без данных
					   }
						 
                        echo 
                       '
                             
                        <input  class="'.$input_2.'" '.$ins_serv.' type="text" id="'.$name.'" name="'.$name.'"  value="'.$val.'"  autocomplete="off" onkeydown="if(event.keyCode==13){return false;}" >
                        <script>'.$name.'.addEventListener("keydown", function(){this.style.backgroundColor = "#B0F0B0";this.style.color="black";})
                                
                        </script> 
                        
                        ';
                        

						$script = "<script>";
						$script .= "document.getElementById('$name').addEventListener('input', function() {";
						//Для setm_P - оставляем пробел цифру и точку для ввода
						if (substr($stroka , 0, 6) == 'setm_P' or substr($stroka , 0, 6) == 'setm_C') 
						{
						$script .= "this.value = this.value.replace(/[^0-9.\\s]+|,/g, '');";								
						}
						else // в остальных случаях оставляем тольо цифры и пробел
						{
						$script .= "this.value = this.value.replace(/[^\d\s]/g, '');";
						}
						$script .= "});";
						$script .= "</script>";

						echo $script;  
                    }
   
				
				
                // Если просто одно цифровое значение
                if (substr($stroka , 0, 4) == 'set_')
                    {
      
				 preg_match('/=\s*(.*?)\s*--/', $stroka, $matches);

				// Проверяем, найдено ли значение
				if (isset($matches[1]) && trim($matches[1]) !== '') {
					$val= $matches[1]; // Возвращаем найденное значение
				} else {
					$val= '""'; // Если ничего не найдено, возвращаем пустую строку
					$input_2 = "input_2_light"; // css стиль для инпута с без данных
				}


                        $format = '';
                        if ($name == "set_dilution_ppm" or $name == "set_Quota" or $name == "set_Temp_corection" ) {$format = 'step="0.1"';}
                        
						$ins_serv2 = $ins_serv;
						// Принудительно вкл.type="number"
					    if ($ins_serv == 'type="text"'){$ins_serv2 = 'type="number"';}  
					    
					
                        echo'
                        
                        <input class="'.$input_2.'" id="'.$name.'_dig" name="'.$name.'" value="'.$val.'" autocomplete="off"
                        '.$ins_serv2.'   '.$format.'onkeydown="if(event.keyCode==13){return false;}"
                                                
                        > 
                        <script>'.$name.'_dig.addEventListener("input", function(){this.style.backgroundColor = "#B0F0B0";this.style.color="black";})</script>                         

                        ';
                        
                    }
				
                    
               // Добавление названиия 
                    $pos1  = strripos($stroka, 'info<');
                    $pos2  = strripos($stroka, '>info');
									
                    if ($pos1 !== FALSE) // Если info< существует
                    {
                        
                     
                        if (substr($name, 0,9) == "setm_Pump" )
                        {              
                        echo'
                        
                        <input  class="input_3" '.$ins_serv.'  id="'.$name.'_info" name="info_'.$name.'" id="'.$name.'_info" type="text" value="'.substr($stroka , $pos1+5 , $pos2-$pos1-5).'"  autocomplete="off" onkeydown="if(event.keyCode==13){return false;}" >
                        <script>'.$name.'_info.addEventListener("keydown", function(){this.style.backgroundColor = "#B0F0B0";this.style.color="black";})</script>                          

                        ';
							
							
                        }
                        else
                        {
                            if (substr($name, 0,3) == "set" )
                           {              
                            //readonly
                            echo'
                        
                            <input readonly class="input_3_readonly" id="'.$name.'_info" name="info_'.$name.'" '.$ins_serv.' type="text" value="'.substr($stroka , $pos1+5 , $pos2-$pos1-5).'" title="'.substr($stroka , $pos1+5 , $pos2-$pos1-5).'" onkeydown="if(event.keyCode==13){return false;}"  >
                         

                            ';
                           }  
                            
                
                        }
             
                        
                    }
         
                     if($ins_serv == 'type="text"')
					 {
					//echo '<br>';	 
					 }                  
                     
                    
                }
            

			
			
         if (strpos($stroka , 'Ver')) 
         {$ver = substr($stroka , strpos($stroka , 'Ver'), strlen($stroka)) ;}            
                
        }   
        fclose($file); 
        
         


        
        
?>





			<input type="hidden" name="cheсk" value="check"> <!--  Проверочный инпут в конце ------>
			<input class="button" type="submit" name="save_header" value="Сохранить Header" style="display: none;">

			</form>

			<div class="separation_div"> </div>

			<div class="input_1" style="color:grey; border: 0px;"> <?php echo $ver ?> </div>







</div>

<script>
	//Этот JavaScript код будет искать все элементы input с типом "number" на странице и добавлять обработчик события прокрутки колеса мыши. Когда происходит событие прокрутки, код проверяет, является ли целевой элемент активным (то есть, имеет ли фокус), и если это так, предотвращает стандартное поведение прокрутки. Таким образом, данная функция предотвращает изменение значения поля ввода типа "number" при прокрутке колеса мыши.
    document.querySelectorAll("input[type=number]").forEach(function (element) {
        element.addEventListener("wheel", function(event) {
            if (document.activeElement === event.target) {
                event.preventDefault();
            }
        });
    });
</script>

<script>
document.addEventListener('keydown', function(event) {
  if (event.ctrlKey && event.key === '/') {
    // Убираем readonly у всех input
    document.querySelectorAll('input').forEach(function(input) {
      input.removeAttribute('readonly');
    });
    
    // Делаем кнопку save_header видимой
    const saveButton = document.querySelector('input[name="save_header"]');
    if (saveButton) {
      saveButton.style.display = 'block'; // или 'inline-block' в зависимости от нужного отображения
      // Если использовалось opacity/visibility, то:
      // saveButton.style.opacity = '1';
      // saveButton.style.visibility = 'visible';
    }
  }
});
</script>
   




</body>

</html>
