<style>
	@import "../style.css" screen; /* Стиль для вывода результата на монитор */
    @import "../style.css" print, handheld; /* Стиль для печати и смартфона */

</style>                                    

<div style="Position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);">
	<?php include('../pic/process.svg'); ?> 
</div>

<?php

if(isset($_POST['del'])) {

    //Удаление загруженного

    $dir = '/home/pi/domoticz/scripts/lua/';
    $file = $_POST['del_file'];   

   // echo 'удаление ...'.$dir.$file; echo '<br>';

    //Удаление файла
    $comand = 'rm '.$dir.$file;
    $output = shell_exec($comand);

    //Удаление переменной пользователя Domoticz - начало

    function utf8_urldecode($str) 
    {
    $str = preg_replace("/%u([0-9a-f]{3,4})/i","&#x\\1;",urldecode($str));
    return html_entity_decode($str,null,'UTF-8');;
    }


    $file = str_replace(".lua" ,"" ,$file);
    
    if (substr($file, 0, 4) == 'off_'){
        $file = str_replace("off_script_time_plant_" ,"" ,$file);
    }
    else
    {
     $file = str_replace("script_time_plant_" ,"" ,$file);    
    }
   
    

    $decod = json_encode(array(utf8_urldecode($file))); 
    $add = str_replace ( "\\", "\\\\\\", $decod);
    $simb   = array("[", "]");
    $repl = str_replace ( $simb, "", $add);

    //определение id переменной
    $comand = 'curl "127.0.0.1:8080/json.htm?type=command&param=getuservariables" | grep -C 3 '.$repl. ' | grep "idx"  '. "| awk '{print $3 }' " . '| sed '.'s/\"//g';
    $output = shell_exec($comand);
    $output = trim($output);

    // удаление переменной по id
    $comand = 'curl "127.0.0.1:8080/json.htm?type=command&param=deleteuservariable&idx='.$output.'"';
    //echo $comand;
    $output = shell_exec($comand);
    //echo $output;
    //Удаление переменной пользователя Domoticz - конец
    //exit;
}


$newname = '';

//Отключить скрипт - т.е. переименовать c добавкой off
if(isset($_POST['otkl'])) {
    
    $dir = '/home/pi/domoticz/scripts/lua/';
    $file = $_POST['del_file'];   
    if (substr($file,0,4)!='off_'){
       // echo 'Переименование ...'.$dir.$file; echo '<br>';
        //Переименование файла
        $newname = 'off_'.substr($file, 12);
        $comand = ' mv '.$dir.$file.' '.$dir.$newname;
        $output = shell_exec($comand);    

    }
  
}

//Включить скрипт - т.е. переименовать c без добавки off
if(isset($_POST['vkl'])) {

    $dir = '/home/pi/domoticz/scripts/lua/';
    $file = $_POST['del_file'];   
    if (substr($file,0,4) =='off_'){
        //echo 'Переименование ...'.$dir.$file; echo '<br>';
        //Переименование файла
        $newname = 'script_time_'.substr($file,4, strlen ($file));    
        $comand = ' mv '.$dir.$file.' '.$dir.$newname;
        $output = shell_exec($comand);    
            
    }
  
}















echo 
'
<html>
<body onload="document.frm1.submit()">
   <form action="index.php" name="frm1" method="POST">
      <input type="hidden" name="rast" value='.$newname.' >
   </form>
</body>
</html>

'


?>


