<?php
session_start();
define('BACKUP_DIR', dirname(__DIR__) . '/backup');
define('CONFIG_FILE', __DIR__ . '/update_config.json');

// Загружаем сохраненные данные
$saved_data = ['username' => '', 'password' => '', 'build_type' => 'stable'];
if (file_exists(CONFIG_FILE)) {
    $content = file_get_contents(CONFIG_FILE);
    if ($content) {
        $data = json_decode($content, true);
        if ($data) {
            $saved_data = array_merge($saved_data, $data);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Обновление</title>
    <style>
        @import "../style.css" screen;
        @import "../style.css" print, handheld;
        

    </style>
</head>
<body>			


        <?php
        ob_start();
        $_GET['version'] = 'stable';
        include 'info_ver_reg_ru.php';
        $stable = trim(ob_get_clean());

        ob_start();
        $_GET['version'] = 'test';
        include 'info_ver_reg_ru.php';
        $test = trim(ob_get_clean());

        //echo "Стабильная: $stable\nТестовая: $test";
        ?>
    
        <div class="div_content_settings_panel">
        <div class="labels">Установлена версия Rastinator - <?php $file_contents = file_get_contents('../version_info');
                                                                echo $file_contents; ?></div>
        <div class="labels">Доступна для обновления: <?php echo $stable;?></div>
        <div class="labels">Доступна для обновления: <?php echo $test;?></div>
    
        </div>
        <br>
    <!-- Контейнер для формы -->
        
        <form method="POST" id="downloadForm">
            <div class="div_content_settings_panel">
                <div>
                    <label class="label_email" for="username">Логин покупателя:</label>
                    <input type="text" class="input_settings" id="username" name="username" required 
                           value="<?php echo htmlspecialchars($saved_data['username']); ?>">
                </div>
                
                <div>
                    <label class="label_email" for="password">Пароль:</label>
                    <input type="password" class="input_settings" id="password" name="password" required
                           value="<?php echo htmlspecialchars($saved_data['password']); ?>">
                </div>

                <div class="remember_container">
                    <input type="checkbox" class="remember_checkbox" id="remember" name="remember" value="1" checked>
                    <label class="remember_label" for="remember">Запомнить</label>
                </div>
                <br>
                <div>
                    <label class="label_email" for="build_type">Тип сборки:</label>
                    <select class="input_settings" id="build_type" name="build_type" required>
                        <option value="stable" <?php echo $saved_data['build_type'] === 'stable' ? 'selected' : ''; ?>>Стабильная (Stable)</option>
                        <option value="beta" <?php echo $saved_data['build_type'] === 'beta' ? 'selected' : ''; ?>>Тестовая (Beta)</option>
                    </select>
                </div>
                

            </div>
            
            <button type="submit" class="button_text" id="submitBtn">
                <span id="btnText">Обновить</span>
                <span id="btnSpinner" class="spinner" style="display: none;"></span>
            </button>
            
            <?php //if (!empty($saved_data['username'])): ?>
    <!--            <div class="saved_indicator">Данные загружены из сохраненной конфигурации</div> -->
            <?php //endif; ?>
        </form>
        
     <!--    <button class="clear_data_btn" id="clearDataBtn">Очистить сохраненные данные</button> -->
        
        <div class="info_show" id="resultMessage"></div>


    <script>
        document.getElementById('downloadForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const submitBtn = document.getElementById('submitBtn');
            const btnText = document.getElementById('btnText');
            const btnSpinner = document.getElementById('btnSpinner');
            const resultMessage = document.getElementById('resultMessage');
            const rememberCheckbox = document.getElementById('remember');
            
            // Сброс предыдущих сообщений
            resultMessage.className = 'info_show';
            resultMessage.style.display = 'none';
            resultMessage.innerHTML = '';
            
            // Добавляем флаг запоминания
            formData.append('remember', rememberCheckbox.checked ? '1' : '0');
            
            // Показать спиннер
            btnText.textContent = 'Обновление...';
            btnSpinner.style.display = 'inline-block';
            submitBtn.disabled = true;
            
            // Отправка AJAX запроса
            fetch('reg_download_action.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    resultMessage.innerHTML = `
                        <div class="status_message">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M20 6L9 17L4 12" stroke="#155724" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            <span>Файл успешно скачан</span>
                        </div>
                        ${data.filename ? `<div class="file-info">${data.filename}<br>${data.build_type === 'beta' ? 'Тестовая сборка' : 'Стабильная сборка'}</div>` : ''}
                    `;
                    resultMessage.className = 'info_show success';
                } else {
                    resultMessage.innerHTML = `
                        <div class="status_message">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2Z" fill="#721c24"/>
                                <path d="M12 17C12.5523 17 13 16.5523 13 16C13 15.4477 12.5523 15 12 15C11.4477 15 11 15.4477 11 16C11 16.5523 11.4477 17 12 17Z" fill="white"/>
                                <path d="M12 7C11.4477 7 11 7.44772 11 8V13C11 13.5523 11.4477 14 12 14C12.5523 14 13 13.5523 13 13V8C13 7.44772 12.5523 7 12 7Z" fill="white"/>
                            </svg>
                            <span>Ошибка: ${data.error}</span>
                        </div>
                    `;
                    resultMessage.className = 'info_show error';
                }
                resultMessage.style.display = 'block';
            })
            .catch(error => {
                resultMessage.innerHTML = `
                    <div class="status_message">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2Z" fill="#721c24"/>
                            <path d="M12 17C12.5523 17 13 16.5523 13 16C13 15.4477 12.5523 15 12 15C11.4477 15 11 15.4477 11 16C11 16.5523 11.4477 17 12 17Z" fill="white"/>
                            <path d="M12 7C11.4477 7 11 7.44772 11 8V13C11 13.5523 11.4477 14 12 14C12.5523 14 13 13.5523 13 13V8C13 7.44772 12.5523 7 12 7Z" fill="white"/>
                        </svg>
                        <span>Ошибка сети или сервера</span>
                    </div>
                `;
                resultMessage.className = 'info_show error';
                resultMessage.style.display = 'block';
            })
            .finally(() => {
                // Восстановить кнопку
                btnText.textContent = 'Обновить';
                btnSpinner.style.display = 'none';
                submitBtn.disabled = false;
            });
        });
        
        // Очистка сохраненных данных
        document.getElementById('clearDataBtn').addEventListener('click', function() {
            if (confirm('Вы уверены, что хотите очистить сохраненные данные? Поля формы будут очищены.')) {
                fetch('reg_download_action.php?clear_config=1', {
                    method: 'GET'
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Очищаем поля формы
                        document.getElementById('username').value = '';
                        document.getElementById('password').value = '';
                        document.getElementById('build_type').value = 'stable';
                        document.getElementById('remember').checked = true;
                        
                        // Обновляем индикатор
                        const savedIndicator = document.querySelector('.saved_indicator');
                        if (savedIndicator) {
                            savedIndicator.textContent = 'Данные очищены';
                            setTimeout(() => {
                                savedIndicator.textContent = '';
                            }, 3000);
                        }
                        
                        // Показываем сообщение
                        const resultMessage = document.getElementById('resultMessage');
                        resultMessage.innerHTML = `
                            <div class="status_message">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M20 6L9 17L4 12" stroke="#155724" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                                <span>Данные очищены</span>
                            </div>
                        `;
                        resultMessage.className = 'info_show success';
                        resultMessage.style.display = 'block';
                    }
                })
                .catch(error => {
                    console.error('Ошибка очистки данных:', error);
                });
            }
        });
    </script>
</body>
</html>