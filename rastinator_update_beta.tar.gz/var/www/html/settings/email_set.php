<!DOCTYPE html>
<html>
<head>

	
<script>	
function redirectWithPost(url, data) {
  var form = document.createElement('form');
  form.method = 'post';
  form.action = url;

  for (var key in data) {
    if (data.hasOwnProperty(key)) {
      var input = document.createElement('input');
      input.type = 'hidden';
      input.name = key;
      input.value = data[key];
      form.appendChild(input);
    }
  }

  document.body.appendChild(form);
  form.submit();
}
</script>
	
	
</head>
<body>
	
<?php
	//var_dump($_POST); exit;
	if(isset($_POST["AuthPass"]))
	{

		$hostname = 'localhost';
		$FromLineOverride = 'NO';
		$mailhub = 'smtp.yandex.ru:465';
		$UseTLS = 'YES';
		$AuthUser = $_POST["AuthUser"];
		$AuthPass = $_POST["AuthPass"];
		$test_email = $_POST["test_email"];


		 $str = 'sudo /home/pi/bin/email_set '.$hostname.' '.$FromLineOverride.' '.$AuthUser.' '.$AuthPass  .' '.$mailhub.' '.$UseTLS.' '.$test_email;
		 shell_exec($str);

		 $str = 'echo "Настройки почтового сервера верные!" | sudo -u pi mail -s "Rastinator-e-mail-test" '.$test_email;
	
		 
		//$str = 'sudo printf "Subject: =?UTF-8?B?$(echo "Наааа" | base64)?=\nFrom: Rastinator <'. $AuthUser .'>\nTo: '.$test_email.'\n\n'.' mess '.'" | sudo sendmail -t';
		
		// Кодируем строку "Наааа" в base64
		//$subject_base64 = base64_encode('Проверка настроек почты');

		//$command = 'printf "Subject: =?UTF-8?B?$(echo "Проверка настроек почты" | base64)?=\nFrom: Rastinator<chief-nav@yandex.ru>\nTo: vertufir@gmail.com\n\nНастройки верные!" | //sudo sendmail -t	';	

		//print ($command); //exit;
		
		shell_exec($str);

		
	}
	
	if(isset($_POST["bot_token"]))
	{
		$token = $_POST["bot_token"];
		$file_path = '/home/pi/bin/restart_info';
		
		shell_exec("sudo chmod 777 /home/pi/bin/restart_info");
		// Команда sed для обновления токена
    	$command = "sed -i \"s|token_bot='[^']*'|token_bot='$token'|\" $file_path";

    	shell_exec($command);
		//print ($command); exit;

	    // проверка 

		$token_new = trim(shell_exec('awk -F "\'" \'/token_bot=/ {print $2}\' /home/pi/bin/restart_info '));

				// Формируем команду
		$str = "rm /var/www/html/telegram/chat_id.txt";
		$output = shell_exec($str);
		
		// Формируем команду
		$str = "python3 /var/www/html/telegram/telegram_bot.py $token_new 'Настройки Telegram верные.'";
		$output = shell_exec($str);

		//echo $output; exit;
	}
?>
	
	
<script>
window.onload = function() {
  var data = {sent: 1};

  // Перенаправление и отправка POST-запроса
  redirectWithPost("index.php", data);
}
</script>
	

</body>
</html>











