<!DOCTYPE html>
<html>
<head>

	
<script>	
function redirectWithPost(url, data) {
  var form = document.createElement('form');
  form.method = 'post';
  form.action = url;

  for (var key in data) {
    if (data.hasOwnProperty(key)) {
      var input = document.createElement('input');
      input.type = 'hidden';
      input.name = key;
      input.value = data[key];
      form.appendChild(input);
    }
  }

  document.body.appendChild(form);
  form.submit();
}
</script>
	
	
</head>
<body>
	
<?php
	//var_dump($_POST); exit;
	if(isset($_POST["AuthPass"]))
	{

		$hostname = 'localhost';
		$FromLineOverride = 'NO';
		$mailhub = 'smtp.yandex.ru:465';
		$UseTLS = 'YES';
		$AuthUser = $_POST["AuthUser"];
		$AuthPass = $_POST["AuthPass"];
		$test_email = $_POST["test_email"];


		 $str = 'sudo /home/pi/bin/email_set '.$hostname.' '.$FromLineOverride.' '.$AuthUser.' '.$AuthPass  .' '.$mailhub.' '.$UseTLS.' '.$test_email;
		 shell_exec($str);

		 $str = 'echo "Настройки почтового сервера верные." | sudo mail -s "Тестовое Письмо" '.$test_email;


		shell_exec($str);

		//exit('<meta http-equiv="refresh" content="0; url=index.php?sent=1" />');
	}
	
	if(isset($_POST["bot_token"]))
	{
		$token = $_POST["bot_token"];
		$file_path = '/home/pi/bin/restart_info';

		// Команда sed для обновления токена
    	$command = "sed -i \"s|token_bot='[^']*'|token_bot='$token'|\" $file_path";

    	shell_exec($command);
		//print ($command); exit;

	    // проверка 

		$token_new = trim(shell_exec('awk -F "\'" \'/token_bot=/ {print $2}\' /home/pi/bin/restart_info '));

		// Формируем команду
		$str = "sudo python3 /home/pi/domoticz/scripts/python/telegram_bot.py $token_new 'Настройки телеграм верные.'";
		$output = shell_exec($str);
		//$output = shell_exec($str . " 2>&1");
		//echo "<pre>$output</pre>"; exit;
	}
?>
	
	
<script>
window.onload = function() {
  var data = {sent: 1};

  // Перенаправление и отправка POST-запроса
  redirectWithPost("index.php", data);
}
</script>
	

</body>
</html>











