<?php
session_start();

define('SERVER_URL', 'https://rastinator.ru/?action=server_download');
define('BACKUP_DIR', dirname(__DIR__) . '/backup');
define('CLIENT_NAME', 'mini-server-' . gethostname());
define('TIMEOUT', 300);
define('CONFIG_FILE', __DIR__ . '/update_config.json');

header('Content-Type: application/json');

// Включаем вывод ошибок для отладки
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Функция для логирования
function logDebug($message) {
    file_put_contents(__DIR__ . '/debug.log', date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL, FILE_APPEND);
}

// Обработка очистки конфигурации
if (isset($_GET['clear_config']) && $_GET['clear_config'] == '1') {
    logDebug('Запрос на очистку конфигурации');
    if (file_exists(CONFIG_FILE)) {
        if (unlink(CONFIG_FILE)) {
            logDebug('Файл конфигурации удален: ' . CONFIG_FILE);
        } else {
            logDebug('Ошибка при удалении файла: ' . CONFIG_FILE);
        }
    } else {
        logDebug('Файл конфигурации не существует: ' . CONFIG_FILE);
    }
    echo json_encode(['success' => true, 'message' => 'Конфигурация очищена']);
    exit;
}

// Проверяем и создаем директорию для бэкапа
if (!is_dir(BACKUP_DIR)) {
    logDebug('Создаем директорию для бэкапа: ' . BACKUP_DIR);
    if (!mkdir(BACKUP_DIR, 0755, true)) {
        logDebug('Ошибка при создании директории: ' . BACKUP_DIR);
    }
}

function getClientIP() {
    $ip_keys = ['HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR'];
    foreach ($ip_keys as $key) {
        if (array_key_exists($key, $_SERVER) === true) {
            foreach (explode(',', $_SERVER[$key]) as $ip) {
                $ip = trim($ip);
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
    }
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

function makeRequest($url, $method = 'GET', $data = null, $headers = []) {
    $ch = curl_init();
    
    $default_headers = [
        'X-Client-Name: ' . CLIENT_NAME,
        'X-Client-IP: ' . getClientIP(),
        'User-Agent: MiniServerDownloader/2.0'
    ];
    
    $all_headers = array_merge($default_headers, $headers);
    
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HEADER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_TIMEOUT => TIMEOUT,
        CURLOPT_HTTPHEADER => $all_headers,
        CURLINFO_HEADER_OUT => true
    ]);
    
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        if ($data) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
            $all_headers[] = 'Content-Type: application/x-www-form-urlencoded';
            curl_setopt($ch, CURLOPT_HTTPHEADER, $all_headers);
        }
    }
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    $error = curl_error($ch);
    
    curl_close($ch);
    
    return [
        'success' => $http_code >= 200 && $http_code < 300,
        'http_code' => $http_code,
        'headers' => substr($response, 0, $header_size),
        'body' => substr($response, $header_size),
        'error' => $error
    ];
}

function saveConfiguration($username, $password, $build_type) {
    logDebug('Попытка сохранения конфигурации');
    logDebug('Путь к файлу: ' . CONFIG_FILE);
    
    $config_data = [
        'username' => $username,
        'password' => $password,
        'build_type' => $build_type,
        'saved_at' => date('Y-m-d H:i:s')
    ];
    
    $json_data = json_encode($config_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    
    // Проверяем, можем ли мы записать файл
    $dir = dirname(CONFIG_FILE);
    if (!is_writable($dir)) {
        logDebug('Директория не доступна для записи: ' . $dir);
        logDebug('Права директории: ' . substr(sprintf('%o', fileperms($dir)), -4));
        return false;
    }
    
    $result = file_put_contents(CONFIG_FILE, $json_data);
    
    if ($result === false) {
        logDebug('Ошибка при записи файла конфигурации');
        $error = error_get_last();
        logDebug('Последняя ошибка: ' . print_r($error, true));
        return false;
    }
    
    logDebug('Конфигурация успешно сохранена');
    logDebug('Размер файла: ' . $result . ' байт');
    logDebug('Содержимое конфигурации (без пароля): ' . json_encode(array_merge($config_data, ['password' => '***HIDDEN***'])));
    
    return true;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'])) {
    logDebug('Получен POST запрос на скачивание');
    logDebug('Данные формы: ' . print_r($_POST, true));
    
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $build_type = $_POST['build_type'] ?? 'stable';
    $remember = isset($_POST['remember']) && $_POST['remember'] == '1';
    
    logDebug('Пользователь: ' . $username);
    logDebug('Тип сборки: ' . $build_type);
    logDebug('Запомнить: ' . ($remember ? 'Да' : 'Нет'));
    
    try {
        logDebug('Начинаем процесс скачивания...');
        
        $response = makeRequest(SERVER_URL, 'POST', [
            'username' => $username,
            'password' => $password,
            'build_type' => $build_type
        ]);
        
        logDebug('Ответ от сервера: HTTP ' . $response['http_code']);
        
        if ($response['error']) {
            throw new Exception("Ошибка сети: " . $response['error']);
        }
        
        if (!$response['success']) {
            $json = @json_decode($response['body'], true);
            $error_msg = $json['message'] ?? 'Неизвестная ошибка сервера';
            throw new Exception("Ошибка сервера: " . $error_msg);
        }
        
        $json = @json_decode($response['body'], true);
        
        if (!$json || !isset($json['success']) || !$json['success']) {
            throw new Exception("Неверный формат ответа от сервера");
        }
        
        $token = $json['data']['token'];
        $file_info = $json['data']['file_info'];
        $download_url = $json['data']['download_url'];
        $build_type = $file_info['build_type'] ?? $build_type;
        
        logDebug('Токен получен, начинаем скачивание файла');
        
        $backup_filename = ($build_type === 'beta') ? 'rastinator_update_beta.tar.gz' : 'rastinator_update.tar.gz';
        $backup_path = BACKUP_DIR . '/' . $backup_filename;
        
        logDebug('Имя файла: ' . $backup_filename);
        logDebug('Путь для сохранения: ' . $backup_path);
        
        $fp = fopen($backup_path, 'w+');
        if (!$fp) {
            throw new Exception("Не удалось создать файл");
        }
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $download_url,
            CURLOPT_FILE => $fp,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_TIMEOUT => TIMEOUT,
            CURLOPT_HTTPHEADER => [
                'X-Client-Name: ' . CLIENT_NAME,
                'X-Client-IP: ' . getClientIP()
            ]
        ]);
        
        $result = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        
        curl_close($ch);
        fclose($fp);
        
        if ($error || $http_code !== 200) {
            @unlink($backup_path);
            throw new Exception("Ошибка скачивания");
        }
        
        $actual_size = filesize($backup_path);
        $expected_size = $file_info['size'];
        
        if ($actual_size === 0) {
            @unlink($backup_path);
            throw new Exception("Файл скачан, но его размер 0 байт");
        }
        
        logDebug('Файл успешно скачан, размер: ' . $actual_size . ' байт');



	$comand = 'sudo tar xPf /var/www/html/backup/rastinator_update.tar.gz -C /';
	shell_exec($comand); 
	
	 //Меняем права и пользователей
    $comand = 'sudo chown -R pi:www-data /var/www/html/';
    shell_exec($comand);
    $comand = 'sudo chmod -R 770 /var/www/html/';
    shell_exec($comand);
      
    
    // тоже для /home/pi/domoticz/scripts/lua
    $comand = 'sudo /bin/chown -R pi:www-data /home/pi/domoticz/scripts/lua';
    shell_exec($comand);
    $comand = 'sudo /bin/chmod -R 770 /home/pi/domoticz/scripts/lua';
    shell_exec($comand);
      
	  
    // тоже для /home/pi/bin/
    $comand = 'sudo /bin/chown -R pi:www-data /home/pi/bin';
    shell_exec($comand);
    $comand = 'sudo /bin/chmod -R 770 /home/pi/bin';
    shell_exec($comand);

// Запус скриптов для дополнительного апгрейта
	$comand = '/home/pi/bin/one_run_scrips/ble_sens_add';
    shell_exec($comand);


    

        
        // Сохраняем конфигурацию, если пользователь выбрал "Запомнить данные"
        if ($remember) {
            logDebug('Попытка сохранить конфигурацию...');
            $save_result = saveConfiguration($username, $password, $build_type);
            logDebug('Результат сохранения: ' . ($save_result ? 'Успех' : 'Ошибка'));
        } else {
            logDebug('Удаление конфигурации по запросу пользователя');
            // Удаляем конфигурацию, если она существует
            if (file_exists(CONFIG_FILE)) {
                if (unlink(CONFIG_FILE)) {
                    logDebug('Конфигурация удалена');
                } else {
                    logDebug('Ошибка при удалении конфигурации');
                }
            }
        }
        
        $response_data = [
            'success' => true,
            'filename' => $backup_filename,
            'path' => $backup_path,
            'size' => $actual_size,
            'build_type' => $build_type,
            'timestamp' => date('Y-m-d H:i:s'),
            'remembered' => $remember,
            'config_file' => CONFIG_FILE,
            'config_exists' => file_exists(CONFIG_FILE)
        ];
        
        logDebug('Отправляем успешный ответ: ' . json_encode($response_data));
        
        echo json_encode($response_data);
        
    } catch (Exception $e) {
        logDebug('Исключение: ' . $e->getMessage());
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage(),
            'timestamp' => date('Y-m-d H:i:s')
        ]);
    }
} else {
    logDebug('Неверный запрос метод: ' . $_SERVER['REQUEST_METHOD']);
    echo json_encode([
        'success' => false,
        'error' => 'Неверный запрос'
    ]);
}