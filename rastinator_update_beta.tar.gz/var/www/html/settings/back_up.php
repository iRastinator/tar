
<?php


$file =  "/var/www/html/backup/rastinator_backup.tar.gz";

// Команда  tar только система /var/www/html 	  
if ($_POST['only_system'] == "on") 
    {   
		$comand = 'tar --exclude=/var/www/html/backup --exclude=/var/www/html/log/log_watering --exclude=/var/www/html/token --exclude=/var/www/html/log/error_detected.log --exclude=/home/pi/bin/restart_info -zcvf '.$file.' /var/www/html/* /home/pi/bin/*';
		shell_exec($comand);  
    }

else	
	{  // Настройки только

		$comand = 'sudo systemctl stop domoticz';
		$output = shell_exec($comand);
		$comand = 'sleep 5';
		$output = shell_exec($comand);
		
		$comand = 'tar  -zcvf '.$file.' /home/pi/domoticz/scripts/lua/* /home/pi/domoticz/domoticz.db';
		shell_exec($comand);

		$comand = 'sudo systemctl start domoticz';
		$output = shell_exec($comand);
	}


// Процесс загрузки
  if (file_exists($file)) {
    // сбрасываем буфер вывода PHP, чтобы избежать переполнения памяти выделенной под скрипт
    // если этого не сделать файл будет читаться в память полностью!
    if (ob_get_level()) {
      ob_end_clean();
    }
    // заставляем браузер показать окно сохранения файла
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename=' . basename($file));
    header('Content-Transfer-Encoding: binary');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($file));
    // читаем файл и отправляем его пользователю
    readfile($file);
    exit;
  }

//$comand = 'rm -f ras_back_up.tar.gz';
//$output = shell_exec($comand);

    
?>