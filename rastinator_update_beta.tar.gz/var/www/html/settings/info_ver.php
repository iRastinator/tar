<?php

//var_dump ($_GET); exit;
// Получаем значение переменной version из параметров запроса (например, из URL)
$version = $_GET['version'] ; // Устанавливаем по умолчанию 'stable'
$history_link = '';
// Определяем URL для получения информации о версии на основе параметра
if ($version === 'test') {
    $url = 'https://raw.githubusercontent.com/iRastinator/tar/main/version_info_beta'; // Если beta
} else {
    $url = 'https://raw.githubusercontent.com/iRastinator/tar/main/version_info'; // Если stable
	$history_link = '<a class="button_text" href="https://raw.githubusercontent.com/iRastinator/tar/main/history">История изменений</a>';
}

// Получаем данные о версии
$file_contents = file_get_contents($url);

// Выводим информацию о доступной версии
echo 'Доступна версия Rastinator: ' . $file_contents.' <br> '.$history_link ;

?>
