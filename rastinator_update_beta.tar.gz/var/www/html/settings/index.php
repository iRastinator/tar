<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Rastinator</title>
<script type="text/javascript" src="/ajax/jquery-3.7.0.min.js"></script>
<style>
         @import "../style.css" screen; /* Стиль для вывода результата на монитор */
         @import "../style.css" print, handheld; /* Стиль для печати и смартфона */
    
                    *{
    padding: 0%;
    margin: 0%;
            }
            .container{
            grid-template-columns: auto;
            display: grid;
            
    
          }
          
          .item {
              
              padding: 0px;
              border: 0px solid black;
                        
            }


    
</style>      
          
</head>

<body>

<?php
	
//var_dump($_POST);	//exit();
//Авторизация
include('../login/in.php');    
    
function debug_to_console($data) {
    $output = $data;
    if (is_array($output))
        $output = implode(',', $output);
    echo "<script>console.log('Debug Objects: " . $output . "' );</script>";
}    
?>
    
   
    
<div class="container">

<!-- Верхнее меню -->     
<div class="item item_1">
        <ul>
		<li><svg width="clamp(6.25rem, 3.977rem + 11.36vw, 12.5rem)" height="clamp(1rem, 0.786rem + 2.29vw, 2.5rem)" viewBox="150 -30 180 180"> <?php include('../pic/Rastinator.svg'); ?> </svg> </li>
          <li><a href="../poliv/index.php" >Полив</a></li>    
          <li><a href="../climat/index.php">Климат</a></li>
          <li><a href="../sensors/index.php">Датчики</a></li>
          <li><a class="active">Настройки</a></li>
          <li><a href="../log_poliva/index.php">Журнал полива</a></li>
          <li><a href="../log_domoticz/index.php">Лог системы</a></li>

        </ul>  
    

    
</div>              

		<!-- Информационная панель - отображение данных лога -->
		<div class="item item_2">
			<script type="text/javascript">
				$(document).ready(function() {
					var updateInfo = function() {
						$.ajax({
							url: '../log/log.php',
							cache: false, // Предотвращаем кэширование запроса
							success: function(response) {
								var trimmedResponse = response.trim();
								// Проверка наличия времени в формате HH:MM
								if (/(\b[01]?[0-9]:[0-5][0-9]\b|\b2[0-3]:[0-5][0-9]\b)/.test(trimmedResponse)) {
									$("#info").css("color", ""); // Сброс цвета
									$(".info_climat").css("color", ""); // Сброс цвета для классов
									$("#info").html(trimmedResponse); // Обновление содержимого
								} else {
									$("#info").css("color", "gray"); // Окрашивание в серый цвет
									$(".info_climat").css("color", "gray"); // Окрашивание в серый цвет для классов
									// Не обновляем содержимое
								}
							},
							error: function() {
								console.error("Ошибка при загрузке данных из log.php");
							}
						});
					};

					var updateInfoBar = function() {
						$("#info_bar").load('../log/log_bar.php');
					};

					setInterval(updateInfo, 2000);
					setInterval(updateInfoBar, 2000);
				});
			</script>

			<div id="info_bar">
				<?php include('../log/log_bar.php'); ?>
			</div>

			<div id="info">
				<?php include('../log/log.php'); ?>
			</div>
		</div>  
    
    
<!-- item item_4 - Кнопки  -  ----------> 
<div class="item item_3">
    
                                                  


<div class="btn-group">

<a class="btn_pag"  href="off_reboot.php?reboot_domoticz" >Перезагрузка процессов Domoticz</a> 
	
<a class="btn_pag"  href="off_reboot.php?reboot" onclick="return confirm('Вы действительно хотите  перезагрузить систему?')">Перезагрузка системы</a> 
<a class="btn_pag"  href="off_reboot.php?shutdown" onclick="return confirm('Вы действительно хотите завершить работу системы?')">Выключение системы</a> 

   

</div> 
    
 

</div> 

    
    
<!--   -->
<div class="item item_4">

   <div class="settings_palel">
	   <form action="back_up.php" method="post" name="save_sett">
			<p class="settins_label">Сохранение настроек </p>
			<br>
			<input class="button_text" type="submit" value="Сохранить настройки" name="download_set">
		    <div style="display: block ; padding-top: 1em;">
		    <input class="checkbox" type="checkbox" id="only_system" name="only_system">
			<label class="labels" for="only_system">Сохранить систему Rastinator без установок и данных</label>
		    </div>
			</form>
			

	</div>
	
	<div class="settings_palel">
        <p class="settins_label">Восстановление настроек </p>
        <form action="upload.php" method="post" enctype="multipart/form-data">

  		
			<div class="file-upload">
  			<input type="file" name="fileToUpload" id="fileToUpload">
  			<label class="labels" for="fileToUpload">Выберите файл</label>
  			<span id="filename"></span>
			</div>

			<script>
			document.getElementById('fileToUpload').addEventListener('change', function() {
			document.getElementById('filename').textContent = this.files[0].name;
			});
			</script>	
			
		
			  <input class="button_text" type="submit" onclick="return confirm('Внимание! Рекомендуем перед восстановлением настроек сначала сохранить существующие. Продолжить восстановление?')" value="Восстановить настройки" name="download_set">
			  <br> 
			  <br> 
			  <input class="checkbox" type="checkbox" id="without_bd" name="without_bd">
			  <label class="labels" for="without_bd">Не восстанавливать базу данных</label>
			  <br>
			  <input class="checkbox" type="checkbox" id="without_old_scrips" name="without_old_scrips">
			  <label class="labels" for="without_bd">Удалять текущие профили</label>

			
        </form>
    </div>
	
	
	
	<div class="settings_palel">
		<p class="settins_label">Обновление</p>

		<div class="div_content_settings_panel">
			<div class="labels">Установлена версия Rastinator: <?php $file_contents = file_get_contents('../version_info'); echo $file_contents; ?></div> 
		</div>

		<br>

		<!-- Селектор для выбора версии -->
		<label class="labels" for="version_select">Версия:</label>
		<select id="version_select">
			<option value="stable" selected>Стабильная</option>
			<option value="test">Тестовая</option>
		</select>

		<button class="button_text" id="getDataButton">Проверить обновление</button>

		<script>
			$(document).ready(function(){
				$("#getDataButton").click(function(){
					var selectedValue = $('#version_select').val(); // Получаем выбранное значение
					$.ajax({
						url: "info_ver.php?version=" + selectedValue, // Передаем параметр version
						type: "GET",
						success: function(response){
							$("#version").html(response);
						}
					});
				});

				// Обновление ссылки при изменении селектора
				$('#version_select').change(function() {
					var selectedValue = $(this).val(); // Получаем выбранное значение
					var updateHref = 'update.php?version=' + selectedValue; // Формируем новый href
					$('#updateLink').attr('href', updateHref); // Обновляем ссылку на кнопку "Обновить"
				});
			});
		</script>

		<a class="button_text" id="updateLink" href="update.php?version=stable" onclick="return confirm('Вы уверены, что хотите Обновить систему?')">Обновить</a>

		<br>
		<br>

		<div class="div_content_settings_panel">
			<div class="labels" id="version"></div>
			<br>
			<p class="labels">После обновления очистите кеш страницы нажатием Ctrl + F5 или в настройках браузера</p>
		</div>
	</div>


	
	
	
	<div class="settings_palel">
		<p class="settins_label">Калибровка дозировочных насосов / Управление дозировочными насосами</p>
		<br>
		<a class="button_text" href="./calibration/index.php">Начать</a>
		<br><br>
        
	</div>
	
	<div class="settings_palel">
        <p class="settins_label">Управление каналами</p>
        <br>
        <a class="button_text" href="test_channels.php">Начать</a>
        <br><br>
	</div>
	
    <?php
		
	$AuthUser = shell_exec('sudo /home/pi/bin/email_read_user');
	$AuthPass = shell_exec('sudo /home/pi/bin/email_read_pass');
	$test_email = shell_exec('  tail -n 1 /home/pi/bin/restart_info | awk \'{print $NF}\'  ');

	?>

  <div class="settings_palel">
		 <p class="settins_label">Настройка почтового сервера для отправки сообщений</p>
	     <form method="post" action="email_set.php" >
	      <div class="div_content_settings_panel">
			<div>	
			    <label class="label_email" for="AuthUser">Почтовый ящик Яндекс</label>
				<input type="text" class="input_settings" id="AuthUser" name="AuthUser" value="<?php echo $AuthUser ?>" placeholder="e-mail Яндекс">
			</div>
				
			<div>
				<label class="label_email" for="AuthPass">Пароль почтового ящика Яндекс </label>
                <input type="password" class="input_settings" id="AuthPass" name="AuthPass" value="<?php echo $AuthPass ?>" placeholder="пароль">
			</div>	

			

			<div>
				<div>
               <label class="label_email" for="test_email">e-mail для системных сообщений</label>
				</div>
                <input type="text" class="input_settings" id="test_email" name="test_email" value="<?php echo $test_email ?>" placeholder="Тестовый e-mail">
               
			</div>
	    </div>  
			<br>
			<div> 
			 <input class="button_text" type="submit" value="Применить" >
			 <label class="info_show" > 
				<?php
		   
					if(isset($_POST["sent"])) {echo "Выслано тестовое письмо на e-mail для системных сообщений!";}
				?>
			  </label>
			</div>
				
        </form>
	 
  </div>    
     


<div class="settings_palel">
    <p class="settins_label">Добавление модулей расширения Expander</p>
    
    <form id="bluetoothExpanderForm" method="post">
        <div class="div_content_settings_panel">
            <div>    
                <label class="label_email" for="AuthUser">IP адрес расширителя Expander</label>
                <input type="text" class="input_settings" id="IP_bluetooth_expander" name="IP_bluetooth_expander" value="" placeholder="ip адрес">
            </div>
                
            <div>
                <div>
                    <label class="label_email" for="test_email">Логин</label>
                </div>
                <input type="text" class="input_settings" id="login_bluetooth_expander" name="login_bluetooth_expander" value="pi" placeholder="логин">
            </div>
    
            <div>
				<label class="label_email" for="AuthPass">Пароль</label>
				<input type="password" class="input_settings" id="pass_bluetooth_expander" name="pass_bluetooth_expander" value="" placeholder="пароль" autocomplete="off">
			</div>
	
        </div>
        <br>
        <div> 
            <input class="button_text" type="submit" value="Применить">
            
        </div>
        <label class="labels" id="responseLabel"></label>
    </form>
</div>

<script>
    document.getElementById('bluetoothExpanderForm').addEventListener('submit', function(event) {
        event.preventDefault(); // Отменяем стандартное поведение формы

        // Создаем объект FormData для передачи данных формы
        var formData = new FormData(this);

        // Отправляем AJAX-запрос
        fetch('ssl_keys_exchange.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.text()) // Ожидаем, что сервер вернет текст
        .then(data => {
            // Отображаем результат в label
            document.getElementById('responseLabel').innerText = data;
        })
        .catch(error => {
            console.error('Ошибка:', error);
            document.getElementById('responseLabel').innerText = "Ошибка при выполнении запроса.";
        });
    });
</script>
  

	

</div>


<script>
  document.addEventListener('keydown', function(event) {
  if (event.ctrlKey && event.key === '/') {
    window.location.href = '../github/index.php';  // Перенаправление на указанную страницу
  }
});
</script>     
    
  </body>
</html>
