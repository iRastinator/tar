<?php

$comand = 'curl "127.0.0.1:8080/json.htm?type=command&param=updateuservariable&vname=Stop_flag&vtype=2&vvalue=-1"';
$output = shell_exec($comand);

if (isset($_POST['reset_calibraton_data'])  ) 
{  

$comand = 'curl "127.0.0.1:8080/json.htm?type=command&param=updateuservariable&vname=pumps_calibraton&vtype=2&vvalue=1,1,1,1,1,1,1"';
$output = shell_exec($comand);

}

if (isset($_POST['start'])  ) 
{  
    $filename = "/home/pi/domoticz/scripts/lua/script_device_pumps_calibration.lua";
          
//var_dump($_POST); exit();
    
    
    
    $fh = fopen($filename, "w"); 
   
    fwrite($fh , 'commandArray = {}'."\r\n");
	fwrite($fh , 'set_pump = {}'."\r\n");
    fwrite($fh , '------------------------------ Установки -------------------------------------'."\r\n");

	
   

       foreach ($_POST as $key => $value) 
	   {
		   if (substr($key, 0, 9) == 'pump_cal_') 
			{
		   	 
			 if($value == ''){$value = '0';}
			 fwrite($fh , 'set_pump['.substr($key, 9, 1).'] = '.$value."\r\n");
  
			   
		    }
		   
		   
		   if (substr($key, 0, 9) == 'cal_value') 
		   {
			   
			 fwrite($fh , 'set_required_volume = '.$value."\r\n");   
		   }
		   
		   
		   if (substr($key, 0, 8) == 'division') 
		   {
			   
			 fwrite($fh , 'set_division = '.$value."\r\n");   
		   }
		   

	
	   }
	
	
	
	
	 //Присоединение програмной части

       $file2 = file_get_contents( "script_part_calibration" ); 
	
		fwrite($fh , $file2);
	
	    fclose($filename); 


	
    //определение id кнопки Калибровка дозировочных насосов
	function utf8_urldecode($str) 
    {$str = preg_replace("/%u([0-9a-f]{3,4})/i","&#x\\1;",urldecode($str));
     return html_entity_decode($str,null,'UTF-8');;
    }

    $decod = json_encode(array(utf8_urldecode("Калибровка дозировочных насосов"))); 
    $add = str_replace ( "\\", "\\\\\\", $decod);
    $simb   = array("[", "]");
    $repl = str_replace ( $simb, "", $add);  
    $comand = 'curl "127.0.0.1:8080/json.htm?type=command&param=getlightswitches" | grep -C 3 '.$repl. ' | grep "idx"  '. "| awk '{print $3 }' " . '| sed '.'s/\"//g';
    $output = shell_exec($comand);
    $id  = trim($output);

    // Нажать кнопку - Калибровка дозировочных насосов   
    $cmd = "curl '127.0.0.1:8080/json.htm?type=command&param=switchlight&idx=".$id."&switchcmd=On'";
    // echo $cmd ;
    $output = shell_exec($cmd);



}


?>


<html>
<body onload="document.frm1.submit()">
   <form action="calibration.php" name="frm1" method="POST">

   </form>
</body>
</html>


