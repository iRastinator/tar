<?php

//var_dump($_GET);

// Функция для получения состояния GPIO через pigpio
function getGpioStates() {
    $result = array();
    
    // Проверяем все возможные GPIO пины (0-53)
    for ($gpio = 0; $gpio <= 53; $gpio++) {
        // Получаем режим GPIO
        $mode_output = shell_exec("pigs mg " . $gpio . " 2>/dev/null");
        $mode = trim($mode_output);
        
        // Если команда вернула результат
        if ($mode !== '' && !strpos($mode, 'error')) {
            if ($mode == '0') {
                $result[$gpio] = 0;  // INPUT
            } elseif ($mode == '1') {
                $result[$gpio] = 1;  // OUTPUT
            }
            // Другие режимы игнорируем
        }
    }
    
    return $result;
}

$result = getGpioStates();

$ifo_gpio = array(
    "ch1-1" => 10, "ch2-1" => 6,
    "ch1-2" => 9,  "ch2-2" => 12,
    "ch1-3" => 25, "ch2-3" => 13, 
    "ch1-4" => 11, "ch2-4" => 19,
    "ch1-5" => 8,  "ch2-5" => 16,
    "ch1-6" => 7,  "ch2-6" => 26,
    "ch1-7" => 5,  "ch2-7" => 20
);

// Создаем новый массив с состояниями каналов
$new_array = array();
foreach($ifo_gpio as $key => $value) {
    $new_array[$key] = isset($result[$value]) ? $result[$value] : -1; // -1 если GPIO не найден
}

// Обработка команд
if (isset($_GET['param']) && isset($_GET['param2'])) {
    $channel = 'ch' . $_GET['param2'] . "-" . $_GET['param'];
    
    if (isset($ifo_gpio[$channel])) {
        $gpio_pin = $ifo_gpio[$channel];
        
        // Для каналов 1 и 2 - переключение состояния
        if ((int)$_GET['param2'] <= 2) {
            if (isset($new_array[$channel])) {
                // Получаем текущее состояние пина
                $current_level = shell_exec("pigs r " . $gpio_pin . " 2>/dev/null");
                $current_level = trim($current_level);
                
                if ($current_level === '0') {
                    // Если LOW - устанавливаем OUTPUT и HIGH
                    $cmd1 = "pigs m " . $gpio_pin . " w";  // режим OUTPUT
                    $cmd2 = "pigs w " . $gpio_pin . " 1";  // установка HIGH
                    shell_exec($cmd1);
                    shell_exec($cmd2);
                } elseif ($current_level === '1') {
                    // Если HIGH - устанавливаем LOW
                    $cmd = "pigs w " . $gpio_pin . " 0";  // установка LOW
                    shell_exec($cmd);
                } else {
                    // Если состояние неизвестно, переключаем режим
                    if ($new_array[$channel] == 0) {
                        $cmd1 = "pigs m " . $gpio_pin . " w";
                        $cmd2 = "pigs w " . $gpio_pin . " 1";
                        shell_exec($cmd1);
                        shell_exec($cmd2);
                    } else {
                        $cmd = "pigs w " . $gpio_pin . " 0";
                        shell_exec($cmd);
                    }
                }
            }
        } 
        // Для каналов > 2 - прямое управление с параметром
        else {
            if (isset($_GET['param3'])) {
                $value = (int)$_GET['param3'];
                
                if ($value == 0 || $value == 1) {
                    // Устанавливаем режим OUTPUT
                    $cmd1 = "pigs m " . $gpio_pin . " w";
                    shell_exec($cmd1);
                    
                    // Устанавливаем значение
                    $cmd2 = "pigs w " . $gpio_pin . " " . $value;
                    shell_exec($cmd2);
                }
            }
        }
    }
}

// Дополнительные функции для работы с GPIO
function getGpioMode($pin) {
    $output = shell_exec("pigs mg " . $pin . " 2>/dev/null");
    return trim($output);
}

function getGpioLevel($pin) {
    $output = shell_exec("pigs r " . $pin . " 2>/dev/null");
    return trim($output);
}

function setGpioMode($pin, $mode) {
    // 0 = INPUT, 1 = OUTPUT
    $cmd = "pigs m " . $pin . " " . $mode;
    return shell_exec($cmd);
}

function setGpioLevel($pin, $level) {
    // 0 = LOW, 1 = HIGH
    $cmd = "pigs w " . $pin . " " . $level;
    return shell_exec($cmd);
}

?>