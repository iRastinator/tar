<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8" />
	<title>Rastinator</title>

	<style>
		@import "../style.css"screen;
		/* ????? ??? ?????? ?????????? ?? ??????? */
		@import "../style.css"print, handheld;
		/* ????? ??? ?????? ? ????????? */

		body {
			height: 100%;
			margin: 0;
			display: flex;
			align-items: center;
			justify-content: center;
		
		}

		.settings_palel {
			text-align: center;
			width: 40%;
			position: absolute;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -50%);
		}

		#indicator {
			height: 20px;
			background-color: #575757;
			animation: progress-bar 60s linear forwards;
		}

		/* ???????? ?????????? */
		@keyframes progress-bar {
			0% {
				width: 0%;
			}

			100% {
				width: 100%;
			}
		}

	</style>

</head>

<body>
	<div class="background-svg"></div>


<?php
	


	
	if(isset($_GET['stop_calibration'])) 
	{
		
		$comand = 'curl "127.0.0.1:8080/json.htm?type=command&param=updateuservariable&vname=Stop_flag&vtype=2&vvalue=0"';
		$output = shell_exec($comand);
 	 	
		echo '<html>
				<body onload="document.frm1.submit()">
				   <form action="calibration.php" name="frm1" method="POST">

				   </form>
				</body>
				</html>';

		exit();
	}


?>
