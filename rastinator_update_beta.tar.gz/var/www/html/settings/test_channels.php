<!DOCTYPE html>
<html>
<head>
   <meta name = "viewport" content = "width=device-width, initial-scale=1">
    <meta charset="utf-8" />
    <title>Rastinator</title>
<script type="text/javascript" src="/ajax/jquery-3.7.0.min.js"></script>
<style>
         @import "../style.css" screen; /* Стиль для вывода результата на монитор */
         @import "../style.css" print, handheld; /* Стиль для печати и смартфона */
    
                    *{
    padding: 0%;
    margin: 0%;
            }
            .container{
            grid-template-columns: auto;
            display: grid;
            
    
          }
          
          .item {
              
              padding: 0px;
              border: 0px solid black;
                        
            }


    
</style>      
          
</head>

<body>


<?php
	
//var_dump($_POST);	//exit();
//Авторизация
include('../login/in.php');    
    
function debug_to_console($data) {
    $output = $data;
    if (is_array($output))
        $output = implode(',', $output);
    echo "<script>console.log('Debug Objects: " . $output . "' );</script>";
}    
?>
    
    
    
<div class="container">

<!-- Верхнее меню -->     
<div class="item item_1">
        <ul>
			<li><svg width="clamp(6.25rem, 3.977rem + 11.36vw, 12.5rem)" height="clamp(1rem, 0.786rem + 2.29vw, 2.5rem)" viewBox="150 -30 180 180"> <?php include('../pic/Rastinator.svg'); ?> </svg> </li>
          <li><a href="../poliv/index.php" >Полив</a></li>    
          <li><a href="../climat/index.php">Климат</a></li>
          <li><a href="../sensors/index.php">Датчики</a></li>
          <li><a class="active" >Настройки</a></li>
          <li><a href="../plant_profiles/index.php">Профили</a></li>
          <li><a href="../log_poliva/index.php">Журнал полива</a></li>
          <li><a href="../log_domoticz/index.php">Лог системы</a></li>

        </ul>  
    

    
</div>              

<!-- Информационная панель - отображение данных лога -->     
	
		<div class="item item_2">
			<script type="text/javascript">
				$(document).ready(function() {
					var updateInfo = function() {
						$.ajax({
							url: '../log/log.php',
							cache: false, // Предотвращаем кэширование запроса
							success: function(response) {
								var trimmedResponse = response.trim();
								// Проверка наличия времени в формате HH:MM
								if (/(\b[01]?[0-9]:[0-5][0-9]\b|\b2[0-3]:[0-5][0-9]\b)/.test(trimmedResponse)) {
									$("#info").css("color", ""); // Сброс цвета
									$(".info_climat").css("color", ""); // Сброс цвета для классов
									$("#info").html(trimmedResponse); // Обновление содержимого
								} else {
									$("#info").css("color", "gray"); // Окрашивание в серый цвет
									$(".info_climat").css("color", "gray"); // Окрашивание в серый цвет для классов
									// Не обновляем содержимое
								}
							},
							error: function() {
								console.error("Ошибка при загрузке данных из log.php");
							}
						});
					};

					var updateInfoBar = function() {
						$("#info_bar").load('../log/log_bar.php');
					};

					setInterval(updateInfo, 2000);
					setInterval(updateInfoBar, 2000);
				});
			</script>

			<div id="info_bar">
				<?php include('../log/log_bar.php'); ?>
			</div>

			<div id="info">
				<?php include('../log/log.php'); ?>
			</div>
		</div>  
    
      
    
    
<!-- item item_4 - Кнопки  -  ----------> 
<div class="item item_3">
    
                                                  


<div class="btn-group">

	<a class="btn_pag"  href="index.php" >Вернуться в настройки</a> 
	
  
</div> 
    
 

</div> 

    
    
<!--   -->
<div class="item item_4">

	
   
	
	<!-- включение насосов --->
	<div class="settings_palel">
		 	<p class="settins_label">Тестовое включение каналов</p>
		<label for="inputParam" >Выбор канала</label>
		<!---  <input class="input_calibration" type="text" id="inputParam" value="1" >   --->
		<select id="inputParam">
		   <option value="1">Ch1</option>
		   <option value="2">Ch2</option>
		   <option value="3">Ch3</option>
		   <option value="4">Ch4</option>
		</select>
		<!-- Этот скрипт получает параметры из GET-запроса при загрузке страницы, извлекает значение параметра 'param' и устанавливает его в выбранном элементе селекта, если такой параметр присутствует в адресной строке. При изменении выбора в селекте также будет отправляться GET-запрос на test_channels.php с обновленным параметром 'param'. -->
		<script> 
			document.addEventListener('DOMContentLoaded', function() {
			  var select = document.getElementById('inputParam');
			  var urlParams = new URLSearchParams(window.location.search); // Получение параметров из GET запроса
			  var selectedValue = urlParams.get('param'); // Получение значения параметра 'param' из GET запроса
			  if(selectedValue !== null) {
				select.value = selectedValue; // Установка выбранного значения в селекте
			  }

			  select.addEventListener('change', function() {
				var selectedValue = select.value;
				window.location.href = 'test_channels.php?param=' + selectedValue;
			  });
			});
		</script>

		<br>
		<br>
<?php
		$cmd = '/home/pi/bin/show_gpio';
		$text = shell_exec($cmd);
		//Этот код извлечет числа после слова "GPIO" в качестве ключей массива и определит значение для каждого ключа на основе значения "func". Строки, где "func" имеет значения отличные от "INPUT" и "OUTPUT", не будут включены в итоговый массив.
		$matches = array();
		preg_match_all("/GPIO (\d+):.*func=(\w+)/", $text, $matches, PREG_SET_ORDER);
		$result = array();
		foreach($matches as $match) {
			if ($match[2] == 'INPUT') {
				$result[$match[1]] = 0;
			} elseif ($match[2] == 'OUTPUT') {
				$result[$match[1]] = 1;
			}
		}

		$ifo_gpio = array(
							"ch1-1" => 10, "ch2-1" => 6,
							"ch1-2" => 9,  "ch2-2" => 12,
							"ch1-3" => 25, "ch2-3" => 13, 
							"ch1-4" => 11, "ch2-4" => 19,
							"ch1-5" => 8,  "ch2-5" => 16,
							"ch1-6" => 7,  "ch2-6" => 26,
							"ch1-7" => 5,  "ch2-7" => 20
						 );
		
		//Этот код создаст новый массив, используя ключи из $ifo_gpio и их соответствующие значения из первого массива. Ключи из $ifo_gpio будут использоваться для нового массива, а их значения из первого массива будут присвоены ключам в новом массиве.
		$new_array = array();
		foreach($ifo_gpio as $key => $value) {
			$new_array[$key] = $result[$value];
		}
		//print_r($new_array); // Вывод результирующего массива
		
		
?>


		
<?php
  
		
	for ($n = 1; $n <= 7; $n++) 
	{

				$ch = 'ch'.$_GET['param'].'-'.$n;
				//если страница грузится первый раз
				if ($_GET['param'] == '') {$ch= 'ch1-'.$n;}

				if($new_array[$ch] == 0) {
				  $style= 'button_text';
				}
				if($new_array[$ch] == 1) {
				  $style= 'button_text_orange';
				}

			

			echo '
			  <button class="'.$style.'" id="executeCommand' . $n . '">'.$ch.'</button>
			  <script>
				document.addEventListener(\'DOMContentLoaded\', function() {
				  var button = document.getElementById(\'executeCommand' . $n .'\');

				 button.addEventListener(\'click\', function() {
				 ';
		  	if ((int)$_GET['param'] < 3)
			{echo'
					if (button.classList.contains(\'button_text\')) {
					   button.classList.remove(\'button_text\');
					  button.classList.add(\'button_text_orange\');
					} else {
					  button.classList.remove(\'button_text_orange\');
					  button.classList.add(\'button_text\');
					}
				';}
			  echo 'var parameterValue = \'' . $n . '\';
					var parameterValue2 = document.getElementById(\'inputParam\').value;
					//нужен для кнопок ch3...
					var parameterValue3 = \'' . '1' . '\';

					var xhr = new XMLHttpRequest();
					xhr.onreadystatechange = function() {
					  if (xhr.readyState === XMLHttpRequest.DONE) {
						if (xhr.status === 200) {
						  document.getElementById(\'dataDisplay\').innerHTML = xhr.responseText;
						} else {
						  console.error(\'Произошла ошибка при выполнении запроса\');
						}
					  }
					};
					var url = \'run_channels.php?param=\' + parameterValue + \'&param2=\' + parameterValue2 + \'&param3=\' + parameterValue3;
					xhr.open(\'GET\', url, true);
					xhr.send();
				  });


				});
			  </script>
			 ';
	}	
		
	echo '<br> <br>';	


if ((int)$_GET['param'] > 2)
{ 		
	for ($n = 1; $n <= 7; $n++) 
	{

				$ch = 'ch'.$_GET['param'].'-'.$n;
				//если страница грузится первый раз
				if ($_GET['param'] == '') {$ch= 'ch1-'.$n;}

				if($new_array[$ch] == 0) {
				  $style= 'button_text_orange';
				}
				if($new_array[$ch] == 1) {
				  $style= 'button_text';
				}


			echo '
			  <button class="button_text_dark" id="executeCommand_off' . $n . '">'.$ch.'</button>
			  <script>
				document.addEventListener(\'DOMContentLoaded\', function() {
				  var button = document.getElementById(\'executeCommand_off' . $n .'\');

				 button.addEventListener(\'click\', function() {

					var parameterValue = \'' . $n . '\';
					var parameterValue2 = document.getElementById(\'inputParam\').value;
					var parameterValue3 = \'' . '0' . '\';

					var xhr = new XMLHttpRequest();
					xhr.onreadystatechange = function() {
					  if (xhr.readyState === XMLHttpRequest.DONE) {
						if (xhr.status === 200) {
						  document.getElementById(\'dataDisplay\').innerHTML = xhr.responseText;
						} else {
						  console.error(\'Произошла ошибка при выполнении запроса\');
						}
					  }
					};
					var url = \'run_channels.php?param=\' + parameterValue + \'&param2=\' + parameterValue2 + \'&param3=\' + parameterValue3;
					xhr.open(\'GET\', url, true);
					xhr.send();
				  });


				});
			  </script>';
		

	}	
		
		echo '<br> <br> Для этих каналов нет информации о их состоянии, вы можете послать команду на включение или выключение, верхний ряд кнопок - включает, нижний ряд - выключает ';		
}
?>

		


		<div id="dataDisplay"></div>	
	
	</div>

</div>

    
    
  </body>
</html>
