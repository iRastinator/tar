<?php //git_start  -2
session_start();

// Конфигурация
define('SERVER_URL', 'https://rastinator.ru/?action=server_download');
define('BACKUP_DIR', dirname(__DIR__) . '/backup');
define('CLIENT_NAME', 'mini-server-' . gethostname());
define('TIMEOUT', 300); // 5 минут

// Убедимся, что папка backup существует
if (!is_dir(BACKUP_DIR)) {
    mkdir(BACKUP_DIR, 0755, true);
}

// Функция для логирования на странице
function addLog($message, $type = 'info') {
    if (!isset($_SESSION['logs'])) {
        $_SESSION['logs'] = [];
    }
    $_SESSION['logs'][] = [
        'time' => date('H:i:s'),
        'message' => $message,
        'type' => $type
    ];
}

// Функция для получения реального IP клиента
function getClientIP() {
    $ip_keys = ['HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR'];
    foreach ($ip_keys as $key) {
        if (array_key_exists($key, $_SERVER) === true) {
            foreach (explode(',', $_SERVER[$key]) as $ip) {
                $ip = trim($ip);
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
    }
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

// Функция для выполнения запросов к серверу
function makeRequest($url, $method = 'GET', $data = null, $headers = []) {
    $ch = curl_init();
    
    $default_headers = [
        'X-Client-Name: ' . CLIENT_NAME,
        'X-Client-IP: ' . getClientIP(),
        'User-Agent: MiniServerDownloader/2.0'
    ];
    
    $all_headers = array_merge($default_headers, $headers);
    
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HEADER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_TIMEOUT => TIMEOUT,
        CURLOPT_HTTPHEADER => $all_headers,
        CURLINFO_HEADER_OUT => true
    ]);
    
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        if ($data) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
            $all_headers[] = 'Content-Type: application/x-www-form-urlencoded';
            curl_setopt($ch, CURLOPT_HTTPHEADER, $all_headers);
        }
    }
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    $error = curl_error($ch);
    $info = curl_getinfo($ch);
    
    curl_close($ch);
    
    return [
        'success' => $http_code >= 200 && $http_code < 300,
        'http_code' => $http_code,
        'headers' => substr($response, 0, $header_size),
        'body' => substr($response, $header_size),
        'error' => $error,
        'info' => $info
    ];
}

// Основная логика обработки формы
$result = null;
$download_info = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'])) {
    // Очищаем старые логи
    $_SESSION['logs'] = [];
    
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $build_type = $_POST['build_type'] ?? 'stable';
    
    addLog("Начинаем процесс скачивания для пользователя: $username");
    addLog("Тип сборки: " . ($build_type === 'beta' ? 'Тестовая (Beta)' : 'Стабильная (Stable)'));
    addLog("Клиент: " . CLIENT_NAME . ", IP: " . getClientIP());
    
    try {
        // Шаг 1: Получение токена
        addLog("Шаг 1: Получение токена доступа...");
        
        $response = makeRequest(SERVER_URL, 'POST', [
            'username' => $username,
            'password' => $password,
            'build_type' => $build_type
        ]);
        
        addLog("HTTP код: " . $response['http_code']);
        addLog("Размер ответа: " . strlen($response['body']) . " байт");
        
        if ($response['error']) {
            throw new Exception("Ошибка сети: " . $response['error']);
        }
        
        if (!$response['success']) {
            $json = @json_decode($response['body'], true);
            $error_msg = $json['message'] ?? 'Неизвестная ошибка сервера';
            throw new Exception("Ошибка сервера ($http_code): " . $error_msg);
        }
        
        $json = @json_decode($response['body'], true);
        
        if (!$json || !isset($json['success']) || !$json['success']) {
            throw new Exception("Неверный формат ответа от сервера");
        }
        
        $token = $json['data']['token'];
        $file_info = $json['data']['file_info'];
        $download_url = $json['data']['download_url'];
        $build_type = $file_info['build_type'] ?? $build_type;
        
        addLog("✓ Токен получен: " . substr($token, 0, 16) . "...");
        addLog("Файл: " . $file_info['name'] . ", размер: " . 
               ($file_info['size'] > 0 ? formatBytes($file_info['size']) : 'неизвестно'));
        addLog("Тип сборки в ответе: " . ($build_type === 'beta' ? 'Тестовая' : 'Стабильная'));
        
        // Шаг 2: Скачивание файла на сервер
        addLog("Шаг 2: Скачивание файла на мини-сервер...");
        
        // Генерируем имя файла в зависимости от типа сборки
        $backup_filename = ($build_type === 'beta') ? 'rastinator_update_beta.tar.gz' : 'rastinator_update.tar.gz';
        $backup_path = BACKUP_DIR . '/' . $backup_filename;
        
        addLog("Целевой путь: " . $backup_path);
        
        // Открываем файл для записи
        $fp = fopen($backup_path, 'w+');
        if (!$fp) {
            throw new Exception("Не удалось создать файл: " . $backup_path);
        }
        
        // Настраиваем cURL для скачивания
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $download_url,
            CURLOPT_FILE => $fp,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_TIMEOUT => TIMEOUT,
            CURLOPT_HTTPHEADER => [
                'X-Client-Name: ' . CLIENT_NAME,
                'X-Client-IP: ' . getClientIP()
            ],
            CURLOPT_NOPROGRESS => false,
            CURLOPT_PROGRESSFUNCTION => function($resource, $download_size, $downloaded, $upload_size, $uploaded) {
                static $last_progress = 0;
                if ($download_size > 0) {
                    $progress = ($downloaded / $download_size) * 100;
                    if ($progress - $last_progress >= 10) { // Каждые 10%
                        addLog("Прогресс: " . round($progress, 1) . "% (" . 
                               formatBytes($downloaded) . " / " . formatBytes($download_size) . ")");
                        $last_progress = floor($progress / 10) * 10;
                    }
                }
                return 0;
            }
        ]);
        
        addLog("Начинаем загрузку...");
        $start_time = microtime(true);
        
        $result = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        $downloaded_bytes = curl_getinfo($ch, CURLINFO_SIZE_DOWNLOAD);
        
        curl_close($ch);
        fclose($fp);
        
        $download_time = microtime(true) - $start_time;
        
        if ($error || $http_code !== 200) {
            @unlink($backup_path);
            throw new Exception("Ошибка скачивания ($http_code): " . $error);
        }
        
        // Проверяем размер файла
        $actual_size = filesize($backup_path);
        $expected_size = $file_info['size'];
        
        addLog("✓ Файл скачан успешно!");
        addLog("Время: " . round($download_time, 2) . " сек");
        addLog("Скорость: " . formatBytes($downloaded_bytes / $download_time) . "/сек");
        addLog("Размер: " . formatBytes($actual_size) . 
               ($expected_size > 0 ? " (ожидалось: " . formatBytes($expected_size) . ")" : ""));
        
        if ($expected_size > 0 && $actual_size != $expected_size) {
            addLog("⚠ Внимание: размер файла отличается от ожидаемого!", 'warning');
        }
        
        // Проверяем, что файл не пустой и не поврежден
        if ($actual_size === 0) {
            @unlink($backup_path);
            throw new Exception("Файл скачан, но его размер 0 байт");
        }
        
        // Проверяем сигнатуру файла (если это gzip)
        $fp = fopen($backup_path, 'rb');
        $header = fread($fp, 4);
        fclose($fp);
        
        if (bin2hex($header) === '1f8b0800' || bin2hex($header) === '1f8b0808') {
            addLog("✓ Файл является валидным gzip архивом");
        }
        
        // Формируем результат
        $download_info = [
            'success' => true,
            'filename' => $backup_filename,
            'path' => $backup_path,
            'size' => $actual_size,
            'expected_size' => $expected_size,
            'build_type' => $build_type,
            'download_time' => round($download_time, 2),
            'speed' => round($downloaded_bytes / $download_time / 1024, 2),
            'token' => $token,
            'timestamp' => date('Y-m-d H:i:s')
        ];
        
        addLog("✓ Файл сохранен в: " . $backup_path, 'success');
        addLog("=== СКАЧИВАНИЕ УСПЕШНО ЗАВЕРШЕНО ===", 'success');
        
    } catch (Exception $e) {
        addLog("❌ ОШИБКА: " . $e->getMessage(), 'error');
        $result = [
            'success' => false,
            'error' => $e->getMessage(),
            'timestamp' => date('Y-m-d H:i:s')
        ];
    }
}

// Вспомогательная функция для форматирования размера
function formatBytes($bytes, $precision = 2) {
    $units = ['Б', 'КБ', 'МБ', 'ГБ', 'ТБ'];
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    $bytes /= pow(1024, $pow);
    return round($bytes, $precision) . ' ' . $units[$pow];
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Скачивание файла на сервер</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #1a2980 0%, #26d0ce 100%);
            min-height: 100vh;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        
        .container {
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            width: 100%;
            max-width: 900px;
            overflow: hidden;
        }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 25px 30px;
            position: relative;
        }
        
        .header h1 {
            font-size: 28px;
            margin-bottom: 5px;
        }
        
        .header .subtitle {
            opacity: 0.9;
            font-size: 14px;
        }
        
        .server-info {
            background: rgba(255,255,255,0.1);
            padding: 10px 15px;
            border-radius: 8px;
            margin-top: 15px;
            font-size: 13px;
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .server-info span {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .content {
            padding: 30px;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
        }
        
        @media (max-width: 768px) {
            .content {
                grid-template-columns: 1fr;
            }
        }
        
        .form-section {
            border-right: 1px solid #eee;
            padding-right: 30px;
        }
        
        @media (max-width: 768px) {
            .form-section {
                border-right: none;
                padding-right: 0;
                border-bottom: 1px solid #eee;
                padding-bottom: 30px;
            }
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
            font-size: 14px;
        }
        
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 14px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 16px;
            transition: all 0.3s;
            background: white;
        }
        
        .form-group input:focus,
        .form-group select:focus {
            border-color: #667eea;
            outline: none;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        .btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            padding: 16px 30px;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            width: 100%;
            margin-top: 10px;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
        }
        
        .btn:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.3);
        }
        
        .btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }
        
        .logs-section {
            max-height: 500px;
            overflow-y: auto;
        }
        
        .logs-section h3 {
            margin-bottom: 15px;
            color: #333;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .log-container {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
            max-height: 400px;
            overflow-y: auto;
            font-family: 'Courier New', monospace;
            font-size: 13px;
            line-height: 1.5;
        }
        
        .log-entry {
            padding: 8px 10px;
            margin-bottom: 6px;
            border-radius: 4px;
            border-left: 4px solid #ddd;
            background: white;
            animation: fadeIn 0.3s;
        }
        
        .log-entry.info {
            border-left-color: #3498db;
        }
        
        .log-entry.success {
            border-left-color: #2ecc71;
            background: #e8f6f3;
        }
        
        .log-entry.warning {
            border-left-color: #f39c12;
            background: #fff8e1;
        }
        
        .log-entry.error {
            border-left-color: #e74c3c;
            background: #ffebee;
        }
        
        .log-time {
            color: #666;
            font-weight: bold;
            margin-right: 10px;
        }
        
        .result-card {
            background: #e8f6f3;
            border-radius: 10px;
            padding: 20px;
            margin-top: 20px;
            border: 2px solid #2ecc71;
            animation: slideIn 0.5s;
        }
        
        .result-card h4 {
            color: #27ae60;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .result-item {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px dashed #b2dfdb;
        }
        
        .result-item:last-child {
            border-bottom: none;
        }
        
        .result-label {
            color: #555;
            font-weight: 500;
        }
        
        .result-value {
            color: #2c3e50;
            font-weight: 600;
        }
        
        .backup-info {
            background: #e3f2fd;
            border-radius: 8px;
            padding: 15px;
            margin-top: 20px;
            border-left: 4px solid #2196f3;
            font-size: 14px;
        }
        
        .build-type-stable {
            color: #27ae60;
            font-weight: 600;
        }
        
        .build-type-beta {
            color: #2980b9;
            font-weight: 600;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(5px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        @keyframes slideIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .spinner {
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255,255,255,0.3);
            border-radius: 50%;
            border-top-color: white;
            animation: spin 1s ease-in-out infinite;
            display: inline-block;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔄 Скачивание файла на сервер</h1>
            <p class="subtitle">Выберите тип сборки и файл будет сохранен в папку ../backup/ на этом сервере</p>
            
            <div class="server-info">
                <span>🖥️ Сервер: <?php echo CLIENT_NAME; ?></span>
                <span>📁 Папка бекапа: <?php echo realpath(BACKUP_DIR); ?></span>
                <span>🌐 Основной сервер: <?php echo parse_url(SERVER_URL, PHP_URL_HOST); ?></span>
            </div>
        </div>
        
        <div class="content">
            <div class="form-section">
                <h3>🔐 Авторизация и выбор сборки</h3>
                
                <form method="POST" id="downloadForm" onsubmit="return startDownload()">
                    <div class="form-group">
                        <label for="username">Логин покупателя:</label>
                        <input type="text" id="username" name="username" 
                               placeholder="Введите логин от WordPress" required
                               value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Пароль:</label>
                        <input type="password" id="password" name="password" 
                               placeholder="Введите пароль" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="build_type">Тип сборки:</label>
                        <select id="build_type" name="build_type" required>
                            <option value="stable" <?php echo (isset($_POST['build_type']) && $_POST['build_type'] === 'stable') ? 'selected' : ''; ?>>Стабильная (Stable)</option>
                            <option value="beta" <?php echo (isset($_POST['build_type']) && $_POST['build_type'] === 'beta') ? 'selected' : ''; ?>>Тестовая (Beta)</option>
                        </select>
                        <p style="font-size: 12px; color: #666; margin-top: 5px;">
                            <strong>Стабильная:</strong> rastinator_update.tar.gz<br>
                            <strong>Тестовая:</strong> rastinator_update_beta.tar.gz
                        </p>
                    </div>
                    
                    <button type="submit" id="submitBtn" class="btn">
                        <span id="btnText">📥 Начать скачивание на сервер</span>
                        <span id="btnSpinner" class="spinner" style="display: none;"></span>
                    </button>
                </form>
                
                <div class="backup-info">
                    <strong>ℹ️ Информация:</strong>
                    <ul style="margin-top: 10px; padding-left: 20px;">
                        <li>Файл скачивается <strong>на этот сервер</strong>, а не в браузер</li>
                        <li>Путь сохранения: <code><?php echo realpath(BACKUP_DIR); ?></code></li>
                        <li>Стабильная сборка: <code>rastinator_update.tar.gz</code></li>
                        <li>Тестовая сборка: <code>rastinator_update_beta.tar.gz</code></li>
                        <li>Используется безопасное соединение (HTTPS)</li>
                        <li>Токен доступа действителен 5 минут</li>
                        <li>Все операции логируются в таблицу WordPress</li>
                    </ul>
                </div>
                
                <?php if (isset($download_info) && $download_info['success']): ?>
                <div class="result-card">
                    <h4>✅ Файл успешно скачан!</h4>
                    
                    <div class="result-item">
                        <span class="result-label">Тип сборки:</span>
                        <span class="result-value build-type-<?php echo $download_info['build_type']; ?>">
                            <?php echo $download_info['build_type'] === 'beta' ? 'Тестовая (Beta)' : 'Стабильная (Stable)'; ?>
                        </span>
                    </div>
                    
                    <div class="result-item">
                        <span class="result-label">Имя файла:</span>
                        <span class="result-value"><?php echo htmlspecialchars($download_info['filename']); ?></span>
                    </div>
                    
                    <div class="result-item">
                        <span class="result-label">Полный путь:</span>
                        <span class="result-value" title="<?php echo htmlspecialchars($download_info['path']); ?>">
                            <?php echo htmlspecialchars(dirname($download_info['path'])) . '/<br><strong>' . 
                                   htmlspecialchars(basename($download_info['path'])) . '</strong>'; ?>
                        </span>
                    </div>
                    
                    <div class="result-item">
                        <span class="result-label">Размер:</span>
                        <span class="result-value"><?php echo formatBytes($download_info['size']); ?></span>
                    </div>
                    
                    <div class="result-item">
                        <span class="result-label">Время скачивания:</span>
                        <span class="result-value"><?php echo $download_info['download_time']; ?> сек</span>
                    </div>
                    
                    <div class="result-item">
                        <span class="result-label">Средняя скорость:</span>
                        <span class="result-value"><?php echo $download_info['speed']; ?> КБ/сек</span>
                    </div>
                    
                    <div class="result-item">
                        <span class="result-label">Время завершения:</span>
                        <span class="result-value"><?php echo $download_info['timestamp']; ?></span>
                    </div>
                    
                    <div style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #b2dfdb;">
                        <p><strong>🎯 Файл готов для обработки!</strong></p>
                        <p style="font-size: 13px; color: #666; margin-top: 5px;">
                            Теперь вы можете использовать этот файл в своих скриптах обработки.
                        </p>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="logs-section">
                <h3>📊 Журнал операций</h3>
                
                <div class="log-container" id="logContainer">
                    <?php if (!empty($_SESSION['logs'])): ?>
                        <?php foreach ($_SESSION['logs'] as $log): ?>
                            <div class="log-entry <?php echo $log['type']; ?>">
                                <span class="log-time">[<?php echo $log['time']; ?>]</span>
                                <?php echo htmlspecialchars($log['message']); ?>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="log-entry info">
                            <span class="log-time">[<?php echo date('H:i:s'); ?>]</span>
                            Готов к работе. Введите логин, пароль и выберите тип сборки.
                        </div>
                    <?php endif; ?>
                </div>
                
                <?php if (!empty($_SESSION['logs'])): ?>
                    <div style="margin-top: 15px; text-align: center;">
                        <button class="btn" style="background: #95a5a6; padding: 10px 20px; width: auto;" 
                                onclick="clearLogs()">Очистить журнал</button>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script>
        function startDownload() {
            const btn = document.getElementById('submitBtn');
            const btnText = document.getElementById('btnText');
            const spinner = document.getElementById('btnSpinner');
            
            btn.disabled = true;
            btnText.textContent = 'Скачивание на сервер...';
            spinner.style.display = 'inline-block';
            
            // Автопрокрутка логов
            const logContainer = document.getElementById('logContainer');
            if (logContainer) {
                setTimeout(() => {
                    logContainer.scrollTop = logContainer.scrollHeight;
                }, 100);
            }
            
            return true;
        }
        
        function clearLogs() {
            if (confirm('Очистить журнал операций?')) {
                fetch('?clear_logs=1', { method: 'POST' })
                    .then(() => location.reload());
            }
        }
        
        // Автопрокрутка логов при новых записях
        function scrollLogs() {
            const logContainer = document.getElementById('logContainer');
            if (logContainer) {
                logContainer.scrollTop = logContainer.scrollHeight;
            }
        }
        
        // Периодическая проверка
        setInterval(scrollLogs, 1000);
        
        // Фокус на поле логина
        document.getElementById('username')?.focus();
    </script>
    
    <?php
    // Обработка очистки логов
    if (isset($_POST['clear_logs'])) {
        unset($_SESSION['logs']);
    }
    ?>
</body>
</html>