<?php

// Получаем значение переменной version из параметров запроса (например, из URL)
$version = $_GET['version'] ; // Устанавливаем по умолчанию 'stable'

// Определяем URL для получения информации о версии на основе параметра
if ($version === 'test') {
    $fileUrl = 'https://github.com/iRastinator/tar/raw/main/rastinator_update_beta.tar.gz'; // Если beta
} else {
    $fileUrl = 'https://github.com/iRastinator/tar/raw/main/rastinator_update.tar.gz'; // Если stable
}


$savePath = '../backup/rastinator_update.tar.gz';

if (copy($fileUrl, $savePath)) {
    echo 'Файл успешно скачан';
	$comand = 'sudo tar xPf /var/www/html/backup/rastinator_update.tar.gz -C /';
	$output = shell_exec($comand); 
	
	 //Меняем права и пользователей
    $comand = 'sudo chown -R pi:www-data /var/www/html/';
    $output = shell_exec($comand);
    $comand = 'sudo chmod -R 770 /var/www/html/';
    $output = shell_exec($comand);
      
    
    // тоже для /home/pi/domoticz/scripts/lua
    $comand = 'sudo /bin/chown -R pi:www-data /home/pi/domoticz/scripts/lua';
    $output = shell_exec($comand);
    $comand = 'sudo /bin/chmod -R 770 /home/pi/domoticz/scripts/lua';
    $output = shell_exec($comand);
      
	  
    // тоже для /home/pi/bin/
    $comand = 'sudo /bin/chown -R pi:www-data /home/pi/bin';
    $output = shell_exec($comand);
    $comand = 'sudo /bin/chmod -R 770 /home/pi/bin';
    $output = shell_exec($comand);
	

	    
	//Запуск скрипта после установки и 
	$comand = 'sudo /home/pi/bin/to_run';
    $output = shell_exec($comand);

	
	
} else {
    echo 'Ошибка при скачивании файла';
}



// Перенаправление на ту же страницу после выполнения скрипта
header("Location: index.php");
exit;
?>
   
