<?php

// Получаем значение переменной version из параметров запроса (например, из URL)
$version = $_GET['version'] ; // Устанавливаем по умолчанию 'stable'

// Определяем URL для получения информации о версии на основе параметра
if ($version === 'test') {
    $fileUrl = 'https://github.com/iRastinator/tar/raw/main/rastinator_update_beta.tar.gz'; // Если beta
} else {
    $fileUrl = 'https://github.com/iRastinator/tar/raw/main/rastinator_update.tar.gz'; // Если stable
}


$savePath = '../backup/rastinator_update.tar.gz';

if (copy($fileUrl, $savePath)) {
    echo 'Файл успешно скачан';
	$comand = 'sudo tar xPf /var/www/html/backup/rastinator_update.tar.gz -C /';
	$output = shell_exec($comand); 
	
	 //Меняем права и пользователей
    $comand = 'sudo chown -R pi:www-data /var/www/html/';
    $output = shell_exec($comand);
    $comand = 'sudo chmod -R 770 /var/www/html/';
    $output = shell_exec($comand);
      
    
    // тоже для /home/pi/domoticz/scripts/lua
    $comand = 'sudo /bin/chown -R pi:www-data /home/pi/domoticz/scripts/lua';
    $output = shell_exec($comand);
    $comand = 'sudo /bin/chmod -R 770 /home/pi/domoticz/scripts/lua';
    $output = shell_exec($comand);
      
	  
    // тоже для /home/pi/bin/
    $comand = 'sudo /bin/chown -R pi:www-data /home/pi/bin';
    $output = shell_exec($comand);
    $comand = 'sudo /bin/chmod -R 770 /home/pi/bin';
    $output = shell_exec($comand);

/*
	$directory = '/var/www/html/one_run_scrips/';

	// Проверяем существование директории
	if (!is_dir($directory)) {
		die("Директория не существует: $directory");
	}

	// Получаем список файлов, исключая . и ..
	$files = array_diff(scandir($directory), ['.', '..']);

	foreach ($files as $file) {
		$fullPath = $directory . $file;

		// Проверяем, является ли элемент файлом
		if (!is_file($fullPath)) {
			continue;
		}

		// Проверяем права на выполнение (опционально)
		if (!is_executable($fullPath)) {
			echo "Файл не исполняемый: $file\n";
			continue;
		}

		// Запускаем скрипт и получаем вывод
		$output = [];
		$returnCode = 0;
		exec(escapeshellarg($fullPath) . " 2>&1", $output, $returnCode);

		// Выводим результат
		echo "Скрипт: $file\n";
		echo "Код возврата: $returnCode\n";
		echo "Вывод:\n" . implode("\n", $output) . "\n\n";
	 }
*/
	
} else {
    echo 'Ошибка при скачивании файла';
}



// Перенаправление на ту же страницу после выполнения скрипта
header("Location: index.php");
exit;
?>
   
