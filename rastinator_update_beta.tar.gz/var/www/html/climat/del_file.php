<style>
	@import "../style.css" screen; /* Стиль для вывода результата на монитор */
    @import "../style.css" print, handheld; /* Стиль для печати и смартфона */

</style>                                    

<div style="Position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);">
	<?php include('../pic/process.svg'); ?> 
</div>

<?php
//var_dump ($_POST);exit;
$newname = '';

if(isset($_POST['del'])) {

    //Удаление загруженного

    $dir = '/home/pi/domoticz/scripts/lua/';
    $file = $_POST['del_file'];   

   // echo 'удаление ...'.$dir.$file; echo '<br>';

    //Удаление файла
    $comand = 'rm '.$dir.$file;
    $output = shell_exec($comand);

    $newname = "";
}




//Отключить скрипт - т.е. переименовать c добавкой off
if(isset($_POST['otkl']) and isset($_POST['del']) == false) {
    
    $dir = '/home/pi/domoticz/scripts/lua/';
    $file = $_POST['del_file'];
    
   

    $comand = 'grep -oP '."'".'sets_Canal_cooler\s*=\s*"\K[^"]+'."' ".$dir.$file;
    $output = shell_exec($comand);
    // отключаеи каналы скрипта
    $comand = 'bash /home/pi/bin/'.$output;
    shell_exec ($comand) ;
    
    
    $comand = 'grep -oP '."'".'sets_Canal_hoter\s*=\s*"\K[^"]+'."' ".$dir.$file;
    $output = shell_exec($comand);
    // отключаеи каналы скрипта
    $comand = 'bash /home/pi/bin/'.$output;
    shell_exec ($comand) ;
    
    $comand = 'grep -oP '."'".'sets_Canal_Co2\s*=\s*"\K[^"]+'."' ".$dir.$file;
    $output = shell_exec($comand);
    // отключаеи каналы скрипта
    $comand = 'bash /home/pi/bin/'.$output;
    shell_exec ($comand) ;
    
    //Переименование файла
    if (substr($file,0,4)!='off_'){
       // echo 'Переименование ...'.$dir.$file; echo '<br>';
        $newname = 'off_'.substr($file, 12);
        $comand = ' mv '.$dir.$file.' '.$dir.$newname;
        $output = shell_exec($comand);
        
        //var_dump($_POST); 
        

    }
  
}

//Включить скрипт - т.е. переименовать c без добавки off
if(isset($_POST['vkl'])) {

    $dir = '/home/pi/domoticz/scripts/lua/';
    $file = $_POST['del_file'];   
    if (substr($file,0,4) =='off_'){
        //echo 'Переименование ...'.$dir.$file; echo '<br>';
        //Переименование файла
        $newname = 'script_time_'.substr($file,4, strlen ($file));    
        $comand = ' mv '.$dir.$file.' '.$dir.$newname;
        $output = shell_exec($comand);    
            
    }
  
}















echo 
'
<html>
<body onload="document.frm1.submit()">
   <form action="index.php" name="frm1" method="POST">
      <input type="hidden" name="rast" value='.$newname.' >
   </form>
</body>
</html>

'


?>


