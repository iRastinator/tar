<style>
	@import "../style.css" screen; /* Стиль для вывода результата на монитор */
    @import "../style.css" print, handheld; /* Стиль для печати и смартфона */

</style>                                    

<div style="Position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);">
	<?php include('../pic/process.svg'); ?> 
</div>

<?php
                                      
//echo '</br>_POST=';
//var_dump($_POST);
//echo '</br>Button=';
//var_dump(isset($_POST['run_script']));
//exit();
    //var_dump($_POST['Name_unit_info']); exit();
    
//var_dump($_POST);
//var_dump($_POST['Name_unit']); exit();

// Если произошел сбой при отправкие формы  и последний проверочный input отсутствует - то выход.
if($_POST["cheсk"] != "check") { exit();}

$filename=''; // Имя файла для отправки в climat.php

function utf8_urldecode($str) 
    {$str = preg_replace("/%u([0-9a-f]{3,4})/i","&#x\\1;",urldecode($str));
     return html_entity_decode($str,null,'UTF-8');;
    }




// Если  сохранить изменения - удаляется старый файл и дальше генерится новой -----------------
// удаляем переменную для старого названия и создаем новую

if(isset($_POST['save_changes'])) 
{   
    
    $name_o = str_replace('/home/pi/domoticz/scripts/lua/script_time_climat', '', $_POST['origen_file']);
       
   // Если скрипт выключен    
    if (substr( $_POST['origen_file'], 0 , 40) == '/home/pi/domoticz/scripts/lua/off_climat_') {
     $name_o = str_replace('/home/pi/domoticz/scripts/lua/off_climat_', '', $_POST['origen_file']);   
         }
     
    $name_o = str_replace ('.lua', '' , $name_o);

    
    //Удаление файла скрипта
    $comand = ' rm '.$_POST['origen_file'];
    //echo $comand; 
    $output = shell_exec($comand);

}
    
//exit();





// Создание нового файла профиля растения ------------------------------------------------------
$query_string = "";
$key = "";
$value = "";
if (isset($_POST['save_changes']) || isset($_POST['new_porfile']) || isset($_POST['save_header'])) 
{  
       $set_value = array();
       $set_value_m = array();
       $set_value_s = array();
       $set_all = array();
       //$tmp = array();
       $label = array();
       $info = array();
    
        
    $filename = "script_time_climat_".$_POST[Name_unit].".lua";
    
// Проверка на существование файла и создание нового имени если файл есть
		$directory = "/home/pi/domoticz/scripts/lua/";

			// Проверяем, существует ли файл и добавляем `-N` к имени, если файл существует
		$baseName = $filename; // Сохраняем базовое имя без изменений
		$count = 1; // Инициализируем счетчик

		// Полный путь к файлу
		$filePath = $directory . $filename;

		// Проверка существования файла и создание нового имени, если файл есть
		while (file_exists($filePath)) {
			// Проверяем, есть ли суффикс -N
			if (preg_match('/-(\d+)\.lua$/', $filename, $matches)) {
				// Увеличиваем значение на 1
				$count = (int)$matches[1] + 1;
				// Убираем суффикс -N для основы
				$baseName = preg_replace('/-\d+\.lua$/', '', $filename);
			} else {
				// Если нет суффикса -N, начинаем с 1
				$baseName = pathinfo($filename, PATHINFO_FILENAME); // Получаем имя файла без расширения
				$count = 1; // Устанавливаем счетчик на 1 для -1
			}

			// Устанавливаем новое имя файла
			// Обновляем файл без расширения и добавляем новое имя
			$filename = $baseName . '-' . $count . '.lua';
			$filePath = $directory . $filename; // Обновляем полный путь к файлу
		}
//-------------		
	
    $name_o = str_replace('/home/pi/domoticz/scripts/lua/', '', $_POST['origen_file']); 
    

    
    if (substr($name_o,0,4) =='off_')
	{
        $filename = "off_climat_".$_POST[Name_unit].".lua";
    } 
    
 
    
	$dataArray = [];  // Массив для заполнения настроек
	
	$dataArray[] = 'commandArray = {}';
	$dataArray[] = '------------------------------------------------------------------------------';
	$dataArray[] = '------------------------------ Установки -------------------------------------';
	$dataArray[] = 'Name_unit = "'.$_POST[Name_unit].'"';

    //var_dump($_POST); exit();

       foreach ($_POST as $key => $value) 
       {

       // $set_value[] = "$key=$value";


         if(substr($key, 0, 4) == 'info'  ) {array_push($info[$key] = $value);}
         if(substr($key, 0, 6) == 'label_') {array_push($label[$key] = $value);}  
         if(substr($key, 0, 4) == 'set_'  ) {array_push($set_value[$key] = $value);}
         if(substr($key, 0, 5) == 'setm_' ) {array_push($set_value_m[$key] = $value);}
         if(substr($key, 0, 5) == 'sets_' ) {array_push($set_value_s[$key] = $value);}
           
         if(substr($key, 0, 3) == 'set'  ) {array_push($set_all[$key] = $value);}
         
         if(substr($key, 0, 14)  == 'Name_unit_info'  ) {array_push($set_all[$key] = $value);}
       }
    
	
	
		// Архив со значениями из Поста
		foreach ($set_all as $key => $value) 
		{
			if (substr($key, 0, 14) == 'Name_unit_info') {
				$dataArray[] = '--info: = ' . $_POST['Name_unit_info'];
			} elseif (substr($key, 0, 5) == 'setm_') {
				$dataArray[] = $key . ' = {' . trim($set_value_m[$key]) . '}';
			} elseif (substr($key, 0, 5) == 'sets_') {
				$dataArray[] = $key . ' = "' . trim($set_value_s[$key]) . '"';
			} elseif (substr($key, 0, 4) == 'set_') {
				$dataArray[] = $key . ' = ' . trim($set_value[$key]);
			}

			if (substr($key, 0, 3) == 'set') {
				$lastIndex = count($dataArray) - 1;
				$dataArray[$lastIndex] .= ' -- label<' . trim($label["label_" . $key]) . '>label ';
				$dataArray[$lastIndex] .= 'info<' . trim($info["info_" . $key]) . '>info ';
			}
		}
	
		// Преобразование $dataArray в $fh_parsed
		$fh_parsed = [];
		foreach ($dataArray as $item) {
			$parts = explode('=', $item, 2);
			if (count($parts) >= 2) {
				$key = trim($parts[0]);
				$value = trim($parts[1]);

				// Сохраняем во всех случаях
				$fh_parsed[$key] = $value;
			}
		}
	//var_dump ($fh_parsed); exit;

	
		// Чтение и обновление файла header
		$filename_header = 'header';

		if (file_exists($filename_header)) 
		{
			$header_standard = file($filename_header, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

			
			
			// Если сохраняем header - образец
			if (isset($_POST['save_header'])) 
			{
				// Обновляем значения в $header_standard
				foreach ($header_standard as &$item) {
					// Проверяем, содержит ли строка символ "="
					if (strpos($item, '=') !== false) {
						// Разбиваем строку на ключ и значение
						list($key, $value) = explode('=', trim($item), 2);
						$key = trim($key);

						// Проверяем, есть ли это переменная в $fh_parsed
						if (isset($fh_parsed[$key])) {
							// Если есть, заменяем значение
							$item = "$key = " . $fh_parsed[$key];
						}
					}
				}

				// Открыть файл для записи
				$fh = fopen("header", "w");

				if ($fh) 
					{
						// Цикл по элементам массива
						foreach ($header_standard as $value) {
							fwrite($fh, $value . PHP_EOL); // Записываем значение и добавляем новую строку
						}

						fclose($fh); // Правильное закрытие файла
					} 
				else {
					echo "Не удалось открыть файл для записи."; exit;
					}

				// Создание имени файла на основе данных из $_POST
				$filename = "script_time_climat_" . $_POST['Name_unit'] . ".lua";
			}
					
			// Если сохраняем скрипт целиком heder + тело
			else
			{
					foreach ($header_standard as &$item) 
					{
						if (strpos($item, '=') !== false) 
						{
								list($key, $rest) = explode('=', $item, 2);
								$key = trim($key);

								// Проверка: если $key  равен '--info'
								if ($key === '--info') {
									// Проверяем, что существует ключ в $fh_parsed
									if (isset($fh_parsed[$key])) {
										// Полностью заменяем значение
										$item = "$key = " . trim($fh_parsed[$key]);
									}
								} elseif ($key !== '--info') 
								{
									// Если $key не содержит 'setm_P' и не равен '--info'
									if (isset($fh_parsed[$key])) {
										// Получаем новое значение и обрезаем его, если есть ' -- label<'
										$newValue = trim($fh_parsed[$key]);
										if (strpos($newValue, ' -- label<') !== false) {
											// Обрезаем строку до ' -- label<'
											$newValue = substr($newValue, 0, strpos($newValue, ' -- label<'));
										}

										// Проверяем, есть ли ' -- label<' в $rest
										if (strpos($rest, ' -- label<') !== false) {
											// Заменяем значение у соответствующей переменной в $header_standard
											$item = "$key = " . $newValue  . substr($rest, strpos($rest, ' -- label<'));
										} else {
											// Если ' -- label<' нет, просто заменяем значение
											$item = "$key = " . $newValue;
										}
									 }
								 }
						  }
					 }
			;
				$fh = fopen("/home/pi/domoticz/scripts/lua/temp_".$filename, "w");	
				  // Цикл по элементам массива
					foreach ($header_standard as $value) {
						fwrite($fh, $value . PHP_EOL); // Записываем значение и добавляем новую строку
					}

				//Присоединение програмной части
						$file2 = file_get_contents( "script_part" );
						fwrite($fh , $file2);

				fclose($filename); 

				//Копирование финального файла
				$path1 = "/home/pi/domoticz/scripts/lua/temp_".$filename;
				$path2 = '/home/pi/domoticz/scripts/lua/'.$filename;
				$comand = ' mv '. $path1. ' '. $path2;
				$output = shell_exec($comand);
				//echo $comand;

				
				
			}
			
			
			
		}


  
    




}
else { $query_string = $_SERVER['QUERY_STRING'];}




 


 

// Эта форма отправляется автоматом после загрузки страницы
echo 
     '
<html>
<body onload="document.frm1.submit()">
   <form action="index.php" name="frm1" method="POST">
      <input type="hidden" name="rast" value="'.$filename.'" />
   </form>
</body>
</html>
' 




?>


