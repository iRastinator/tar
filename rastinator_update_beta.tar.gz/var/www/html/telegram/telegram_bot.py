import requests
import sys
import os

print(f"Текущий пользователь: {os.geteuid()}")

def get_chat_id(token):
    url = f"https://api.telegram.org/bot{token}/getUpdates"
    response = requests.get(url)

    if response.status_code == 200:
        updates = response.json().get('result', [])
        if updates:
            chat_id = updates[-1]['message']['chat']['id']
            print(f"Полученный chat_id: {chat_id}")

            try:
                with open("/var/www/html/telegram/chat_id.txt", "w") as file:
                    file.write(str(chat_id))
                    print("Файл chat_id.txt успешно создан и записан.")
            except Exception as e:
                print(f"Ошибка при записи в файл chat_id.txt: {str(e)}")
            return chat_id
        else:
            print("Нет обновлений. Убедитесь, что вы отправили сообщение вашему боту.")
    else:
        print(f"Ошибка при получении обновлений: {response.status_code}, {response.text}")

    return None


def load_chat_id():
    # Загружаем chat_id из файла
    if os.path.exists("/var/www/html/telegram/chat_id.txt"):
        with open("/var/www/html/telegram/chat_id.txt", "r") as file:
            return file.read().strip()
    return None

def send_message(token, chat_id, message):
    message = message.replace('_', '-')  # Заменяем "_" на "-"
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    payload = {
        'chat_id': chat_id,
        'text': message,
        'parse_mode': 'Markdown'  # Для использования HTML установите 'HTML'
    }

    response = requests.post(url, data=payload)
    if response.status_code == 200:
        print("Сообщение отправлено успешно!")
    else:
        print(f"Ошибка при отправке сообщения: {response.status_code}, {response.text}")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Использование: python send_telegram_message.py <TOKEN> <MESSAGE>")
        sys.exit(1)

    bot_token = sys.argv[1]  # Токен бота
    message = sys.argv[2]     # Сообщение для отправки

    # Загружаем chat_id
    chat_id = load_chat_id()

    # Если chat_id не загружен, получаем его
    if chat_id is None:
        chat_id = get_chat_id(bot_token)

    if chat_id is not None:
        send_message(bot_token, chat_id, message)
    else:
        print("Не удалось получить chat_id.")

