            
<style>
body{    
background-color:#545454;
font-family:Tahoma ;
overflow-x:hidden;
}
</style>                                    

<div style=" color:gainsboro; Position:absolute; top:50%;left:50%;transform:translate(-50%,-50%);font-size: 36px;"> <img src="../pic/loading_pic.gif" > </div>

<?php
                                      
//echo '</br>_POST=';
//var_dump($_POST);
//echo '</br>Button=';
//var_dump(isset($_POST['run_script']));
//exit();
    //var_dump($_POST['Name_unit_info']); exit();
    
//var_dump($_POST);
//var_dump($_POST['Name_unit']); exit();

// Если произошел сбой при отправкие формы  и последний проверочный input отсутствует - то выход.
if($_POST["cheсk"] != "check") { exit();}

$filename=''; // Имя файла для отправки в climat.php

function utf8_urldecode($str) 
    {$str = preg_replace("/%u([0-9a-f]{3,4})/i","&#x\\1;",urldecode($str));
     return html_entity_decode($str,null,'UTF-8');;
    }




// Если  сохранить изменения - удаляется старый файл и дальше генерится новой -----------------
// удаляем переменную для старого названия и создаем новую

if(isset($_POST['save_changes'])) 
{   
    
    $name_o = str_replace('/home/pi/domoticz/scripts/lua/script_time_climat', '', $_POST['origen_file']);
       
   // Если скрипт выключен    
    if (substr( $_POST['origen_file'], 0 , 40) == '/home/pi/domoticz/scripts/lua/off_climat_') {
     $name_o = str_replace('/home/pi/domoticz/scripts/lua/off_climat_', '', $_POST['origen_file']);   
         }
     
    $name_o = str_replace ('.lua', '' , $name_o);

    
    //Удаление файла скрипта
    $comand = ' rm '.$_POST['origen_file'];
    //echo $comand; 
    $output = shell_exec($comand);

}
    
//exit();





// Создание нового файла профиля растения ------------------------------------------------------
$query_string = "";
$key = "";
$value = "";
if (isset($_POST['save_changes']) || isset($_POST['new_porfile'])) 
{  
       $set_value = array();
       $set_value_m = array();
       $set_value_s = array();
       $set_all = array();
       //$tmp = array();
       $label = array();
       $info = array();
    
        
    $filename = $_POST[Name_unit].".lua";
 
    

    
    
    
    $fh = fopen("/home/pi/domoticz/scripts/lua/temp_script_time_climat_".$filename, "w"); 
   
    fwrite($fh , 'commandArray = {}'."\r\n");
    fwrite($fh , '------------------------------------------------------------------------------'."\r\n");
    fwrite($fh , '------------------------------ Установки -------------------------------------'."\r\n");
    fwrite($fh , 'Name_unit = "'.$_POST[Name_unit].'"'."\r\n");

    //var_dump($_POST); exit();

       foreach ($_POST as $key => $value) 
       {

       // $set_value[] = "$key=$value";


         if(substr($key, 0, 4) == 'info'  ) {array_push($info[$key] = $value);}
         if(substr($key, 0, 6) == 'label_') {array_push($label[$key] = $value);}  
         if(substr($key, 0, 4) == 'set_'  ) {array_push($set_value[$key] = $value);}
         if(substr($key, 0, 5) == 'setm_' ) {array_push($set_value_m[$key] = $value);}
         if(substr($key, 0, 5) == 'sets_' ) {array_push($set_value_s[$key] = $value);}
           
         if(substr($key, 0, 3) == 'set'  ) {array_push($set_all[$key] = $value);}
         if(substr($key, 0, 10)  == 'separation'  ) {array_push($set_all[$key] = $value);}
         if(substr($key, 0, 14)  == 'Name_unit_info'  ) {array_push($set_all[$key] = $value);}
       }
       
    foreach ($set_all as $key => $value) 
       {
        
        
        if (substr($key, 0, 14)  == 'Name_unit_info')
            {
            fwrite($fh , '--info:'.$_POST['Name_unit_info']."\r\n");
            }
        
        if (substr($key, 0, 10)  == 'separation') 
            {
            fwrite($fh , '--separation'."\r\n");
            }
            
        if (substr($key, 0, 5) == 'setm_') 
            {
            fwrite($fh , $key);
            fwrite($fh , ' = {');
            fwrite($fh , trim($set_value_m[$key]));
            fwrite($fh , '}');    
        
            }
        if (substr($key, 0, 5) == 'sets_') 
            {
            fwrite($fh ,  $key);
            fwrite($fh , ' = "');
            fwrite($fh , trim($set_value_s[$key]));
            fwrite($fh , '"');    
        
            }
        if (substr($key, 0, 4) == 'set_') 
            {
            fwrite($fh , $key);
            fwrite($fh , ' = ');
            fwrite($fh , trim($set_value[$key]) );    
            }
        
        if (substr($key, 0, 3) == 'set')
        {
            fwrite($fh , ' -- label<');
            fwrite($fh , trim($label["label_".$key]) ); 
            fwrite($fh , '>label ');

            fwrite($fh , 'info<');
            fwrite($fh , trim ($info["info_".$key]));
            fwrite($fh , '>info'."\r\n");
         }
    
              
      }
  
    

    //Присоединение програмной части
            //Если скрипт котролирует температуру
            if (isset($_POST['set_Value_Cooler']) )
            {$file2 = file_get_contents( "script_part_climat_temp" ); }
            //Если скрипт котролирует Co2 
            if (isset($_POST['sets_Canal_Co2']) )
            {$file2 = file_get_contents( "script_part_co2" ); }   
            
            
    
            fwrite($fh , $file2);

    fclose($filename); 

    //Копирование финального файла
    $path1 = "/home/pi/domoticz/scripts/lua/temp_script_time_climat_".$_POST[Name_unit].".lua";
    $path2 = '/home/pi/domoticz/scripts/lua/script_time_climat_'.$_POST[Name_unit].".lua";
    $filename = 'script_time_climat_'.$filename;
    
    
    $name_o = str_replace('/home/pi/domoticz/scripts/lua/', '', $_POST['origen_file']); 
    if (substr($name_o,0,4) =='off_')
        {
         $path2 = '/home/pi/domoticz/scripts/lua/off_climat_'.$_POST[Name_unit].".lua";
         $filename = 'off_climat_'.$_POST[Name_unit].".lua";
        } 
    
    
    
    $comand = ' mv '. $path1. ' '. $path2;
    $output = shell_exec($comand);

 


}
else { $query_string = $_SERVER['QUERY_STRING'];}




 


 

// Эта форма отправляется автоматом после загрузки страницы
echo 
     '
<html>
<body onload="document.frm1.submit()">
   <form action="index.php" name="frm1" method="POST">
      <input type="hidden" name="rast" value="'.$filename.'" />
   </form>
</body>
</html>
' 




?>


